<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-P7FCGMN"></script>
    <script type="module" id="prepare-env" src="1.js"></script>
    <!-- WebA adobe-->
    <script type="text/javascript">
      var dataLayer = dataLayer || [];
    </script>
    <title>Cetelem login page</title>

    <link rel="stylesheet" href="1.css">
 
    <script src="https://assets.adobedtm.com/d398b9f3a685/a46c52b7af05/launch-7d505e9b0fe4.min.js" async=""></script>
    <script src="https://cdn.cookielaw.org/scripttemplates/6.17.0/otBannerSdk.js" async="" type="text/javascript"></script>
    <script src="https://assets.adobedtm.com/extensions/EPbf7b42aa08bc4f10879b1484195e80d1/AppMeasurement.min.js" async=""></script>
    <script src="https://assets.adobedtm.com/d398b9f3a685/a46c52b7af05/ce7835914794/RCb58a23326d2748f4afca6326a5c32ec9-source.min.js" async=""></script>
    <style id="onetrust-style">
      #onetrust-banner-sdk {
        -ms-text-size-adjust: 100%;
        -webkit-text-size-adjust: 100%
      }

      #onetrust-banner-sdk .onetrust-vendors-list-handler {
        cursor: pointer;
        color: #1f96db;
        font-size: inherit;
        font-weight: bold;
        text-decoration: none;
        margin-left: 5px
      }

      #onetrust-banner-sdk .onetrust-vendors-list-handler:hover {
        color: #1f96db
      }

      #onetrust-banner-sdk:focus {
        outline: 2px solid #000;
        outline-offset: -2px
      }

      #onetrust-banner-sdk a:focus {
        outline: 2px solid #000
      }

      #onetrust-banner-sdk .ot-close-icon,
      #onetrust-pc-sdk .ot-close-icon,
      #ot-sync-ntfy .ot-close-icon {
        background-image: url("data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB3aWR0aD0iMzQ4LjMzM3B4IiBoZWlnaHQ9IjM0OC4zMzNweCIgdmlld0JveD0iMCAwIDM0OC4zMzMgMzQ4LjMzNCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzQ4LjMzMyAzNDguMzM0OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PGc+PHBhdGggZmlsbD0iIzU2NTY1NiIgZD0iTTMzNi41NTksNjguNjExTDIzMS4wMTYsMTc0LjE2NWwxMDUuNTQzLDEwNS41NDljMTUuNjk5LDE1LjcwNSwxNS42OTksNDEuMTQ1LDAsNTYuODVjLTcuODQ0LDcuODQ0LTE4LjEyOCwxMS43NjktMjguNDA3LDExLjc2OWMtMTAuMjk2LDAtMjAuNTgxLTMuOTE5LTI4LjQxOS0xMS43NjlMMTc0LjE2NywyMzEuMDAzTDY4LjYwOSwzMzYuNTYzYy03Ljg0Myw3Ljg0NC0xOC4xMjgsMTEuNzY5LTI4LjQxNiwxMS43NjljLTEwLjI4NSwwLTIwLjU2My0zLjkxOS0yOC40MTMtMTEuNzY5Yy0xNS42OTktMTUuNjk4LTE1LjY5OS00MS4xMzksMC01Ni44NWwxMDUuNTQtMTA1LjU0OUwxMS43NzQsNjguNjExYy0xNS42OTktMTUuNjk5LTE1LjY5OS00MS4xNDUsMC01Ni44NDRjMTUuNjk2LTE1LjY4Nyw0MS4xMjctMTUuNjg3LDU2LjgyOSwwbDEwNS41NjMsMTA1LjU1NEwyNzkuNzIxLDExLjc2N2MxNS43MDUtMTUuNjg3LDQxLjEzOS0xNS42ODcsNTYuODMyLDBDMzUyLjI1OCwyNy40NjYsMzUyLjI1OCw1Mi45MTIsMzM2LjU1OSw2OC42MTF6Ii8+PC9nPjwvc3ZnPg==");
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        height: 12px;
        width: 12px
      }

      #onetrust-banner-sdk .powered-by-logo,
      #onetrust-banner-sdk .ot-pc-footer-logo a,
      #onetrust-pc-sdk .powered-by-logo,
      #onetrust-pc-sdk .ot-pc-footer-logo a,
      #ot-sync-ntfy .powered-by-logo,
      #ot-sync-ntfy .ot-pc-footer-logo a {
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        height: 25px;
        width: 152px;
        display: block
      }

      #onetrust-banner-sdk h3 *,
      #onetrust-banner-sdk h4 *,
      #onetrust-banner-sdk h6 *,
      #onetrust-banner-sdk button *,
      #onetrust-banner-sdk a[data-parent-id] *,
      #onetrust-pc-sdk h3 *,
      #onetrust-pc-sdk h4 *,
      #onetrust-pc-sdk h6 *,
      #onetrust-pc-sdk button *,
      #onetrust-pc-sdk a[data-parent-id] *,
      #ot-sync-ntfy h3 *,
      #ot-sync-ntfy h4 *,
      #ot-sync-ntfy h6 *,
      #ot-sync-ntfy button *,
      #ot-sync-ntfy a[data-parent-id] * {
        font-size: inherit;
        font-weight: inherit;
        color: inherit
      }

      #onetrust-banner-sdk .ot-hide,
      #onetrust-pc-sdk .ot-hide,
      #ot-sync-ntfy .ot-hide {
        display: none !important
      }

      #onetrust-pc-sdk .ot-sdk-row .ot-sdk-column {
        padding: 0
      }

      #onetrust-pc-sdk .ot-sdk-container {
        padding-right: 0
      }

      #onetrust-pc-sdk .ot-sdk-row {
        flex-direction: initial;
        width: 100%
      }

      #onetrust-pc-sdk [type="checkbox"]:checked,
      #onetrust-pc-sdk [type="checkbox"]:not(:checked) {
        pointer-events: initial
      }

      #onetrust-pc-sdk [type="checkbox"]:disabled+label::before,
      #onetrust-pc-sdk [type="checkbox"]:disabled+label:after,
      #onetrust-pc-sdk [type="checkbox"]:disabled+label {
        pointer-events: none;
        opacity: 0.7
      }

      #onetrust-pc-sdk #vendor-list-content {
        transform: translate3d(0, 0, 0)
      }

      #onetrust-pc-sdk li input[type="checkbox"] {
        z-index: 1
      }

      #onetrust-pc-sdk li .ot-checkbox label {
        z-index: 2
      }

      #onetrust-pc-sdk li .ot-checkbox input[type="checkbox"] {
        height: auto;
        width: auto
      }

      #onetrust-pc-sdk li .host-title a,
      #onetrust-pc-sdk li .ot-host-name a,
      #onetrust-pc-sdk li .accordion-text,
      #onetrust-pc-sdk li .ot-acc-txt {
        z-index: 2;
        position: relative
      }

      #onetrust-pc-sdk input {
        margin: 3px 0.1ex
      }

      #onetrust-pc-sdk .toggle-always-active {
        opacity: 0.6;
        cursor: default
      }

      #onetrust-pc-sdk .pc-logo,
      #onetrust-pc-sdk .ot-pc-logo {
        height: 60px;
        width: 180px;
        background-position: center;
        background-size: contain;
        background-repeat: no-repeat
      }

      #onetrust-pc-sdk .ot-tooltip .ot-tooltiptext {
        visibility: hidden;
        width: 120px;
        background-color: #555;
        color: #fff;
        text-align: center;
        padding: 5px 0;
        border-radius: 6px;
        position: absolute;
        z-index: 1;
        bottom: 125%;
        left: 50%;
        margin-left: -60px;
        opacity: 0;
        transition: opacity 0.3s
      }

      #onetrust-pc-sdk .ot-tooltip .ot-tooltiptext::after {
        content: "";
        position: absolute;
        top: 100%;
        left: 50%;
        margin-left: -5px;
        border-width: 5px;
        border-style: solid;
        border-color: #555 transparent transparent transparent
      }

      #onetrust-pc-sdk .ot-tooltip:hover .ot-tooltiptext {
        visibility: visible;
        opacity: 1
      }

      #onetrust-pc-sdk .ot-tooltip {
        position: relative;
        display: inline-block;
        z-index: 3
      }

      #onetrust-pc-sdk .ot-tooltip svg {
        color: grey;
        height: 20px;
        width: 20px
      }

      #onetrust-pc-sdk .screen-reader-only,
      #onetrust-pc-sdk .ot-scrn-rdr,
      .ot-sdk-cookie-policy .screen-reader-only,
      .ot-sdk-cookie-policy .ot-scrn-rdr {
        border: 0;
        clip: rect(0 0 0 0);
        height: 1px;
        margin: -1px;
        overflow: hidden;
        padding: 0;
        position: absolute;
        width: 1px
      }

      #onetrust-pc-sdk.ot-fade-in,
      .onetrust-pc-dark-filter.ot-fade-in,
      #onetrust-banner-sdk.ot-fade-in {
        animation-name: onetrust-fade-in;
        animation-duration: 400ms;
        animation-timing-function: ease-in-out
      }

      #onetrust-pc-sdk.ot-hide {
        display: none !important
      }

      .onetrust-pc-dark-filter.ot-hide {
        display: none !important
      }

      #ot-sdk-btn.ot-sdk-show-settings,
      #ot-sdk-btn.optanon-show-settings {
        color: #68b631;
        border: 1px solid #68b631;
        height: auto;
        white-space: normal;
        word-wrap: break-word;
        padding: 0.8em 2em;
        font-size: 0.8em;
        line-height: 1.2;
        cursor: pointer;
        -moz-transition: 0.1s ease;
        -o-transition: 0.1s ease;
        -webkit-transition: 1s ease;
        transition: 0.1s ease
      }

      #ot-sdk-btn.ot-sdk-show-settings:hover,
      #ot-sdk-btn.optanon-show-settings:hover {
        color: #fff;
        background-color: #68b631
      }

      .onetrust-pc-dark-filter {
        background: rgba(0, 0, 0, 0.5);
        z-index: 2147483646;
        width: 100%;
        height: 100%;
        overflow: hidden;
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0
      }

      @keyframes onetrust-fade-in {
        0% {
          opacity: 0
        }

        100% {
          opacity: 1
        }
      }

      @media only screen and (min-width: 426px) and (max-width: 896px) and (orientation: landscape) {
        #onetrust-pc-sdk p {
          font-size: 0.75em
        }
      }

      #onetrust-banner-sdk .banner-option-input:focus+label {
        outline: 1px solid #000;
        outline-style: auto
      }

      #onetrust-banner-sdk,
      #onetrust-pc-sdk,
      #ot-sdk-cookie-policy,
      #ot-sync-ntfy {
        font-size: 16px
      }

      #onetrust-banner-sdk *,
      #onetrust-banner-sdk ::after,
      #onetrust-banner-sdk ::before,
      #onetrust-pc-sdk *,
      #onetrust-pc-sdk ::after,
      #onetrust-pc-sdk ::before,
      #ot-sdk-cookie-policy *,
      #ot-sdk-cookie-policy ::after,
      #ot-sdk-cookie-policy ::before,
      #ot-sync-ntfy *,
      #ot-sync-ntfy ::after,
      #ot-sync-ntfy ::before {
        -webkit-box-sizing: content-box;
        -moz-box-sizing: content-box;
        box-sizing: content-box
      }

      #onetrust-banner-sdk div,
      #onetrust-banner-sdk span,
      #onetrust-banner-sdk h1,
      #onetrust-banner-sdk h2,
      #onetrust-banner-sdk h3,
      #onetrust-banner-sdk h4,
      #onetrust-banner-sdk h5,
      #onetrust-banner-sdk h6,
      #onetrust-banner-sdk p,
      #onetrust-banner-sdk img,
      #onetrust-banner-sdk svg,
      #onetrust-banner-sdk button,
      #onetrust-banner-sdk section,
      #onetrust-banner-sdk a,
      #onetrust-banner-sdk label,
      #onetrust-banner-sdk input,
      #onetrust-banner-sdk ul,
      #onetrust-banner-sdk li,
      #onetrust-banner-sdk nav,
      #onetrust-banner-sdk table,
      #onetrust-banner-sdk thead,
      #onetrust-banner-sdk tr,
      #onetrust-banner-sdk td,
      #onetrust-banner-sdk tbody,
      #onetrust-banner-sdk .ot-main-content,
      #onetrust-banner-sdk .ot-toggle,
      #onetrust-banner-sdk #ot-content,
      #onetrust-banner-sdk #ot-pc-content,
      #onetrust-banner-sdk .checkbox,
      #onetrust-pc-sdk div,
      #onetrust-pc-sdk span,
      #onetrust-pc-sdk h1,
      #onetrust-pc-sdk h2,
      #onetrust-pc-sdk h3,
      #onetrust-pc-sdk h4,
      #onetrust-pc-sdk h5,
      #onetrust-pc-sdk h6,
      #onetrust-pc-sdk p,
      #onetrust-pc-sdk img,
      #onetrust-pc-sdk svg,
      #onetrust-pc-sdk button,
      #onetrust-pc-sdk section,
      #onetrust-pc-sdk a,
      #onetrust-pc-sdk label,
      #onetrust-pc-sdk input,
      #onetrust-pc-sdk ul,
      #onetrust-pc-sdk li,
      #onetrust-pc-sdk nav,
      #onetrust-pc-sdk table,
      #onetrust-pc-sdk thead,
      #onetrust-pc-sdk tr,
      #onetrust-pc-sdk td,
      #onetrust-pc-sdk tbody,
      #onetrust-pc-sdk .ot-main-content,
      #onetrust-pc-sdk .ot-toggle,
      #onetrust-pc-sdk #ot-content,
      #onetrust-pc-sdk #ot-pc-content,
      #onetrust-pc-sdk .checkbox,
      #ot-sdk-cookie-policy div,
      #ot-sdk-cookie-policy span,
      #ot-sdk-cookie-policy h1,
      #ot-sdk-cookie-policy h2,
      #ot-sdk-cookie-policy h3,
      #ot-sdk-cookie-policy h4,
      #ot-sdk-cookie-policy h5,
      #ot-sdk-cookie-policy h6,
      #ot-sdk-cookie-policy p,
      #ot-sdk-cookie-policy img,
      #ot-sdk-cookie-policy svg,
      #ot-sdk-cookie-policy button,
      #ot-sdk-cookie-policy section,
      #ot-sdk-cookie-policy a,
      #ot-sdk-cookie-policy label,
      #ot-sdk-cookie-policy input,
      #ot-sdk-cookie-policy ul,
      #ot-sdk-cookie-policy li,
      #ot-sdk-cookie-policy nav,
      #ot-sdk-cookie-policy table,
      #ot-sdk-cookie-policy thead,
      #ot-sdk-cookie-policy tr,
      #ot-sdk-cookie-policy td,
      #ot-sdk-cookie-policy tbody,
      #ot-sdk-cookie-policy .ot-main-content,
      #ot-sdk-cookie-policy .ot-toggle,
      #ot-sdk-cookie-policy #ot-content,
      #ot-sdk-cookie-policy #ot-pc-content,
      #ot-sdk-cookie-policy .checkbox,
      #ot-sync-ntfy div,
      #ot-sync-ntfy span,
      #ot-sync-ntfy h1,
      #ot-sync-ntfy h2,
      #ot-sync-ntfy h3,
      #ot-sync-ntfy h4,
      #ot-sync-ntfy h5,
      #ot-sync-ntfy h6,
      #ot-sync-ntfy p,
      #ot-sync-ntfy img,
      #ot-sync-ntfy svg,
      #ot-sync-ntfy button,
      #ot-sync-ntfy section,
      #ot-sync-ntfy a,
      #ot-sync-ntfy label,
      #ot-sync-ntfy input,
      #ot-sync-ntfy ul,
      #ot-sync-ntfy li,
      #ot-sync-ntfy nav,
      #ot-sync-ntfy table,
      #ot-sync-ntfy thead,
      #ot-sync-ntfy tr,
      #ot-sync-ntfy td,
      #ot-sync-ntfy tbody,
      #ot-sync-ntfy .ot-main-content,
      #ot-sync-ntfy .ot-toggle,
      #ot-sync-ntfy #ot-content,
      #ot-sync-ntfy #ot-pc-content,
      #ot-sync-ntfy .checkbox {
        font-family: inherit;
        font-weight: normal;
        -webkit-font-smoothing: auto;
        letter-spacing: normal;
        line-height: normal;
        padding: 0;
        margin: 0;
        height: auto;
        min-height: 0;
        max-height: none;
        width: auto;
        min-width: 0;
        max-width: none;
        border-radius: 0;
        border: none;
        clear: none;
        float: none;
        position: static;
        bottom: auto;
        left: auto;
        right: auto;
        top: auto;
        text-align: left;
        text-decoration: none;
        text-indent: 0;
        text-shadow: none;
        text-transform: none;
        white-space: normal;
        background: none;
        overflow: visible;
        vertical-align: baseline;
        visibility: visible;
        z-index: auto;
        box-shadow: none
      }

      #onetrust-banner-sdk label:before,
      #onetrust-banner-sdk label:after,
      #onetrust-banner-sdk .checkbox:after,
      #onetrust-banner-sdk .checkbox:before,
      #onetrust-pc-sdk label:before,
      #onetrust-pc-sdk label:after,
      #onetrust-pc-sdk .checkbox:after,
      #onetrust-pc-sdk .checkbox:before,
      #ot-sdk-cookie-policy label:before,
      #ot-sdk-cookie-policy label:after,
      #ot-sdk-cookie-policy .checkbox:after,
      #ot-sdk-cookie-policy .checkbox:before,
      #ot-sync-ntfy label:before,
      #ot-sync-ntfy label:after,
      #ot-sync-ntfy .checkbox:after,
      #ot-sync-ntfy .checkbox:before {
        content: "";
        content: none
      }

      #onetrust-banner-sdk .ot-sdk-container,
      #onetrust-pc-sdk .ot-sdk-container,
      #ot-sdk-cookie-policy .ot-sdk-container {
        position: relative;
        width: 100%;
        max-width: 100%;
        margin: 0 auto;
        padding: 0 20px;
        box-sizing: border-box
      }

      #onetrust-banner-sdk .ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-columns {
        width: 100%;
        float: left;
        box-sizing: border-box;
        padding: 0;
        display: initial
      }

      @media (min-width: 400px) {

        #onetrust-banner-sdk .ot-sdk-container,
        #onetrust-pc-sdk .ot-sdk-container,
        #ot-sdk-cookie-policy .ot-sdk-container {
          width: 90%;
          padding: 0
        }
      }

      @media (min-width: 550px) {

        #onetrust-banner-sdk .ot-sdk-container,
        #onetrust-pc-sdk .ot-sdk-container,
        #ot-sdk-cookie-policy .ot-sdk-container {
          width: 100%
        }

        #onetrust-banner-sdk .ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-columns {
          margin-left: 4%
        }

        #onetrust-banner-sdk .ot-sdk-column:first-child,
        #onetrust-banner-sdk .ot-sdk-columns:first-child,
        #onetrust-pc-sdk .ot-sdk-column:first-child,
        #onetrust-pc-sdk .ot-sdk-columns:first-child,
        #ot-sdk-cookie-policy .ot-sdk-column:first-child,
        #ot-sdk-cookie-policy .ot-sdk-columns:first-child {
          margin-left: 0
        }

        #onetrust-banner-sdk .ot-sdk-one.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-one.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-one.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-one.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-one.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-one.ot-sdk-columns {
          width: 4.66666666667%
        }

        #onetrust-banner-sdk .ot-sdk-two.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-two.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-two.ot-sdk-columns {
          width: 13.3333333333%
        }

        #onetrust-banner-sdk .ot-sdk-three.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-three.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-three.ot-sdk-columns {
          width: 22%
        }

        #onetrust-banner-sdk .ot-sdk-four.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-four.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-four.ot-sdk-columns {
          width: 30.6666666667%
        }

        #onetrust-banner-sdk .ot-sdk-five.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-five.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-five.ot-sdk-columns {
          width: 39.3333333333%
        }

        #onetrust-banner-sdk .ot-sdk-six.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-six.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-six.ot-sdk-columns {
          width: 48%
        }

        #onetrust-banner-sdk .ot-sdk-seven.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-seven.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-seven.ot-sdk-columns {
          width: 56.6666666667%
        }

        #onetrust-banner-sdk .ot-sdk-eight.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-eight.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-eight.ot-sdk-columns {
          width: 65.3333333333%
        }

        #onetrust-banner-sdk .ot-sdk-nine.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-nine.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-nine.ot-sdk-columns {
          width: 74%
        }

        #onetrust-banner-sdk .ot-sdk-ten.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-ten.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-ten.ot-sdk-columns {
          width: 82.6666666667%
        }

        #onetrust-banner-sdk .ot-sdk-eleven.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-eleven.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-eleven.ot-sdk-columns {
          width: 91.3333333333%
        }

        #onetrust-banner-sdk .ot-sdk-twelve.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-twelve.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-twelve.ot-sdk-columns {
          width: 100%;
          margin-left: 0
        }

        #onetrust-banner-sdk .ot-sdk-one-third.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-one-third.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-one-third.ot-sdk-column {
          width: 30.6666666667%
        }

        #onetrust-banner-sdk .ot-sdk-two-thirds.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-two-thirds.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-two-thirds.ot-sdk-column {
          width: 65.3333333333%
        }

        #onetrust-banner-sdk .ot-sdk-one-half.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-one-half.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-one-half.ot-sdk-column {
          width: 48%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-one.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-one.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-one.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-one.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-one.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-one.ot-sdk-columns {
          margin-left: 8.66666666667%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-two.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-two.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-two.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-two.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-two.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-two.ot-sdk-columns {
          margin-left: 17.3333333333%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-three.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-three.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-three.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-three.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-three.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-three.ot-sdk-columns {
          margin-left: 26%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-four.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-four.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-four.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-four.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-four.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-four.ot-sdk-columns {
          margin-left: 34.6666666667%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-five.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-five.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-five.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-five.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-five.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-five.ot-sdk-columns {
          margin-left: 43.3333333333%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-six.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-six.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-six.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-six.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-six.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-six.ot-sdk-columns {
          margin-left: 52%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-seven.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-seven.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-seven.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-seven.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-seven.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-seven.ot-sdk-columns {
          margin-left: 60.6666666667%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-eight.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-eight.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-eight.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-eight.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-eight.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-eight.ot-sdk-columns {
          margin-left: 69.3333333333%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-nine.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-nine.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-nine.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-nine.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-nine.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-nine.ot-sdk-columns {
          margin-left: 78%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-ten.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-ten.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-ten.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-ten.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-ten.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-ten.ot-sdk-columns {
          margin-left: 86.6666666667%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-eleven.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-eleven.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-eleven.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-eleven.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-eleven.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-eleven.ot-sdk-columns {
          margin-left: 95.3333333333%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-one-third.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-one-third.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-one-third.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-one-third.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-one-third.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-one-third.ot-sdk-columns {
          margin-left: 34.6666666667%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-two-thirds.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-two-thirds.ot-sdk-columns {
          margin-left: 69.3333333333%
        }

        #onetrust-banner-sdk .ot-sdk-offset-by-one-half.ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-offset-by-one-half.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-offset-by-one-half.ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-offset-by-one-half.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-one-half.ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-offset-by-one-half.ot-sdk-columns {
          margin-left: 52%
        }
      }

      #onetrust-banner-sdk h1,
      #onetrust-banner-sdk h2,
      #onetrust-banner-sdk h3,
      #onetrust-banner-sdk h4,
      #onetrust-banner-sdk h5,
      #onetrust-banner-sdk h6,
      #onetrust-pc-sdk h1,
      #onetrust-pc-sdk h2,
      #onetrust-pc-sdk h3,
      #onetrust-pc-sdk h4,
      #onetrust-pc-sdk h5,
      #onetrust-pc-sdk h6,
      #ot-sdk-cookie-policy h1,
      #ot-sdk-cookie-policy h2,
      #ot-sdk-cookie-policy h3,
      #ot-sdk-cookie-policy h4,
      #ot-sdk-cookie-policy h5,
      #ot-sdk-cookie-policy h6 {
        margin-top: 0;
        font-weight: 600;
        font-family: inherit
      }

      #onetrust-banner-sdk h1,
      #onetrust-pc-sdk h1,
      #ot-sdk-cookie-policy h1 {
        font-size: 1.5rem;
        line-height: 1.2
      }

      #onetrust-banner-sdk h2,
      #onetrust-pc-sdk h2,
      #ot-sdk-cookie-policy h2 {
        font-size: 1.5rem;
        line-height: 1.25
      }

      #onetrust-banner-sdk h3,
      #onetrust-pc-sdk h3,
      #ot-sdk-cookie-policy h3 {
        font-size: 1.5rem;
        line-height: 1.3
      }

      #onetrust-banner-sdk h4,
      #onetrust-pc-sdk h4,
      #ot-sdk-cookie-policy h4 {
        font-size: 1.5rem;
        line-height: 1.35
      }

      #onetrust-banner-sdk h5,
      #onetrust-pc-sdk h5,
      #ot-sdk-cookie-policy h5 {
        font-size: 1.5rem;
        line-height: 1.5
      }

      #onetrust-banner-sdk h6,
      #onetrust-pc-sdk h6,
      #ot-sdk-cookie-policy h6 {
        font-size: 1.5rem;
        line-height: 1.6
      }

      @media (min-width: 550px) {

        #onetrust-banner-sdk h1,
        #onetrust-pc-sdk h1,
        #ot-sdk-cookie-policy h1 {
          font-size: 1.5rem
        }

        #onetrust-banner-sdk h2,
        #onetrust-pc-sdk h2,
        #ot-sdk-cookie-policy h2 {
          font-size: 1.5rem
        }

        #onetrust-banner-sdk h3,
        #onetrust-pc-sdk h3,
        #ot-sdk-cookie-policy h3 {
          font-size: 1.5rem
        }

        #onetrust-banner-sdk h4,
        #onetrust-pc-sdk h4,
        #ot-sdk-cookie-policy h4 {
          font-size: 1.5rem
        }

        #onetrust-banner-sdk h5,
        #onetrust-pc-sdk h5,
        #ot-sdk-cookie-policy h5 {
          font-size: 1.5rem
        }

        #onetrust-banner-sdk h6,
        #onetrust-pc-sdk h6,
        #ot-sdk-cookie-policy h6 {
          font-size: 1.5rem
        }
      }

      #onetrust-banner-sdk p,
      #onetrust-pc-sdk p,
      #ot-sdk-cookie-policy p {
        margin: 0 0 1em 0;
        font-family: inherit;
        line-height: normal
      }

      #onetrust-banner-sdk a,
      #onetrust-pc-sdk a,
      #ot-sdk-cookie-policy a {
        color: #565656;
        text-decoration: underline
      }

      #onetrust-banner-sdk a:hover,
      #onetrust-pc-sdk a:hover,
      #ot-sdk-cookie-policy a:hover {
        color: #565656;
        text-decoration: none
      }

      #onetrust-banner-sdk .ot-sdk-button,
      #onetrust-banner-sdk button,
      #onetrust-pc-sdk .ot-sdk-button,
      #onetrust-pc-sdk button,
      #ot-sdk-cookie-policy .ot-sdk-button,
      #ot-sdk-cookie-policy button {
        margin-bottom: 1rem;
        font-family: inherit
      }

      #onetrust-banner-sdk .ot-sdk-button,
      #onetrust-banner-sdk button,
      #onetrust-banner-sdk input[type="submit"],
      #onetrust-banner-sdk input[type="reset"],
      #onetrust-banner-sdk input[type="button"],
      #onetrust-pc-sdk .ot-sdk-button,
      #onetrust-pc-sdk button,
      #onetrust-pc-sdk input[type="submit"],
      #onetrust-pc-sdk input[type="reset"],
      #onetrust-pc-sdk input[type="button"],
      #ot-sdk-cookie-policy .ot-sdk-button,
      #ot-sdk-cookie-policy button,
      #ot-sdk-cookie-policy input[type="submit"],
      #ot-sdk-cookie-policy input[type="reset"],
      #ot-sdk-cookie-policy input[type="button"] {
        display: inline-block;
        height: 38px;
        padding: 0 30px;
        color: #555;
        text-align: center;
        font-size: 0.9em;
        font-weight: 400;
        line-height: 38px;
        letter-spacing: 0.01em;
        text-decoration: none;
        white-space: nowrap;
        background-color: transparent;
        border-radius: 2px;
        border: 1px solid #bbb;
        cursor: pointer;
        box-sizing: border-box
      }

      #onetrust-banner-sdk .ot-sdk-button:hover,
      #onetrust-banner-sdk :not(.ot-leg-btn-container)>button:hover,
      #onetrust-banner-sdk input[type="submit"]:hover,
      #onetrust-banner-sdk input[type="reset"]:hover,
      #onetrust-banner-sdk input[type="button"]:hover,
      #onetrust-banner-sdk .ot-sdk-button:focus,
      #onetrust-banner-sdk :not(.ot-leg-btn-container)>button:focus,
      #onetrust-banner-sdk input[type="submit"]:focus,
      #onetrust-banner-sdk input[type="reset"]:focus,
      #onetrust-banner-sdk input[type="button"]:focus,
      #onetrust-pc-sdk .ot-sdk-button:hover,
      #onetrust-pc-sdk :not(.ot-leg-btn-container)>button:hover,
      #onetrust-pc-sdk input[type="submit"]:hover,
      #onetrust-pc-sdk input[type="reset"]:hover,
      #onetrust-pc-sdk input[type="button"]:hover,
      #onetrust-pc-sdk .ot-sdk-button:focus,
      #onetrust-pc-sdk :not(.ot-leg-btn-container)>button:focus,
      #onetrust-pc-sdk input[type="submit"]:focus,
      #onetrust-pc-sdk input[type="reset"]:focus,
      #onetrust-pc-sdk input[type="button"]:focus,
      #ot-sdk-cookie-policy .ot-sdk-button:hover,
      #ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:hover,
      #ot-sdk-cookie-policy input[type="submit"]:hover,
      #ot-sdk-cookie-policy input[type="reset"]:hover,
      #ot-sdk-cookie-policy input[type="button"]:hover,
      #ot-sdk-cookie-policy .ot-sdk-button:focus,
      #ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:focus,
      #ot-sdk-cookie-policy input[type="submit"]:focus,
      #ot-sdk-cookie-policy input[type="reset"]:focus,
      #ot-sdk-cookie-policy input[type="button"]:focus {
        color: #333;
        border-color: #888;
        opacity: 0.7
      }

      #onetrust-banner-sdk .ot-sdk-button:focus,
      #onetrust-banner-sdk :not(.ot-leg-btn-container)>button:focus,
      #onetrust-banner-sdk input[type="submit"]:focus,
      #onetrust-banner-sdk input[type="reset"]:focus,
      #onetrust-banner-sdk input[type="button"]:focus,
      #onetrust-pc-sdk .ot-sdk-button:focus,
      #onetrust-pc-sdk :not(.ot-leg-btn-container)>button:focus,
      #onetrust-pc-sdk input[type="submit"]:focus,
      #onetrust-pc-sdk input[type="reset"]:focus,
      #onetrust-pc-sdk input[type="button"]:focus,
      #ot-sdk-cookie-policy .ot-sdk-button:focus,
      #ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:focus,
      #ot-sdk-cookie-policy input[type="submit"]:focus,
      #ot-sdk-cookie-policy input[type="reset"]:focus,
      #ot-sdk-cookie-policy input[type="button"]:focus {
        outline: 2px solid #000
      }

      #onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary,
      #onetrust-banner-sdk button.ot-sdk-button-primary,
      #onetrust-banner-sdk input[type="submit"].ot-sdk-button-primary,
      #onetrust-banner-sdk input[type="reset"].ot-sdk-button-primary,
      #onetrust-banner-sdk input[type="button"].ot-sdk-button-primary,
      #onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary,
      #onetrust-pc-sdk button.ot-sdk-button-primary,
      #onetrust-pc-sdk input[type="submit"].ot-sdk-button-primary,
      #onetrust-pc-sdk input[type="reset"].ot-sdk-button-primary,
      #onetrust-pc-sdk input[type="button"].ot-sdk-button-primary,
      #ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary,
      #ot-sdk-cookie-policy button.ot-sdk-button-primary,
      #ot-sdk-cookie-policy input[type="submit"].ot-sdk-button-primary,
      #ot-sdk-cookie-policy input[type="reset"].ot-sdk-button-primary,
      #ot-sdk-cookie-policy input[type="button"].ot-sdk-button-primary {
        color: #fff;
        background-color: #33c3f0;
        border-color: #33c3f0
      }

      #onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary:hover,
      #onetrust-banner-sdk button.ot-sdk-button-primary:hover,
      #onetrust-banner-sdk input[type="submit"].ot-sdk-button-primary:hover,
      #onetrust-banner-sdk input[type="reset"].ot-sdk-button-primary:hover,
      #onetrust-banner-sdk input[type="button"].ot-sdk-button-primary:hover,
      #onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary:focus,
      #onetrust-banner-sdk button.ot-sdk-button-primary:focus,
      #onetrust-banner-sdk input[type="submit"].ot-sdk-button-primary:focus,
      #onetrust-banner-sdk input[type="reset"].ot-sdk-button-primary:focus,
      #onetrust-banner-sdk input[type="button"].ot-sdk-button-primary:focus,
      #onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary:hover,
      #onetrust-pc-sdk button.ot-sdk-button-primary:hover,
      #onetrust-pc-sdk input[type="submit"].ot-sdk-button-primary:hover,
      #onetrust-pc-sdk input[type="reset"].ot-sdk-button-primary:hover,
      #onetrust-pc-sdk input[type="button"].ot-sdk-button-primary:hover,
      #onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary:focus,
      #onetrust-pc-sdk button.ot-sdk-button-primary:focus,
      #onetrust-pc-sdk input[type="submit"].ot-sdk-button-primary:focus,
      #onetrust-pc-sdk input[type="reset"].ot-sdk-button-primary:focus,
      #onetrust-pc-sdk input[type="button"].ot-sdk-button-primary:focus,
      #ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary:hover,
      #ot-sdk-cookie-policy button.ot-sdk-button-primary:hover,
      #ot-sdk-cookie-policy input[type="submit"].ot-sdk-button-primary:hover,
      #ot-sdk-cookie-policy input[type="reset"].ot-sdk-button-primary:hover,
      #ot-sdk-cookie-policy input[type="button"].ot-sdk-button-primary:hover,
      #ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary:focus,
      #ot-sdk-cookie-policy button.ot-sdk-button-primary:focus,
      #ot-sdk-cookie-policy input[type="submit"].ot-sdk-button-primary:focus,
      #ot-sdk-cookie-policy input[type="reset"].ot-sdk-button-primary:focus,
      #ot-sdk-cookie-policy input[type="button"].ot-sdk-button-primary:focus {
        color: #fff;
        background-color: #1eaedb;
        border-color: #1eaedb
      }

      #onetrust-banner-sdk input[type="email"],
      #onetrust-banner-sdk input[type="number"],
      #onetrust-banner-sdk input[type="search"],
      #onetrust-banner-sdk input[type="text"],
      #onetrust-banner-sdk input[type="tel"],
      #onetrust-banner-sdk input[type="url"],
      #onetrust-banner-sdk input[type="password"],
      #onetrust-banner-sdk textarea,
      #onetrust-banner-sdk select,
      #onetrust-pc-sdk input[type="email"],
      #onetrust-pc-sdk input[type="number"],
      #onetrust-pc-sdk input[type="search"],
      #onetrust-pc-sdk input[type="text"],
      #onetrust-pc-sdk input[type="tel"],
      #onetrust-pc-sdk input[type="url"],
      #onetrust-pc-sdk input[type="password"],
      #onetrust-pc-sdk textarea,
      #onetrust-pc-sdk select,
      #ot-sdk-cookie-policy input[type="email"],
      #ot-sdk-cookie-policy input[type="number"],
      #ot-sdk-cookie-policy input[type="search"],
      #ot-sdk-cookie-policy input[type="text"],
      #ot-sdk-cookie-policy input[type="tel"],
      #ot-sdk-cookie-policy input[type="url"],
      #ot-sdk-cookie-policy input[type="password"],
      #ot-sdk-cookie-policy textarea,
      #ot-sdk-cookie-policy select {
        height: 38px;
        padding: 6px 10px;
        background-color: #fff;
        border: 1px solid #d1d1d1;
        border-radius: 4px;
        box-shadow: none;
        box-sizing: border-box
      }

      #onetrust-banner-sdk input[type="email"],
      #onetrust-banner-sdk input[type="number"],
      #onetrust-banner-sdk input[type="search"],
      #onetrust-banner-sdk input[type="text"],
      #onetrust-banner-sdk input[type="tel"],
      #onetrust-banner-sdk input[type="url"],
      #onetrust-banner-sdk input[type="password"],
      #onetrust-banner-sdk textarea,
      #onetrust-pc-sdk input[type="email"],
      #onetrust-pc-sdk input[type="number"],
      #onetrust-pc-sdk input[type="search"],
      #onetrust-pc-sdk input[type="text"],
      #onetrust-pc-sdk input[type="tel"],
      #onetrust-pc-sdk input[type="url"],
      #onetrust-pc-sdk input[type="password"],
      #onetrust-pc-sdk textarea,
      #ot-sdk-cookie-policy input[type="email"],
      #ot-sdk-cookie-policy input[type="number"],
      #ot-sdk-cookie-policy input[type="search"],
      #ot-sdk-cookie-policy input[type="text"],
      #ot-sdk-cookie-policy input[type="tel"],
      #ot-sdk-cookie-policy input[type="url"],
      #ot-sdk-cookie-policy input[type="password"],
      #ot-sdk-cookie-policy textarea {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none
      }

      #onetrust-banner-sdk textarea,
      #onetrust-pc-sdk textarea,
      #ot-sdk-cookie-policy textarea {
        min-height: 65px;
        padding-top: 6px;
        padding-bottom: 6px
      }

      #onetrust-banner-sdk input[type="email"]:focus,
      #onetrust-banner-sdk input[type="number"]:focus,
      #onetrust-banner-sdk input[type="search"]:focus,
      #onetrust-banner-sdk input[type="text"]:focus,
      #onetrust-banner-sdk input[type="tel"]:focus,
      #onetrust-banner-sdk input[type="url"]:focus,
      #onetrust-banner-sdk input[type="password"]:focus,
      #onetrust-banner-sdk textarea:focus,
      #onetrust-banner-sdk select:focus,
      #onetrust-pc-sdk input[type="email"]:focus,
      #onetrust-pc-sdk input[type="number"]:focus,
      #onetrust-pc-sdk input[type="search"]:focus,
      #onetrust-pc-sdk input[type="text"]:focus,
      #onetrust-pc-sdk input[type="tel"]:focus,
      #onetrust-pc-sdk input[type="url"]:focus,
      #onetrust-pc-sdk input[type="password"]:focus,
      #onetrust-pc-sdk textarea:focus,
      #onetrust-pc-sdk select:focus,
      #ot-sdk-cookie-policy input[type="email"]:focus,
      #ot-sdk-cookie-policy input[type="number"]:focus,
      #ot-sdk-cookie-policy input[type="search"]:focus,
      #ot-sdk-cookie-policy input[type="text"]:focus,
      #ot-sdk-cookie-policy input[type="tel"]:focus,
      #ot-sdk-cookie-policy input[type="url"]:focus,
      #ot-sdk-cookie-policy input[type="password"]:focus,
      #ot-sdk-cookie-policy textarea:focus,
      #ot-sdk-cookie-policy select:focus {
        border: 1px solid #000;
        outline: 0
      }

      #onetrust-banner-sdk label,
      #onetrust-banner-sdk legend,
      #onetrust-pc-sdk label,
      #onetrust-pc-sdk legend,
      #ot-sdk-cookie-policy label,
      #ot-sdk-cookie-policy legend {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: 600
      }

      #onetrust-banner-sdk fieldset,
      #onetrust-pc-sdk fieldset,
      #ot-sdk-cookie-policy fieldset {
        padding: 0;
        border-width: 0
      }

      #onetrust-banner-sdk input[type="checkbox"],
      #onetrust-banner-sdk input[type="radio"],
      #onetrust-pc-sdk input[type="checkbox"],
      #onetrust-pc-sdk input[type="radio"],
      #ot-sdk-cookie-policy input[type="checkbox"],
      #ot-sdk-cookie-policy input[type="radio"] {
        display: inline
      }

      #onetrust-banner-sdk label>.label-body,
      #onetrust-pc-sdk label>.label-body,
      #ot-sdk-cookie-policy label>.label-body {
        display: inline-block;
        margin-left: 0.5rem;
        font-weight: normal
      }

      #onetrust-banner-sdk ul,
      #onetrust-pc-sdk ul,
      #ot-sdk-cookie-policy ul {
        list-style: circle inside
      }

      #onetrust-banner-sdk ol,
      #onetrust-pc-sdk ol,
      #ot-sdk-cookie-policy ol {
        list-style: decimal inside
      }

      #onetrust-banner-sdk ol,
      #onetrust-banner-sdk ul,
      #onetrust-pc-sdk ol,
      #onetrust-pc-sdk ul,
      #ot-sdk-cookie-policy ol,
      #ot-sdk-cookie-policy ul {
        padding-left: 0;
        margin-top: 0
      }

      #onetrust-banner-sdk ul ul,
      #onetrust-banner-sdk ul ol,
      #onetrust-banner-sdk ol ol,
      #onetrust-banner-sdk ol ul,
      #onetrust-pc-sdk ul ul,
      #onetrust-pc-sdk ul ol,
      #onetrust-pc-sdk ol ol,
      #onetrust-pc-sdk ol ul,
      #ot-sdk-cookie-policy ul ul,
      #ot-sdk-cookie-policy ul ol,
      #ot-sdk-cookie-policy ol ol,
      #ot-sdk-cookie-policy ol ul {
        margin: 1.5rem 0 1.5rem 3rem;
        font-size: 90%
      }

      #onetrust-banner-sdk li,
      #onetrust-pc-sdk li,
      #ot-sdk-cookie-policy li {
        margin-bottom: 1rem
      }

      #onetrust-banner-sdk code,
      #onetrust-pc-sdk code,
      #ot-sdk-cookie-policy code {
        padding: 0.2rem 0.5rem;
        margin: 0 0.2rem;
        font-size: 90%;
        white-space: nowrap;
        background: #f1f1f1;
        border: 1px solid #e1e1e1;
        border-radius: 4px
      }

      #onetrust-banner-sdk pre>code,
      #onetrust-pc-sdk pre>code,
      #ot-sdk-cookie-policy pre>code {
        display: block;
        padding: 1rem 1.5rem;
        white-space: pre
      }

      #onetrust-banner-sdk th,
      #onetrust-banner-sdk td,
      #onetrust-pc-sdk th,
      #onetrust-pc-sdk td,
      #ot-sdk-cookie-policy th,
      #ot-sdk-cookie-policy td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #e1e1e1
      }

      #onetrust-banner-sdk .ot-sdk-u-full-width,
      #onetrust-pc-sdk .ot-sdk-u-full-width,
      #ot-sdk-cookie-policy .ot-sdk-u-full-width {
        width: 100%;
        box-sizing: border-box
      }

      #onetrust-banner-sdk .ot-sdk-u-max-full-width,
      #onetrust-pc-sdk .ot-sdk-u-max-full-width,
      #ot-sdk-cookie-policy .ot-sdk-u-max-full-width {
        max-width: 100%;
        box-sizing: border-box
      }

      #onetrust-banner-sdk .ot-sdk-u-pull-right,
      #onetrust-pc-sdk .ot-sdk-u-pull-right,
      #ot-sdk-cookie-policy .ot-sdk-u-pull-right {
        float: right
      }

      #onetrust-banner-sdk .ot-sdk-u-pull-left,
      #onetrust-pc-sdk .ot-sdk-u-pull-left,
      #ot-sdk-cookie-policy .ot-sdk-u-pull-left {
        float: left
      }

      #onetrust-banner-sdk hr,
      #onetrust-pc-sdk hr,
      #ot-sdk-cookie-policy hr {
        margin-top: 3rem;
        margin-bottom: 3.5rem;
        border-width: 0;
        border-top: 1px solid #e1e1e1
      }

      #onetrust-banner-sdk .ot-sdk-container:after,
      #onetrust-banner-sdk .ot-sdk-row:after,
      #onetrust-banner-sdk .ot-sdk-u-cf,
      #onetrust-pc-sdk .ot-sdk-container:after,
      #onetrust-pc-sdk .ot-sdk-row:after,
      #onetrust-pc-sdk .ot-sdk-u-cf,
      #ot-sdk-cookie-policy .ot-sdk-container:after,
      #ot-sdk-cookie-policy .ot-sdk-row:after,
      #ot-sdk-cookie-policy .ot-sdk-u-cf {
        content: "";
        display: table;
        clear: both
      }

      #onetrust-banner-sdk .ot-sdk-row,
      #onetrust-pc-sdk .ot-sdk-row,
      #ot-sdk-cookie-policy .ot-sdk-row {
        margin: 0;
        max-width: none;
        display: block
      }

      #onetrust-banner-sdk {
        box-shadow: 0 0 18px rgba(0, 0, 0, .2)
      }

      #onetrust-banner-sdk.otFlat {
        position: fixed;
        z-index: 2147483645;
        bottom: 0;
        right: 0;
        left: 0;
        background-color: #fff;
        max-height: 90%;
        overflow-x: hidden;
        overflow-y: auto
      }

      #onetrust-banner-sdk.otRelFont {
        font-size: 1rem
      }

      #onetrust-banner-sdk>.ot-sdk-container {
        overflow: hidden
      }

      #onetrust-banner-sdk::-webkit-scrollbar {
        width: 11px
      }

      #onetrust-banner-sdk::-webkit-scrollbar-thumb {
        border-radius: 10px;
        background: #c1c1c1
      }

      #onetrust-banner-sdk {
        scrollbar-arrow-color: #c1c1c1;
        scrollbar-darkshadow-color: #c1c1c1;
        scrollbar-face-color: #c1c1c1;
        scrollbar-shadow-color: #c1c1c1
      }

      #onetrust-banner-sdk #onetrust-policy {
        margin: 1.25em 0 .625em 2em;
        overflow: hidden
      }

      #onetrust-banner-sdk #onetrust-policy .ot-gv-list-handler {
        float: left;
        font-size: .82em;
        padding: 0;
        margin-bottom: 0;
        border: 0;
        line-height: normal;
        height: auto;
        width: auto
      }

      #onetrust-banner-sdk #onetrust-policy-title {
        font-size: 1.2em;
        line-height: 1.3;
        margin-bottom: 10px
      }

      #onetrust-banner-sdk #onetrust-policy-text {
        clear: both;
        text-align: left;
        font-size: .88em;
        line-height: 1.4
      }

      #onetrust-banner-sdk #onetrust-policy-text * {
        font-size: inherit;
        line-height: inherit
      }

      #onetrust-banner-sdk #onetrust-policy-text a {
        font-weight: bold;
        margin-left: 5px
      }

      #onetrust-banner-sdk #onetrust-policy-title,
      #onetrust-banner-sdk #onetrust-policy-text {
        color: dimgray;
        float: left
      }

      #onetrust-banner-sdk #onetrust-button-group-parent {
        min-height: 1px;
        text-align: center
      }

      #onetrust-banner-sdk #onetrust-button-group {
        display: inline-block
      }

      #onetrust-banner-sdk #onetrust-accept-btn-handler,
      #onetrust-banner-sdk #onetrust-reject-all-handler,
      #onetrust-banner-sdk #onetrust-pc-btn-handler {
        background-color: #68b631;
        color: #fff;
        border-color: #68b631;
        margin-right: 1em;
        min-width: 125px;
        height: auto;
        white-space: normal;
        word-break: break-word;
        word-wrap: break-word;
        padding: 12px 10px;
        line-height: 1.2;
        font-size: .813em;
        font-weight: 600
      }

      #onetrust-banner-sdk #onetrust-pc-btn-handler.cookie-setting-link {
        background-color: #fff;
        border: none;
        color: #68b631;
        text-decoration: underline;
        padding-left: 0;
        padding-right: 0
      }

      #onetrust-banner-sdk .onetrust-close-btn-ui {
        width: 44px;
        height: 44px;
        background-size: 12px;
        border: none;
        position: relative;
        margin: auto;
        padding: 0
      }

      #onetrust-banner-sdk .banner_logo {
        display: none
      }

      #onetrust-banner-sdk .ot-b-addl-desc {
        clear: both;
        float: left;
        display: block
      }

      #onetrust-banner-sdk #banner-options {
        float: left;
        display: table;
        margin-right: 0;
        margin-left: 1em;
        width: calc(100% - 1em)
      }

      #onetrust-banner-sdk .banner-option-input {
        cursor: pointer;
        width: auto;
        height: auto;
        border: none;
        padding: 0;
        padding-right: 3px;
        margin: 0 0 10px;
        font-size: .82em;
        line-height: 1.4
      }

      #onetrust-banner-sdk .banner-option-input * {
        pointer-events: none;
        font-size: inherit;
        line-height: inherit
      }

      #onetrust-banner-sdk .banner-option-input[aria-expanded=true]~.banner-option-details {
        display: block;
        height: auto
      }

      #onetrust-banner-sdk .banner-option-input[aria-expanded=true] .ot-arrow-container {
        transform: rotate(90deg)
      }

      #onetrust-banner-sdk .banner-option {
        margin-bottom: 12px;
        margin-left: 0;
        border: none;
        float: left;
        padding: 0
      }

      #onetrust-banner-sdk .banner-option:first-child {
        padding-left: 2px
      }

      #onetrust-banner-sdk .banner-option:not(:first-child) {
        padding: 0;
        border: none
      }

      #onetrust-banner-sdk .banner-option-header {
        cursor: pointer;
        display: inline-block
      }

      #onetrust-banner-sdk .banner-option-header :first-child {
        color: dimgray;
        font-weight: bold;
        float: left
      }

      #onetrust-banner-sdk .banner-option-header .ot-arrow-container {
        display: inline-block;
        border-top: 6px solid transparent;
        border-bottom: 6px solid transparent;
        border-left: 6px solid dimgray;
        margin-left: 10px;
        vertical-align: middle
      }

      #onetrust-banner-sdk .banner-option-details {
        display: none;
        font-size: .83em;
        line-height: 1.5;
        padding: 10px 0px 5px 10px;
        margin-right: 10px;
        height: 0px
      }

      #onetrust-banner-sdk .banner-option-details * {
        font-size: inherit;
        line-height: inherit;
        color: dimgray
      }

      #onetrust-banner-sdk .ot-arrow-container,
      #onetrust-banner-sdk .banner-option-details {
        transition: all 300ms ease-in 0s;
        -webkit-transition: all 300ms ease-in 0s;
        -moz-transition: all 300ms ease-in 0s;
        -o-transition: all 300ms ease-in 0s
      }

      #onetrust-banner-sdk .ot-dpd-container {
        float: left
      }

      #onetrust-banner-sdk .ot-dpd-title {
        margin-bottom: 10px
      }

      #onetrust-banner-sdk .ot-dpd-title,
      #onetrust-banner-sdk .ot-dpd-desc {
        font-size: .88em;
        line-height: 1.4;
        color: dimgray
      }

      #onetrust-banner-sdk .ot-dpd-title *,
      #onetrust-banner-sdk .ot-dpd-desc * {
        font-size: inherit;
        line-height: inherit
      }

      #onetrust-banner-sdk.ot-iab-2 #onetrust-policy-text * {
        margin-bottom: 0
      }

      #onetrust-banner-sdk.ot-iab-2 .onetrust-vendors-list-handler {
        display: block;
        margin-left: 0;
        margin-top: 5px;
        clear: both;
        margin-bottom: 0;
        padding: 0;
        border: 0;
        height: auto;
        width: auto
      }

      #onetrust-banner-sdk.ot-iab-2 #onetrust-button-group button {
        display: block
      }

      #onetrust-banner-sdk.ot-close-btn-link {
        padding-top: 25px
      }

      #onetrust-banner-sdk.ot-close-btn-link #onetrust-close-btn-container {
        top: 15px;
        transform: none;
        right: 15px
      }

      #onetrust-banner-sdk.ot-close-btn-link #onetrust-close-btn-container button {
        padding: 0;
        white-space: pre-wrap;
        border: none;
        height: auto;
        line-height: 1.5;
        text-decoration: underline;
        font-size: .69em
      }

      #onetrust-banner-sdk #onetrust-policy-text,
      #onetrust-banner-sdk .ot-dpd-desc,
      #onetrust-banner-sdk .ot-b-addl-desc {
        font-size: .813em;
        line-height: 1.5
      }

      #onetrust-banner-sdk .ot-dpd-desc {
        margin-bottom: 10px
      }

      #onetrust-banner-sdk .ot-dpd-desc>.ot-b-addl-desc {
        margin-top: 10px;
        margin-bottom: 10px;
        font-size: 1em
      }

      @media only screen and (max-width: 425px) {
        #onetrust-banner-sdk #onetrust-close-btn-container {
          position: absolute;
          top: 10px;
          right: 10px
        }

        #onetrust-banner-sdk #onetrust-policy {
          margin-left: 0
        }

        #onetrust-banner-sdk #onetrust-button-group {
          display: block
        }

        #onetrust-banner-sdk #onetrust-accept-btn-handler,
        #onetrust-banner-sdk #onetrust-reject-all-handler,
        #onetrust-banner-sdk #onetrust-pc-btn-handler {
          width: 100%
        }

        #onetrust-banner-sdk .onetrust-close-btn-ui {
          top: auto;
          transform: none
        }

        #onetrust-banner-sdk #onetrust-policy-title {
          display: inline;
          float: none
        }

        #onetrust-banner-sdk #banner-options {
          margin: 0;
          padding: 0;
          width: 100%
        }
      }

      @media only screen and (min-width: 426px)and (max-width: 896px) {
        #onetrust-banner-sdk #onetrust-close-btn-container {
          position: absolute;
          top: 0;
          right: 0
        }

        #onetrust-banner-sdk #onetrust-policy {
          margin-left: 1em;
          margin-right: 1em
        }

        #onetrust-banner-sdk .onetrust-close-btn-ui {
          top: 10px;
          right: 10px
        }

        #onetrust-banner-sdk:not(.ot-iab-2) #onetrust-group-container {
          width: 95%
        }

        #onetrust-banner-sdk.ot-iab-2 #onetrust-group-container {
          width: 100%
        }

        #onetrust-banner-sdk #onetrust-button-group-parent {
          width: 100%;
          position: relative;
          margin-left: 0
        }

        #onetrust-banner-sdk #onetrust-button-group button {
          display: inline-block
        }

        #onetrust-banner-sdk #onetrust-button-group {
          margin-right: 0;
          text-align: center
        }

        #onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler {
          float: left
        }

        #onetrust-banner-sdk .has-reject-all-button #onetrust-reject-all-handler,
        #onetrust-banner-sdk .has-reject-all-button #onetrust-accept-btn-handler {
          float: right
        }

        #onetrust-banner-sdk .has-reject-all-button #onetrust-button-group {
          width: calc(100% - 2em);
          margin-right: 0
        }

        #onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler.cookie-setting-link {
          padding-left: 0px;
          text-align: left
        }

        #onetrust-banner-sdk.ot-buttons-fw .ot-sdk-three button {
          width: 100%;
          text-align: center
        }

        #onetrust-banner-sdk.ot-buttons-fw #onetrust-button-group-parent button {
          float: none
        }

        #onetrust-banner-sdk.ot-buttons-fw #onetrust-pc-btn-handler.cookie-setting-link {
          text-align: center
        }
      }

      @media only screen and (min-width: 550px) {
        #onetrust-banner-sdk .banner-option:not(:first-child) {
          border-left: 1px solid #d8d8d8;
          padding-left: 25px
        }
      }

      @media only screen and (min-width: 425px)and (max-width: 550px) {

        #onetrust-banner-sdk.ot-iab-2 #onetrust-button-group,
        #onetrust-banner-sdk.ot-iab-2 #onetrust-policy,
        #onetrust-banner-sdk.ot-iab-2 .banner-option {
          width: 100%
        }
      }

      @media only screen and (min-width: 769px) {
        #onetrust-banner-sdk #onetrust-button-group {
          margin-right: 30%
        }

        #onetrust-banner-sdk #banner-options {
          margin-left: 2em;
          margin-right: 5em;
          margin-bottom: 1.25em;
          width: calc(100% - 7em)
        }
      }

      @media only screen and (min-width: 897px)and (max-width: 1023px) {
        #onetrust-banner-sdk.vertical-align-content #onetrust-button-group-parent {
          position: absolute;
          top: 50%;
          left: 75%;
          transform: translateY(-50%)
        }

        #onetrust-banner-sdk #onetrust-close-btn-container {
          top: 50%;
          margin: auto;
          transform: translate(-50%, -50%);
          position: absolute;
          padding: 0;
          right: 0
        }

        #onetrust-banner-sdk #onetrust-close-btn-container button {
          position: relative;
          margin: 0;
          right: -22px;
          top: 2px
        }
      }

      @media only screen and (min-width: 1024px) {
        #onetrust-banner-sdk #onetrust-close-btn-container {
          top: 50%;
          margin: auto;
          transform: translate(-50%, -50%);
          position: absolute;
          right: 0
        }

        #onetrust-banner-sdk #onetrust-close-btn-container button {
          right: -12px
        }

        #onetrust-banner-sdk #onetrust-policy {
          margin-left: 2em
        }

        #onetrust-banner-sdk.vertical-align-content #onetrust-button-group-parent {
          position: absolute;
          top: 50%;
          left: 60%;
          transform: translateY(-50%)
        }

        #onetrust-banner-sdk.ot-iab-2 #onetrust-policy-title {
          width: 50%
        }

        #onetrust-banner-sdk.ot-iab-2 #onetrust-policy-text,
        #onetrust-banner-sdk.ot-iab-2 :not(.ot-dpd-desc)>.ot-b-addl-desc {
          margin-bottom: 1em;
          width: 50%;
          border-right: 1px solid #d8d8d8;
          padding-right: 1rem
        }

        #onetrust-banner-sdk.ot-iab-2 #onetrust-policy-text {
          margin-bottom: 0;
          padding-bottom: 1em
        }

        #onetrust-banner-sdk.ot-iab-2 :not(.ot-dpd-desc)>.ot-b-addl-desc {
          margin-bottom: 0;
          padding-bottom: 1em
        }

        #onetrust-banner-sdk.ot-iab-2 .ot-dpd-container {
          width: 45%;
          padding-left: 1rem;
          display: inline-block;
          float: none
        }

        #onetrust-banner-sdk.ot-iab-2 .ot-dpd-title {
          line-height: 1.7
        }

        #onetrust-banner-sdk.ot-iab-2 #onetrust-button-group-parent {
          left: auto;
          right: 4%;
          margin-left: 0
        }

        #onetrust-banner-sdk.ot-iab-2 #onetrust-button-group button {
          display: block
        }

        #onetrust-banner-sdk:not(.ot-iab-2) #onetrust-button-group-parent {
          margin: auto;
          width: 30%
        }

        #onetrust-banner-sdk:not(.ot-iab-2) #onetrust-group-container {
          width: 60%
        }

        #onetrust-banner-sdk #onetrust-button-group {
          margin-right: auto
        }

        #onetrust-banner-sdk #onetrust-accept-btn-handler,
        #onetrust-banner-sdk #onetrust-reject-all-handler,
        #onetrust-banner-sdk #onetrust-pc-btn-handler {
          margin-top: 1em
        }
      }

      @media only screen and (min-width: 890px) {
        #onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group-parent {
          padding-left: 3%;
          padding-right: 4%;
          margin-left: 0
        }

        #onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group {
          margin-right: 0;
          margin-top: 1.25em;
          width: 100%
        }

        #onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group button {
          width: 100%;
          margin-bottom: 5px;
          margin-top: 5px
        }

        #onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group button:last-of-type {
          margin-bottom: 20px
        }
      }

      @media only screen and (min-width: 1280px) {
        #onetrust-banner-sdk:not(.ot-iab-2) #onetrust-group-container {
          width: 55%
        }

        #onetrust-banner-sdk:not(.ot-iab-2) #onetrust-button-group-parent {
          width: 44%;
          padding-left: 2%;
          padding-right: 2%
        }

        #onetrust-banner-sdk:not(.ot-iab-2).vertical-align-content #onetrust-button-group-parent {
          position: absolute;
          left: 55%
        }
      }

      #onetrust-consent-sdk #onetrust-banner-sdk {
        background-color: #FFFFFF;
      }

      #onetrust-consent-sdk #onetrust-policy-title,
      #onetrust-consent-sdk #onetrust-policy-text,
      #onetrust-consent-sdk .ot-b-addl-desc,
      #onetrust-consent-sdk .ot-dpd-desc,
      #onetrust-consent-sdk .ot-dpd-title,
      #onetrust-consent-sdk #onetrust-policy-text *:not(.onetrust-vendors-list-handler),
      #onetrust-consent-sdk .ot-dpd-desc *:not(.onetrust-vendors-list-handler),
      #onetrust-consent-sdk #onetrust-banner-sdk #banner-options *,
      #onetrust-banner-sdk .ot-cat-header {
        color: #4A4A4A;
      }

      #onetrust-consent-sdk #onetrust-banner-sdk .banner-option-details {
        background-color: #FFF;
      }

      #onetrust-consent-sdk #onetrust-banner-sdk a[href],
      #onetrust-consent-sdk #onetrust-banner-sdk a[href] font,
      #onetrust-consent-sdk #onetrust-banner-sdk .ot-link-btn {
        color: #3A913F;
      }

      #onetrust-consent-sdk #onetrust-accept-btn-handler,
      #onetrust-banner-sdk #onetrust-reject-all-handler {
        background-color: #FFF;
        border-color: #FFF;
        color: #4A4A4A;
      }

      #onetrust-consent-sdk #onetrust-pc-btn-handler,
      #onetrust-consent-sdk #onetrust-pc-btn-handler.cookie-setting-link {
        color: #4A4A4A;
        border-color: #4A4A4A;
        background-color:
          #FFFFFF;
      }

      #onetrust-banner-sdk #onetrust-policy-title {
        font-size: 22px;
        letter-spacing: 0;
        line-height: 28px;
      }

      #onetrust-banner-sdk #onetrust-policy-text {
        font-size: 12px;
        letter-spacing: 0;
        line-height: 16px;
      }

      #onetrust-banner-sdk .ot-sdk-row,
      #ot-sdk-cookie-policy .ot-sdk-row {
        margin: 0 0 0 136px;
        max-width: none;
        display: flex;
        flex-flow: column;
        flex-wrap: wrap;
      }

      .ot-sdk-container>.ot-sdk-row::before {
        content: url(https://www.cetelem.fr/rsc/contrib/image/cetelem/cookie/Credito-cookie.jpg);
        left: 40px;
        bottom: 136px;
        position: absolute;
      }

      #onetrust-group-container {
        width: 100%;
      }

      #onetrust-button-group-parent {
        width: auto;
        padding-left: 0 !important;
        margin-left: 0 !important;
      }

      #onetrust-banner-sdk *:focus,
      #onetrust-banner-sdk :not(.ot-leg-btn-container)>button:focus {
        outline: none;
      }

      #onetrust-banner-sdk p {
        margin: 0 0 10px 0;
      }

      #onetrust-banner-sdk>div,
      #onetrust-banner-sdk>.ot-sdk-container {
        max-width: 1140px;
        margin: 0 auto;
      }

      @media only screen and (min-width: 701px) {
        #onetrust-banner-sdk.vertical-align-content #onetrust-button-group-parent {
          position: inherit !important;
          transform: none;
          width: 100% !important;
        }
      }

      #onetrust-banner-sdk #onetrust-button-group {
        display: flex;
        margin-left: 0;
      }

      @media only screen and (min-width: 700px) {
        #onetrust-banner-sdk:not(.ot-iab-2) #onetrust-group-container {
          width: 100%;
          padding-right: 24px;
          margin-top: 48px;
        }
      }

      #onetrust-banner-sdk #onetrust-reject-all-handler {
        position: absolute;
        top: 0;
        right: 24px;
        font-weight: bold;
        font-size: 15px;
        letter-spacing: 0;
        text-align: right;
        margin: 12px 0 0 0;
        border-radius: 4px;
      }

      button#onetrust-reject-all-handler::after {
        content: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iOHB4IiBoZWlnaHQ9IjE0cHgiIHZpZXdCb3g9IjAgMCA4IDE0IiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPHRpdGxlPkZCNTYxQTExLTI4MTAtNEVFNy1CMkMwLTgxQkRBMjQwNzM2MjwvdGl0bGU+CiAgICA8ZGVmcz48L2RlZnM+CiAgICA8ZyBpZD0iVjUiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSIjNEE0QTRBIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxnIGlkPSJbVjRdLVtkZXNrdG9wXS1CYW5kZWF1LWNvbnNlbnRlbWVudC0wMSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTk4OC4wMDAwMDAsIC0yNjAuMDAwMDAwKSI+CiAgICAgICAgICAgIDxnIGlkPSJCYW5kZWF1LWNvb2tpZXMiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAuMDAwMDAwLCAyMzIuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICA8ZyBpZD0iQnV0dG9uLWNvbnRpbnVlci1zYW5zLWFjY2VwdGVyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg3OTkuMDAwMDAwLCAyNC4wMDAwMDApIj4KICAgICAgICAgICAgICAgICAgICA8ZyBpZD0i8J+OqC1Db2xvciIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTg5LjAwMDAwMCwgNC4wMDAwMDApIj4KICAgICAgICAgICAgICAgICAgICAgICAgPGc+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMy43NSw4LjY4OTMzOTgzIEw5LjIxOTY2OTkxLDMuMjE5NjY5OTEgQzkuNTEyNTYzMTMsMi45MjY3NzY3IDkuOTg3NDM2ODcsMi45MjY3NzY3IDEwLjI4MDMzMDEsMy4yMTk2Njk5MSBDMTAuNTczMjIzMywzLjUxMjU2MzEzIDEwLjU3MzIyMzMsMy45ODc0MzY4NyAxMC4yODAzMzAxLDQuMjgwMzMwMDkgTDQuMjgwMzMwMDksMTAuMjgwMzMwMSBDMy45ODc0MzY4NywxMC41NzMyMjMzIDMuNTEyNTYzMTMsMTAuNTczMjIzMyAzLjIxOTY2OTkxLDEwLjI4MDMzMDEgTC0yLjc4MDMzMDA5LDQuMjgwMzMwMDkgQy0zLjA3MzIyMzMsMy45ODc0MzY4NyAtMy4wNzMyMjMzLDMuNTEyNTYzMTMgLTIuNzgwMzMwMDksMy4yMTk2Njk5MSBDLTIuNDg3NDM2ODcsMi45MjY3NzY3IC0yLjAxMjU2MzEzLDIuOTI2Nzc2NyAtMS43MTk2Njk5MSwzLjIxOTY2OTkxIEwzLjc1LDguNjg5MzM5ODMgWiIgZmlsbD0iIzRBNEE0QSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMy43NTAwMDAsIDYuNzUwMDAwKSByb3RhdGUoLTkwLjAwMDAwMCkgdHJhbnNsYXRlKC0zLjc1MDAwMCwgLTYuNzUwMDAwKSAiPjwvcGF0aD4KICAgICAgICAgICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICAgICAgICAgIDwvZz4KICAgICAgICAgICAgICAgIDwvZz4KICAgICAgICAgICAgPC9nPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+);
        margin-left: 8px;
        vertical-align: middle;
        display: inline-block;
        line-height: normal;
      }

      #onetrust-banner-sdk #onetrust-accept-btn-handler,
      #onetrust-banner-sdk #onetrust-pc-btn-handler {
        box-sizing: border-box;
        border: 2px solid #4A4A4A;
        border-radius: 4px;
        font-size: 12px;
        margin: 0 15px 32px 0 !important;
        padding: 8px 16px !important;
        width: auto !important;
      }

      #onetrust-banner-sdk #onetrust-accept-btn-handler:hover,
      #onetrust-banner-sdk #onetrust-pc-btn-handler:hover,
      #onetrust-banner-sdk #onetrust-accept-btn-handler:focus,
      #onetrust-banner-sdk #onetrust-pc-btn-handler:focus,
      #onetrust-banner-sdk #onetrust-reject-all-handler:hover,
      #onetrust-banner-sdk #onetrust-reject-all-handler:focus,
      #onetrust-consent-sdk #onetrust-banner-sdk a[href]:hover,
      #onetrust-consent-sdk #onetrust-banner-sdk a[href]:focus {
        border: 2px solid #3a913f;
        opacity: 1 !important;
        color: #3a913f;
      }

      #onetrust-policy,
      #onetrust-button-group {
        margin-left: 2em !important;
      }

      /* MOBILE CONFIG */
      @media only screen and (max-width: 700px) {

        #onetrust-banner-sdk .ot-sdk-row,
        #ot-sdk-cookie-policy .ot-sdk-row {
          margin: 0 !important;
          max-width: none;
          display: flex;
          flex-flow: column;
          flex-wrap: nowrap;
          height: 100%;
          overflow: hidden;
        }

        #onetrust-banner-sdk #onetrust-accept-btn-handler,
        #onetrust-banner-sdk #onetrust-pc-btn-handler {
          width: 100% !important;
          margin: 0 !important;
          height: 32px;
        }

        #onetrust-policy,
        #onetrust-button-group {
          margin-left: 0 !important;
        }

        .ot-sdk-row::before {
          display: none;
        }

        #onetrust-consent-sdk #onetrust-banner-sdk {
          height: 75%;
        }

        #onetrust-banner-sdk>div {
          height: 100%;
        }

        #onetrust-banner-sdk .ot-sdk-container {
          height: 100%;
        }

        #onetrust-banner-sdk #onetrust-button-group {
          display: flex;
          width: 100% !important;
          margin: 0 !important;
          flex-flow: column;
          justify-content: space-between;
          height: 72px;
          padding: 19px 0 16px 0;
        }

        #onetrust-banner-sdk #onetrust-group-container {
          margin-top: 52px;
          min-height: 0;
          overflow-y: scroll;
          flex: 1;
          padding: 0 20px;
          scroll-behavior: auto;
        }

        #onetrust-banner-sdk #onetrust-policy {
          margin-top: 0;
          padding-bottom: 30px;
        }

        #onetrust-banner-sdk #onetrust-button-group-parent {
          min-height: 0;
          flex-grow: 0;
          padding: 0 20px !important;
          position: static !important;
        }

        #onetrust-banner-sdk #onetrust-reject-all-handler {
          right: 16px;
          margin: 16px 0 0 0;
          padding: 0;
          width: auto;
        }

        #onetrust-banner-sdk .ot-sdk-container {
          padding: 0;
        }

        #onetrust-banner-sdk .ot-sdk-container::before {
          position: absolute;
          content: "";
          bottom: 107px;
          width: 100%;
          height: 40px;
          background: linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, rgb(255, 255, 255) 100%);
          display: block;
        }

        #onetrust-consent-sdk #onetrust-policy-title {
          margin-bottom: 10px;
          float: left;
        }
      }

      #onetrust-pc-sdk.otPcCenter {
        overflow: hidden;
        position: fixed;
        margin: 0 auto;
        top: 5%;
        right: 0;
        left: 0;
        width: 40%;
        max-width: 575px;
        min-width: 575px;
        border-radius: 2.5px;
        z-index: 2147483647;
        background-color: #fff;
        -webkit-box-shadow: 0px 2px 10px -3px #999;
        -moz-box-shadow: 0px 2px 10px -3px #999;
        box-shadow: 0px 2px 10px -3px #999
      }

      #onetrust-pc-sdk.otPcCenter[dir=rtl] {
        right: 0;
        left: 0
      }

      #onetrust-pc-sdk.otRelFont {
        font-size: 1rem
      }

      #onetrust-pc-sdk #ot-addtl-venlst .ot-arw-cntr,
      #onetrust-pc-sdk #ot-addtl-venlst .ot-plus-minus,
      #onetrust-pc-sdk .ot-hide-tgl {
        visibility: hidden
      }

      #onetrust-pc-sdk #ot-addtl-venlst .ot-arw-cntr *,
      #onetrust-pc-sdk #ot-addtl-venlst .ot-plus-minus *,
      #onetrust-pc-sdk .ot-hide-tgl * {
        visibility: hidden
      }

      #onetrust-pc-sdk #ot-gn-venlst .ot-ven-item .ot-acc-hdr {
        min-height: 40px
      }

      #onetrust-pc-sdk .ot-pc-header {
        height: 39px;
        padding: 10px 0 10px 30px;
        border-bottom: 1px solid #e9e9e9
      }

      #onetrust-pc-sdk #ot-pc-title,
      #onetrust-pc-sdk #ot-category-title,
      #onetrust-pc-sdk .ot-cat-header,
      #onetrust-pc-sdk #ot-lst-title,
      #onetrust-pc-sdk .ot-ven-hdr .ot-ven-name,
      #onetrust-pc-sdk .ot-always-active {
        font-weight: bold;
        color: dimgray
      }

      #onetrust-pc-sdk .ot-cat-header {
        float: left;
        font-weight: 600;
        font-size: .875em;
        line-height: 1.5;
        max-width: 90%;
        vertical-align: middle
      }

      #onetrust-pc-sdk .ot-always-active-group .ot-cat-header {
        width: 55%;
        font-weight: 700
      }

      #onetrust-pc-sdk .ot-cat-item p {
        clear: both;
        float: left;
        margin-top: 10px;
        margin-bottom: 5px;
        line-height: 1.5;
        font-size: .812em;
        color: dimgray
      }

      #onetrust-pc-sdk .ot-close-icon {
        height: 44px;
        width: 44px;
        background-size: 10px
      }

      #onetrust-pc-sdk #ot-pc-title {
        float: left;
        font-size: 1em;
        line-height: 1.5;
        margin-bottom: 10px;
        margin-top: 10px;
        width: 100%
      }

      #onetrust-pc-sdk #accept-recommended-btn-handler {
        margin-right: 10px;
        margin-bottom: 25px;
        outline-offset: -1px
      }

      #onetrust-pc-sdk #ot-pc-desc {
        clear: both;
        width: 100%;
        font-size: .812em;
        line-height: 1.5;
        margin-bottom: 25px
      }

      #onetrust-pc-sdk #ot-pc-desc a {
        margin-left: 5px
      }

      #onetrust-pc-sdk #ot-pc-desc * {
        font-size: inherit;
        line-height: inherit
      }

      #onetrust-pc-sdk #ot-pc-desc ul li {
        padding: 10px 0px
      }

      #onetrust-pc-sdk a {
        color: #656565;
        cursor: pointer
      }

      #onetrust-pc-sdk a:hover {
        color: #3860be
      }

      #onetrust-pc-sdk label {
        margin-bottom: 0
      }

      #onetrust-pc-sdk #vdr-lst-dsc {
        font-size: .812em;
        line-height: 1.5;
        padding: 10px 15px 5px 15px
      }

      #onetrust-pc-sdk button {
        max-width: 394px;
        padding: 12px 30px;
        line-height: 1;
        word-break: break-word;
        word-wrap: break-word;
        white-space: normal;
        font-weight: bold;
        height: auto
      }

      #onetrust-pc-sdk .ot-link-btn {
        padding: 0;
        margin-bottom: 0;
        border: 0;
        font-weight: normal;
        line-height: normal;
        width: auto;
        height: auto
      }

      #onetrust-pc-sdk #ot-pc-content {
        position: absolute;
        overflow-y: scroll;
        padding-left: 0px;
        padding-right: 30px;
        top: 60px;
        bottom: 110px;
        margin: 1px 3px 0 30px;
        width: calc(100% - 63px)
      }

      #onetrust-pc-sdk .ot-cat-grp .ot-always-active {
        float: right;
        clear: none;
        color: #3860be;
        margin: 0;
        font-size: .813em;
        line-height: 1.3
      }

      #onetrust-pc-sdk .ot-pc-scrollbar::-webkit-scrollbar-track {
        margin-right: 20px
      }

      #onetrust-pc-sdk .ot-pc-scrollbar::-webkit-scrollbar {
        width: 11px
      }

      #onetrust-pc-sdk .ot-pc-scrollbar::-webkit-scrollbar-thumb {
        border-radius: 10px;
        background: #d8d8d8
      }

      #onetrust-pc-sdk input[type=checkbox]:focus+.ot-acc-hdr {
        outline: #000 1px solid
      }

      #onetrust-pc-sdk .ot-pc-scrollbar {
        scrollbar-arrow-color: #d8d8d8;
        scrollbar-darkshadow-color: #d8d8d8;
        scrollbar-face-color: #d8d8d8;
        scrollbar-shadow-color: #d8d8d8
      }

      #onetrust-pc-sdk .save-preference-btn-handler {
        margin-right: 20px
      }

      #onetrust-pc-sdk .ot-pc-refuse-all-handler {
        margin-right: 10px
      }

      #onetrust-pc-sdk #ot-pc-desc .privacy-notice-link {
        margin-left: 0
      }

      #onetrust-pc-sdk .ot-subgrp-cntr {
        display: inline-block;
        clear: both;
        width: 100%;
        padding-top: 15px
      }

      #onetrust-pc-sdk .ot-switch+.ot-subgrp-cntr {
        padding-top: 10px
      }

      #onetrust-pc-sdk ul.ot-subgrps {
        margin: 0;
        font-size: initial
      }

      #onetrust-pc-sdk ul.ot-subgrps li p,
      #onetrust-pc-sdk ul.ot-subgrps li h5 {
        font-size: .813em;
        line-height: 1.4;
        color: dimgray
      }

      #onetrust-pc-sdk ul.ot-subgrps .ot-switch {
        min-height: auto
      }

      #onetrust-pc-sdk ul.ot-subgrps .ot-switch-nob {
        top: 0
      }

      #onetrust-pc-sdk ul.ot-subgrps .ot-acc-hdr {
        display: inline-block;
        width: 100%
      }

      #onetrust-pc-sdk ul.ot-subgrps .ot-acc-txt {
        margin: 0
      }

      #onetrust-pc-sdk ul.ot-subgrps li {
        padding: 0;
        border: none
      }

      #onetrust-pc-sdk ul.ot-subgrps li h5 {
        position: relative;
        top: 5px;
        font-weight: bold;
        margin-bottom: 0;
        float: left
      }

      #onetrust-pc-sdk li.ot-subgrp {
        margin-left: 20px;
        overflow: auto
      }

      #onetrust-pc-sdk li.ot-subgrp>h5 {
        width: calc(100% - 100px)
      }

      #onetrust-pc-sdk .ot-cat-item p>ul,
      #onetrust-pc-sdk li.ot-subgrp p>ul {
        margin: 0px;
        list-style: disc;
        margin-left: 15px;
        font-size: inherit
      }

      #onetrust-pc-sdk .ot-cat-item p>ul li,
      #onetrust-pc-sdk li.ot-subgrp p>ul li {
        font-size: inherit;
        padding-top: 10px;
        padding-left: 0px;
        padding-right: 0px;
        border: none
      }

      #onetrust-pc-sdk .ot-cat-item p>ul li:last-child,
      #onetrust-pc-sdk li.ot-subgrp p>ul li:last-child {
        padding-bottom: 10px
      }

      #onetrust-pc-sdk .ot-pc-logo {
        height: 40px;
        width: 120px;
        display: inline-block
      }

      #onetrust-pc-sdk .ot-pc-footer {
        position: absolute;
        bottom: 0px;
        width: 100%;
        max-height: 160px;
        border-top: 1px solid #d8d8d8
      }

      #onetrust-pc-sdk.ot-ftr-stacked .ot-pc-refuse-all-handler {
        margin-bottom: 0px
      }

      #onetrust-pc-sdk.ot-ftr-stacked #ot-pc-content {
        bottom: 160px
      }

      #onetrust-pc-sdk.ot-ftr-stacked .ot-pc-footer button {
        width: 100%;
        max-width: none
      }

      #onetrust-pc-sdk.ot-ftr-stacked .ot-btn-container {
        margin: 0 30px;
        width: calc(100% - 60px);
        padding-right: 0
      }

      #onetrust-pc-sdk .ot-pc-footer-logo {
        height: 30px;
        width: 100%;
        text-align: right;
        background: #f4f4f4
      }

      #onetrust-pc-sdk .ot-pc-footer-logo a {
        display: inline-block;
        margin-top: 5px;
        margin-right: 10px
      }

      #onetrust-pc-sdk[dir=rtl] .ot-pc-footer-logo {
        direction: rtl
      }

      #onetrust-pc-sdk[dir=rtl] .ot-pc-footer-logo a {
        margin-right: 25px
      }

      #onetrust-pc-sdk .ot-tgl {
        float: right;
        position: relative;
        z-index: 1
      }

      #onetrust-pc-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob {
        background-color: #cddcf2;
        border: 1px solid #3860be
      }

      #onetrust-pc-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob:before {
        -webkit-transform: translateX(20px);
        -ms-transform: translateX(20px);
        transform: translateX(20px);
        background-color: #3860be;
        border-color: #3860be
      }

      #onetrust-pc-sdk .ot-tgl input:focus+.ot-switch {
        outline: #000 solid 1px
      }

      #onetrust-pc-sdk .ot-switch {
        position: relative;
        display: inline-block;
        width: 45px;
        height: 25px
      }

      #onetrust-pc-sdk .ot-switch-nob {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #f2f1f1;
        border: 1px solid #ddd;
        transition: all .2s ease-in 0s;
        -moz-transition: all .2s ease-in 0s;
        -o-transition: all .2s ease-in 0s;
        -webkit-transition: all .2s ease-in 0s;
        border-radius: 20px
      }

      #onetrust-pc-sdk .ot-switch-nob:before {
        position: absolute;
        content: "";
        height: 21px;
        width: 21px;
        bottom: 1px;
        background-color: #7d7d7d;
        -webkit-transition: .4s;
        transition: .4s;
        border-radius: 20px
      }

      #onetrust-pc-sdk .ot-chkbox input:checked~label::before {
        background-color: #3860be
      }

      #onetrust-pc-sdk .ot-chkbox input+label::after {
        content: none;
        color: #fff
      }

      #onetrust-pc-sdk .ot-chkbox input:checked+label::after {
        content: ""
      }

      #onetrust-pc-sdk .ot-chkbox input:focus+label::before {
        outline-style: solid;
        outline-width: 2px;
        outline-style: auto
      }

      #onetrust-pc-sdk .ot-chkbox label {
        position: relative;
        display: inline-block;
        padding-left: 30px;
        cursor: pointer;
        font-weight: 500
      }

      #onetrust-pc-sdk .ot-chkbox label::before,
      #onetrust-pc-sdk .ot-chkbox label::after {
        position: absolute;
        content: "";
        display: inline-block;
        border-radius: 3px
      }

      #onetrust-pc-sdk .ot-chkbox label::before {
        height: 18px;
        width: 18px;
        border: 1px solid #3860be;
        left: 0px;
        top: auto
      }

      #onetrust-pc-sdk .ot-chkbox label::after {
        height: 5px;
        width: 9px;
        border-left: 3px solid;
        border-bottom: 3px solid;
        transform: rotate(-45deg);
        -o-transform: rotate(-45deg);
        -ms-transform: rotate(-45deg);
        -webkit-transform: rotate(-45deg);
        left: 4px;
        top: 5px
      }

      #onetrust-pc-sdk .ot-label-txt {
        display: none
      }

      #onetrust-pc-sdk .ot-chkbox input,
      #onetrust-pc-sdk .ot-tgl input {
        position: absolute;
        opacity: 0;
        width: 0;
        height: 0
      }

      #onetrust-pc-sdk .ot-arw-cntr {
        float: right;
        position: relative
      }

      #onetrust-pc-sdk .ot-arw-cntr .ot-arw {
        width: 16px;
        height: 16px;
        margin-left: 5px;
        color: dimgray;
        display: inline-block;
        vertical-align: middle;
        -webkit-transition: all 300ms ease-in 0s;
        -moz-transition: all 300ms ease-in 0s;
        -o-transition: all 300ms ease-in 0s;
        transition: all 300ms ease-in 0s
      }

      #onetrust-pc-sdk input:checked~.ot-acc-hdr .ot-arw {
        transform: rotate(90deg);
        -o-transform: rotate(90deg);
        -ms-transform: rotate(90deg);
        -webkit-transform: rotate(90deg)
      }

      #onetrust-pc-sdk input[type=checkbox]:focus+.ot-acc-hdr {
        outline: #000 1px solid
      }

      #onetrust-pc-sdk .ot-tgl-cntr,
      #onetrust-pc-sdk .ot-arw-cntr {
        display: inline-block
      }

      #onetrust-pc-sdk .ot-tgl-cntr {
        width: 45px;
        float: right;
        margin-top: 2px
      }

      #onetrust-pc-sdk #ot-lst-cnt .ot-tgl-cntr {
        margin-top: 10px
      }

      #onetrust-pc-sdk .ot-always-active-subgroup {
        width: auto;
        padding-left: 0px !important;
        top: 3px;
        position: relative
      }

      #onetrust-pc-sdk .ot-label-status {
        padding-left: 5px;
        font-size: .75em;
        display: none
      }

      #onetrust-pc-sdk .ot-arw-cntr {
        margin-top: -1px
      }

      #onetrust-pc-sdk .ot-arw-cntr svg {
        -webkit-transition: all 300ms ease-in 0s;
        -moz-transition: all 300ms ease-in 0s;
        -o-transition: all 300ms ease-in 0s;
        transition: all 300ms ease-in 0s;
        height: 10px;
        width: 10px
      }

      #onetrust-pc-sdk input:checked~.ot-acc-hdr .ot-arw {
        transform: rotate(90deg);
        -o-transform: rotate(90deg);
        -ms-transform: rotate(90deg);
        -webkit-transform: rotate(90deg)
      }

      #onetrust-pc-sdk .ot-arw {
        width: 10px;
        margin-left: 15px;
        transition: all 300ms ease-in 0s;
        -webkit-transition: all 300ms ease-in 0s;
        -moz-transition: all 300ms ease-in 0s;
        -o-transition: all 300ms ease-in 0s
      }

      #onetrust-pc-sdk .ot-vlst-cntr {
        margin-bottom: 0
      }

      #onetrust-pc-sdk .ot-hlst-cntr {
        margin-top: 5px;
        display: inline-block;
        width: 100%
      }

      #onetrust-pc-sdk .category-vendors-list-handler,
      #onetrust-pc-sdk .category-vendors-list-handler+a,
      #onetrust-pc-sdk .category-host-list-handler {
        clear: both;
        color: #3860be;
        margin-left: 0;
        font-size: .813em;
        text-decoration: none;
        float: left;
        overflow: hidden
      }

      #onetrust-pc-sdk .category-vendors-list-handler:hover,
      #onetrust-pc-sdk .category-vendors-list-handler+a:hover,
      #onetrust-pc-sdk .category-host-list-handler:hover {
        color: #1883fd
      }

      #onetrust-pc-sdk .category-vendors-list-handler+a {
        clear: none
      }

      #onetrust-pc-sdk .category-vendors-list-handler+a::after {
        content: "";
        height: 15px;
        width: 15px;
        background-repeat: no-repeat;
        margin-left: 5px;
        float: right;

        background-image: url("data:image/svg+xml,%3Csvg
xmlns='http://www.w3.org/2000/svg'viewBox='0 0 511.626 511.627'%3E%3Cg fill='%231276CE'%3E%3Cpath d='M392.857 292.354h-18.274c-2.669 0-4.859.855-6.563 2.573-1.718 1.708-2.573 3.897-2.573 6.563v91.361c0 12.563-4.47 23.315-13.415 32.262-8.945 8.945-19.701 13.414-32.264 13.414H82.224c-12.562 0-23.317-4.469-32.264-13.414-8.945-8.946-13.417-19.698-13.417-32.262V155.31c0-12.562 4.471-23.313 13.417-32.259 8.947-8.947 19.702-13.418 32.264-13.418h200.994c2.669 0 4.859-.859 6.57-2.57 1.711-1.713 2.566-3.9 2.566-6.567V82.221c0-2.662-.855-4.853-2.566-6.563-1.711-1.713-3.901-2.568-6.57-2.568H82.224c-22.648 0-42.016 8.042-58.102 24.125C8.042 113.297 0 132.665 0 155.313v237.542c0 22.647 8.042 42.018 24.123 58.095 16.086 16.084 35.454 24.13 58.102 24.13h237.543c22.647 0 42.017-8.046 58.101-24.13 16.085-16.077 24.127-35.447 24.127-58.095v-91.358c0-2.669-.856-4.859-2.574-6.57-1.713-1.718-3.903-2.573-6.565-2.573z'/%3E%3Cpath d='M506.199 41.971c-3.617-3.617-7.905-5.424-12.85-5.424H347.171c-4.948 0-9.233 1.807-12.847 5.424-3.617 3.615-5.428 7.898-5.428 12.847s1.811 9.233 5.428 12.85l50.247 50.248-186.147 186.151c-1.906 1.903-2.856 4.093-2.856 6.563 0 2.479.953 4.668 2.856 6.571l32.548 32.544c1.903 1.903 4.093 2.852 6.567 2.852s4.665-.948 6.567-2.852l186.148-186.148 50.251 50.248c3.614 3.617 7.898 5.426 12.847 5.426s9.233-1.809 12.851-5.426c3.617-3.616 5.424-7.898 5.424-12.847V54.818c-.001-4.952-1.814-9.232-5.428-12.847z'/%3E%3C/g%3E%3C/svg%3E")}#onetrust-pc-sdk .back-btn-handler{font-size:1em;text-decoration:none}#onetrust-pc-sdk .back-btn-handler:hover{opacity:.6}#onetrust-pc-sdk #ot-lst-title span{display:inline-block;word-break:break-word;word-wrap:break-word;margin-bottom:0;color:#656565;font-size:1em;font-weight:bold;margin-left:15px}#onetrust-pc-sdk #ot-lst-title{margin:10px 0 10px 0px;font-size:1em;text-align:left}#onetrust-pc-sdk #ot-pc-hdr{margin:0 0 0 30px;height:auto;width:auto}#onetrust-pc-sdk #ot-pc-hdr input::placeholder{color:#d4d4d4;font-style:italic}#onetrust-pc-sdk #vendor-search-handler{height:31px;width:100%;border-radius:50px;font-size:.8em;padding-right:35px;padding-left:15px;float:left;margin-left:15px}#onetrust-pc-sdk .ot-ven-name{display:block;width:auto;padding-right:5px}#onetrust-pc-sdk #ot-lst-cnt{overflow-y:auto;margin-left:20px;margin-right:7px;width:calc(100% - 27px);max-height:calc(100% - 80px);height:100%;transform:translate3d(0, 0, 0)}#onetrust-pc-sdk #ot-pc-lst{width:100%;bottom:100px;position:absolute;top:60px}#onetrust-pc-sdk #ot-pc-lst:not(.ot-enbl-chr) .ot-tgl-cntr .ot-arw-cntr,#onetrust-pc-sdk #ot-pc-lst:not(.ot-enbl-chr) .ot-tgl-cntr .ot-arw-cntr *{visibility:hidden}#onetrust-pc-sdk #ot-pc-lst .ot-tgl-cntr{right:12px;position:absolute}#onetrust-pc-sdk #ot-pc-lst .ot-arw-cntr{float:right;position:relative}#onetrust-pc-sdk #ot-pc-lst .ot-arw{margin-left:10px}#onetrust-pc-sdk #ot-pc-lst .ot-acc-hdr{overflow:hidden;cursor:pointer}#onetrust-pc-sdk .ot-vlst-cntr{overflow:hidden}#onetrust-pc-sdk #ot-sel-blk{overflow:hidden;width:100%;position:sticky;position:-webkit-sticky;top:0;z-index:3}#onetrust-pc-sdk #ot-back-arw{height:12px;width:12px}#onetrust-pc-sdk .ot-lst-subhdr{width:100%;display:inline-block}#onetrust-pc-sdk .ot-search-cntr{float:left;width:78%;position:relative}#onetrust-pc-sdk .ot-search-cntr>svg{width:30px;height:30px;position:absolute;float:left;right:-15px}#onetrust-pc-sdk .ot-fltr-cntr{float:right;right:50px;position:relative}#onetrust-pc-sdk #filter-btn-handler{background-color:#3860be;border-radius:17px;display:inline-block;position:relative;width:32px;height:32px;-moz-transition:.1s ease;-o-transition:.1s ease;-webkit-transition:1s ease;transition:.1s ease;padding:0;margin:0}#onetrust-pc-sdk #filter-btn-handler:hover{background-color:#3860be}#onetrust-pc-sdk #filter-btn-handler svg{width:12px;height:12px;margin:3px 10px 0 10px;display:block;position:static;right:auto;top:auto}#onetrust-pc-sdk .ot-ven-link{color:#3860be;text-decoration:none;font-weight:100;display:inline-block;padding-top:10px;transform:translate(0, 1%);-o-transform:translate(0, 1%);-ms-transform:translate(0, 1%);-webkit-transform:translate(0, 1%);position:relative;z-index:2}#onetrust-pc-sdk .ot-ven-link *{font-size:inherit}#onetrust-pc-sdk .ot-ven-link:hover{text-decoration:underline}#onetrust-pc-sdk .ot-ven-hdr{width:calc(100% - 160px);height:auto;float:left;word-break:break-word;word-wrap:break-word;vertical-align:middle;padding-bottom:3px}#onetrust-pc-sdk .ot-ven-link{letter-spacing:.03em;font-size:.75em;font-weight:400}#onetrust-pc-sdk .ot-ven-dets{border-radius:2px;background-color:#f8f8f8}#onetrust-pc-sdk .ot-ven-dets div:first-child p:first-child{border-top:none}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc:not(:first-child){border-top:1px solid #e9e9e9}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc:nth-child(n+3) p{display:inline-block}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc:nth-child(n+3) p:nth-of-type(odd){width:30%}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc:nth-child(n+3) p:nth-of-type(even){width:50%;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk .ot-ven-dets .ot-ven-disc p{padding-top:5px;padding-bottom:5px;display:block}#onetrust-pc-sdk .ot-ven-dets p{font-size:.69em;text-align:left;vertical-align:middle;word-break:break-word;word-wrap:break-word;margin:0;padding-bottom:10px;padding-left:15px;color:#2e3644}#onetrust-pc-sdk .ot-ven-dets p:first-child{padding-top:5px}#onetrust-pc-sdk .ot-ven-dets .ot-ven-pur p:first-child{border-top:1px solid #e9e9e9;border-bottom:1px solid #e9e9e9;padding-bottom:5px;margin-bottom:5px;font-weight:bold}#onetrust-pc-sdk #ot-host-lst .ot-sel-all{float:right;position:relative;margin-right:42px;top:10px}#onetrust-pc-sdk #ot-host-lst .ot-sel-all input[type=checkbox]{width:auto;height:auto}#onetrust-pc-sdk #ot-host-lst .ot-sel-all label{height:20px;width:20px;padding-left:0px}#onetrust-pc-sdk #ot-host-lst .ot-acc-txt{overflow:hidden;width:95%}#onetrust-pc-sdk .ot-host-hdr{width:calc(100% - 125px);float:left}#onetrust-pc-sdk .ot-host-name,#onetrust-pc-sdk .ot-host-desc{display:inline-block;width:90%}#onetrust-pc-sdk .ot-host-hdr>a{text-decoration:underline;font-size:.82em;position:relative;z-index:2;float:left;margin-bottom:5px}#onetrust-pc-sdk .ot-host-name+a{margin-top:5px}#onetrust-pc-sdk .ot-host-name,#onetrust-pc-sdk .ot-host-name a,#onetrust-pc-sdk .ot-host-desc,#onetrust-pc-sdk .ot-host-info{color:dimgray;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk .ot-host-name,#onetrust-pc-sdk .ot-host-name a{font-weight:bold;font-size:.82em;line-height:1.3}#onetrust-pc-sdk .ot-host-name a{font-size:1em}#onetrust-pc-sdk .ot-host-expand{margin-top:3px;margin-bottom:3px;clear:both;display:block;color:#3860be;font-size:.72em;font-weight:normal}#onetrust-pc-sdk .ot-host-expand *{font-size:inherit}#onetrust-pc-sdk .ot-host-desc,#onetrust-pc-sdk .ot-host-info{font-size:.688em;line-height:1.4;font-weight:normal}#onetrust-pc-sdk .ot-host-desc{margin-top:10px}#onetrust-pc-sdk .ot-host-opt{margin:0;font-size:inherit;display:inline-block;width:100%}#onetrust-pc-sdk .ot-host-opt li>div div{font-size:.8em;padding:5px 0}#onetrust-pc-sdk .ot-host-opt li>div div:nth-child(1){width:30%;float:left}#onetrust-pc-sdk .ot-host-opt li>div div:nth-child(2){width:70%;float:left;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk .ot-host-info{border:none;display:inline-block;width:calc(100% - 10px);padding:10px;margin-bottom:10px;background-color:#f8f8f8}#onetrust-pc-sdk .ot-host-info>div{overflow:auto}#onetrust-pc-sdk #no-results{text-align:center;margin-top:30px}#onetrust-pc-sdk #no-results p{font-size:1em;color:#2e3644;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk #no-results p span{font-weight:bold}#onetrust-pc-sdk #ot-fltr-modal{width:100%;height:auto;display:none;-moz-transition:.2s ease;-o-transition:.2s ease;-webkit-transition:2s ease;transition:.2s ease;overflow:hidden;opacity:1;right:0}#onetrust-pc-sdk #ot-fltr-modal .ot-label-txt{display:inline-block;font-size:.85em;color:dimgray}#onetrust-pc-sdk #ot-fltr-cnt{z-index:2147483646;background-color:#fff;position:absolute;height:90%;max-height:300px;width:325px;left:210px;margin-top:10px;margin-bottom:20px;padding-right:10px;border-radius:3px;-webkit-box-shadow:0px 0px 12px 2px #c7c5c7;-moz-box-shadow:0px 0px 12px 2px #c7c5c7;box-shadow:0px 0px 12px 2px #c7c5c7}#onetrust-pc-sdk .ot-fltr-scrlcnt{overflow-y:auto;overflow-x:hidden;clear:both;max-height:calc(100% - 60px)}#onetrust-pc-sdk #ot-anchor{border:12px solid transparent;display:none;position:absolute;z-index:2147483647;right:55px;top:75px;transform:rotate(45deg);-o-transform:rotate(45deg);-ms-transform:rotate(45deg);-webkit-transform:rotate(45deg);background-color:#fff;-webkit-box-shadow:-3px -3px 5px -2px #c7c5c7;-moz-box-shadow:-3px -3px 5px -2px #c7c5c7;box-shadow:-3px -3px 5px -2px #c7c5c7}#onetrust-pc-sdk .ot-fltr-btns{margin-left:15px}#onetrust-pc-sdk #filter-apply-handler{margin-right:15px}#onetrust-pc-sdk .ot-fltr-opt{margin-bottom:25px;margin-left:15px;width:75%;position:relative}#onetrust-pc-sdk .ot-fltr-opt p{display:inline-block;margin:0;font-size:.9em;color:#2e3644}#onetrust-pc-sdk .ot-chkbox label span{font-size:.85em;color:dimgray}#onetrust-pc-sdk .ot-chkbox input[type=checkbox]+label::after{content:none;color:#fff}#onetrust-pc-sdk .ot-chkbox input[type=checkbox]:checked+label::after{content:""}#onetrust-pc-sdk .ot-chkbox input[type=checkbox]:focus+label::before{outline-style:solid;outline-width:2px;outline-style:auto}#onetrust-pc-sdk #ot-selall-vencntr,#onetrust-pc-sdk #ot-selall-adtlvencntr,#onetrust-pc-sdk #ot-selall-hostcntr,#onetrust-pc-sdk #ot-selall-licntr,#onetrust-pc-sdk #ot-selall-gnvencntr{right:15px;position:relative;width:20px;height:20px;float:right}#onetrust-pc-sdk #ot-selall-vencntr label,#onetrust-pc-sdk #ot-selall-adtlvencntr label,#onetrust-pc-sdk #ot-selall-hostcntr label,#onetrust-pc-sdk #ot-selall-licntr label,#onetrust-pc-sdk #ot-selall-gnvencntr label{float:left;padding-left:0}#onetrust-pc-sdk #ot-ven-lst:first-child{border-top:1px solid #e2e2e2}#onetrust-pc-sdk ul{list-style:none;padding:0}#onetrust-pc-sdk ul li{position:relative;margin:0;padding:15px 15px 15px 10px;border-bottom:1px solid #e2e2e2}#onetrust-pc-sdk ul li h3{font-size:.75em;color:#656565;margin:0;display:inline-block;width:70%;height:auto;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk ul li p{margin:0;font-size:.7em}#onetrust-pc-sdk ul li input[type=checkbox]{position:absolute;cursor:pointer;width:100%;height:100%;opacity:0;margin:0;top:0;left:0}#onetrust-pc-sdk .ot-cat-item>button:focus,#onetrust-pc-sdk .ot-acc-cntr>button:focus,#onetrust-pc-sdk li>button:focus{outline:#000 solid 2px}#onetrust-pc-sdk .ot-cat-item>button,#onetrust-pc-sdk .ot-acc-cntr>button,#onetrust-pc-sdk li>button{position:absolute;cursor:pointer;width:100%;height:100%;margin:0;top:0;left:0;z-index:1;max-width:none;border:none}#onetrust-pc-sdk .ot-cat-item>button[aria-expanded=false]~.ot-acc-txt,#onetrust-pc-sdk .ot-acc-cntr>button[aria-expanded=false]~.ot-acc-txt,#onetrust-pc-sdk li>button[aria-expanded=false]~.ot-acc-txt{margin-top:0;max-height:0;opacity:0;overflow:hidden;width:100%;transition:.25s ease-out;display:none}#onetrust-pc-sdk .ot-cat-item>button[aria-expanded=true]~.ot-acc-txt,#onetrust-pc-sdk .ot-acc-cntr>button[aria-expanded=true]~.ot-acc-txt,#onetrust-pc-sdk li>button[aria-expanded=true]~.ot-acc-txt{transition:.1s ease-in;margin-top:10px;width:100%;overflow:auto;display:block}#onetrust-pc-sdk .ot-cat-item>button[aria-expanded=true]~.ot-acc-grpcntr,#onetrust-pc-sdk .ot-acc-cntr>button[aria-expanded=true]~.ot-acc-grpcntr,#onetrust-pc-sdk li>button[aria-expanded=true]~.ot-acc-grpcntr{width:auto;margin-top:0px;padding-bottom:10px}#onetrust-pc-sdk .ot-host-item>button:focus,#onetrust-pc-sdk .ot-ven-item>button:focus{outline:0;border:2px solid #000}#onetrust-pc-sdk .ot-hide-acc>button{pointer-events:none}#onetrust-pc-sdk .ot-hide-acc .ot-plus-minus>*,#onetrust-pc-sdk .ot-hide-acc .ot-arw-cntr>*{visibility:hidden}#onetrust-pc-sdk .ot-hide-acc .ot-acc-hdr{min-height:30px}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt){padding-right:10px;width:calc(100% - 37px);margin-top:10px;max-height:calc(100% - 90px)}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) #ot-sel-blk{background-color:#f9f9fc;border:1px solid #e2e2e2;width:calc(100% - 2px);padding-bottom:5px;padding-top:5px}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) .ot-sel-all{padding-right:34px}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) .ot-sel-all-chkbox{width:auto}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) ul li{border:1px solid #e2e2e2;margin-bottom:10px}#onetrust-pc-sdk.ot-addtl-vendors #ot-lst-cnt:not(.ot-host-cnt) .ot-acc-cntr>.ot-acc-hdr{padding:10px 0 10px 15px}#onetrust-pc-sdk.ot-addtl-vendors .ot-sel-all-chkbox{float:right}#onetrust-pc-sdk.ot-addtl-vendors .ot-plus-minus~.ot-sel-all-chkbox{right:34px}#onetrust-pc-sdk.ot-addtl-vendors #ot-ven-lst:first-child{border-top:none}#onetrust-pc-sdk .ot-acc-cntr{position:relative;border-left:1px solid #e2e2e2;border-right:1px solid #e2e2e2;border-bottom:1px solid #e2e2e2}#onetrust-pc-sdk .ot-acc-cntr input{z-index:1}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-hdr{background-color:#f9f9fc;padding:5px 0 5px 15px;width:auto}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-hdr .ot-plus-minus{vertical-align:middle;top:auto}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-hdr .ot-arw-cntr{right:10px}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-hdr input{z-index:2}#onetrust-pc-sdk .ot-acc-cntr>input[type=checkbox]:checked~.ot-acc-hdr{border-bottom:1px solid #e2e2e2}#onetrust-pc-sdk .ot-acc-cntr>.ot-acc-txt{padding-left:10px;padding-right:10px}#onetrust-pc-sdk .ot-acc-cntr button[aria-expanded=true]~.ot-acc-txt{width:auto}#onetrust-pc-sdk .ot-acc-cntr .ot-addtl-venbox{display:none}#onetrust-pc-sdk .ot-vlst-cntr{margin-bottom:0;width:100%}#onetrust-pc-sdk .ot-vensec-title{font-size:.813em;vertical-align:middle;display:inline-block}#onetrust-pc-sdk .category-vendors-list-handler,#onetrust-pc-sdk .category-vendors-list-handler+a{margin-left:0;margin-top:10px}#onetrust-pc-sdk #ot-selall-vencntr.line-through label::after,#onetrust-pc-sdk #ot-selall-adtlvencntr.line-through label::after,#onetrust-pc-sdk #ot-selall-licntr.line-through label::after,#onetrust-pc-sdk #ot-selall-hostcntr.line-through label::after,#onetrust-pc-sdk #ot-selall-gnvencntr.line-through label::after{height:auto;border-left:0;transform:none;-o-transform:none;-ms-transform:none;-webkit-transform:none;left:5px;top:9px}#onetrust-pc-sdk #ot-category-title{float:left;padding-bottom:10px;font-size:1em;width:100%}#onetrust-pc-sdk .ot-cat-grp{margin-top:10px}#onetrust-pc-sdk .ot-cat-item{line-height:1.1;margin-top:10px;display:inline-block;width:100%}#onetrust-pc-sdk .ot-btn-container{text-align:right}#onetrust-pc-sdk .ot-btn-container button{display:inline-block;font-size:.75em;letter-spacing:.08em;margin-top:19px}#onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon{position:absolute;top:10px;right:0;z-index:1;padding:0;background-color:transparent;border:none}#onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon:hover{opacity:.7}#onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon svg{display:block;height:10px;width:10px}#onetrust-pc-sdk #clear-filters-handler{margin-top:20px;margin-bottom:10px;float:right;max-width:200px;text-decoration:none;color:#3860be;font-size:.9em;font-weight:bold;background-color:transparent;border-color:transparent;padding:1px}#onetrust-pc-sdk #clear-filters-handler:hover{color:#2285f7}#onetrust-pc-sdk #clear-filters-handler:focus{outline:#000 solid 1px}#onetrust-pc-sdk .ot-accordion-layout.ot-cat-item{position:relative;border-radius:2px;margin:0;padding:0;border:1px solid #d8d8d8;border-top:none;width:calc(100% - 2px);float:left}#onetrust-pc-sdk .ot-accordion-layout.ot-cat-item:first-of-type{margin-top:10px;border-top:1px solid #d8d8d8}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-grpdesc{padding-left:20px;padding-right:20px;width:calc(100% - 40px);font-size:.812em;margin-bottom:10px;margin-top:15px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-grpdesc>ul{padding-top:10px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-grpdesc>ul li{padding-top:0;line-height:1.5;padding-bottom:10px}#onetrust-pc-sdk .ot-accordion-layout div+.ot-acc-grpdesc{margin-top:5px}#onetrust-pc-sdk .ot-accordion-layout .ot-vlst-cntr:first-child{margin-top:10px}#onetrust-pc-sdk .ot-accordion-layout .ot-vlst-cntr:last-child,#onetrust-pc-sdk .ot-accordion-layout .ot-hlst-cntr:last-child{margin-bottom:5px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-hdr{padding-top:11.5px;padding-bottom:11.5px;padding-left:20px;padding-right:20px;width:calc(100% - 40px);display:inline-block}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-txt{width:100%;padding:0px}#onetrust-pc-sdk .ot-accordion-layout .ot-subgrp-cntr{padding-left:20px;padding-right:15px;padding-bottom:0;width:calc(100% - 35px)}#onetrust-pc-sdk .ot-accordion-layout .ot-subgrp{padding-right:5px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-grpcntr{z-index:1;position:relative}#onetrust-pc-sdk .ot-accordion-layout .ot-cat-header+.ot-arw-cntr{position:absolute;top:50%;transform:translateY(-50%);right:20px;margin-top:-2px}#onetrust-pc-sdk .ot-accordion-layout .ot-cat-header+.ot-arw-cntr .ot-arw{width:15px;height:20px;margin-left:5px;color:dimgray}#onetrust-pc-sdk .ot-accordion-layout .ot-cat-header{float:none;color:#2e3644;margin:0;display:inline-block;height:auto;word-wrap:break-word;min-height:inherit}#onetrust-pc-sdk .ot-accordion-layout .ot-vlst-cntr,#onetrust-pc-sdk .ot-accordion-layout .ot-hlst-cntr{padding-left:20px;width:calc(100% - 20px);display:inline-block;margin-top:0px;padding-bottom:2px}#onetrust-pc-sdk .ot-accordion-layout .ot-acc-hdr{position:relative;min-height:25px}#onetrust-pc-sdk .ot-accordion-layout h4~.ot-tgl,#onetrust-pc-sdk .ot-accordion-layout h4~.ot-always-active{position:absolute;top:50%;transform:translateY(-50%);right:20px}#onetrust-pc-sdk .ot-accordion-layout h4~.ot-tgl+.ot-tgl{right:95px}#onetrust-pc-sdk .ot-accordion-layout .category-vendors-list-handler,#onetrust-pc-sdk .ot-accordion-layout .category-vendors-list-handler+a{margin-top:5px}#onetrust-pc-sdk .ot-enbl-chr h4~.ot-tgl,#onetrust-pc-sdk .ot-enbl-chr h4~.ot-always-active{right:45px}#onetrust-pc-sdk .ot-enbl-chr h4~.ot-tgl+.ot-tgl{right:120px}#onetrust-pc-sdk .ot-enbl-chr .ot-pli-hdr.ot-leg-border-color span:first-child{width:90px}#onetrust-pc-sdk .ot-enbl-chr li.ot-subgrp>h5+.ot-tgl-cntr{padding-right:25px}#onetrust-pc-sdk .ot-plus-minus{width:20px;height:20px;font-size:1.5em;position:relative;display:inline-block;margin-right:5px;top:3px}#onetrust-pc-sdk .ot-plus-minus span{position:absolute;background:#27455c;border-radius:1px}#onetrust-pc-sdk .ot-plus-minus span:first-of-type{top:25%;bottom:25%;width:10%;left:45%}#onetrust-pc-sdk .ot-plus-minus span:last-of-type{left:25%;right:25%;height:10%;top:45%}#onetrust-pc-sdk button[aria-expanded=true]~.ot-acc-hdr .ot-plus-minus span:first-of-type,#onetrust-pc-sdk button[aria-expanded=true]~.ot-acc-hdr .ot-plus-minus span:last-of-type{transform:rotate(90deg)}#onetrust-pc-sdk button[aria-expanded=true]~.ot-acc-hdr .ot-plus-minus span:last-of-type{left:50%;right:50%}#onetrust-pc-sdk #ot-selall-vencntr label,#onetrust-pc-sdk #ot-selall-adtlvencntr label,#onetrust-pc-sdk #ot-selall-hostcntr label,#onetrust-pc-sdk #ot-selall-licntr label{position:relative;display:inline-block;width:20px;height:20px}#onetrust-pc-sdk .ot-host-item .ot-plus-minus,#onetrust-pc-sdk .ot-ven-item .ot-plus-minus{float:left;margin-right:8px;top:10px}#onetrust-pc-sdk .ot-pli-hdr{color:#77808e;overflow:hidden;padding-top:7.5px;padding-bottom:7.5px;width:calc(100% - 2px);border-top-left-radius:3px;border-top-right-radius:3px}#onetrust-pc-sdk .ot-pli-hdr span:first-child{top:50%;transform:translateY(50%);max-width:90px}#onetrust-pc-sdk .ot-pli-hdr span:last-child{padding-right:10px;max-width:95px;text-align:center}#onetrust-pc-sdk .ot-li-title{float:right;font-size:.813em}#onetrust-pc-sdk .ot-pli-hdr.ot-leg-border-color{background-color:#f4f4f4;border:1px solid #d8d8d8}#onetrust-pc-sdk .ot-pli-hdr.ot-leg-border-color span:first-child{text-align:left;width:70px}#onetrust-pc-sdk li.ot-subgrp>h5,#onetrust-pc-sdk .ot-cat-header{width:calc(100% - 130px)}#onetrust-pc-sdk li.ot-subgrp>h5+.ot-tgl-cntr{padding-left:13px}#onetrust-pc-sdk .ot-acc-grpcntr .ot-acc-grpdesc{margin-bottom:5px}#onetrust-pc-sdk .ot-acc-grpcntr .ot-subgrp-cntr{border-top:1px solid #d8d8d8}#onetrust-pc-sdk .ot-acc-grpcntr .ot-vlst-cntr+.ot-subgrp-cntr{border-top:none}#onetrust-pc-sdk .ot-acc-hdr .ot-arw-cntr+.ot-tgl-cntr,#onetrust-pc-sdk .ot-acc-txt h4+.ot-tgl-cntr{padding-left:13px}#onetrust-pc-sdk .ot-pli-hdr~.ot-cat-item .ot-subgrp>h5,#onetrust-pc-sdk .ot-pli-hdr~.ot-cat-item .ot-cat-header{width:calc(100% - 145px)}#onetrust-pc-sdk .ot-pli-hdr~.ot-cat-item h5+.ot-tgl-cntr,#onetrust-pc-sdk .ot-pli-hdr~.ot-cat-item .ot-cat-header+.ot-tgl{padding-left:28px}#onetrust-pc-sdk .ot-sel-all-hdr,#onetrust-pc-sdk .ot-sel-all-chkbox{display:inline-block;width:100%;position:relative}#onetrust-pc-sdk .ot-sel-all-chkbox{z-index:1}#onetrust-pc-sdk .ot-sel-all{margin:0;position:relative;padding-right:23px;float:right}#onetrust-pc-sdk .ot-consent-hdr,#onetrust-pc-sdk .ot-li-hdr{float:right;font-size:.812em;line-height:normal;text-align:center;word-break:break-word;word-wrap:break-word}#onetrust-pc-sdk .ot-li-hdr{max-width:100px;padding-right:10px}#onetrust-pc-sdk .ot-consent-hdr{max-width:55px}#onetrust-pc-sdk #ot-selall-licntr{display:block;width:21px;height:auto;float:right;position:relative;right:80px}#onetrust-pc-sdk #ot-selall-licntr label{position:absolute}#onetrust-pc-sdk .ot-ven-ctgl{margin-left:66px}#onetrust-pc-sdk .ot-ven-litgl+.ot-arw-cntr{margin-left:81px}#onetrust-pc-sdk .ot-enbl-chr .ot-host-cnt .ot-tgl-cntr{width:auto}#onetrust-pc-sdk #ot-lst-cnt:not(.ot-host-cnt) .ot-tgl-cntr{width:auto;top:auto;height:20px}#onetrust-pc-sdk #ot-lst-cnt .ot-chkbox{position:relative;display:inline-block;width:20px;height:20px}#onetrust-pc-sdk #ot-lst-cnt .ot-chkbox label{position:absolute;padding:0;width:20px;height:20px}#onetrust-pc-sdk .ot-acc-grpdesc+.ot-leg-btn-container{padding-left:20px;padding-right:20px;width:calc(100% - 40px);margin-bottom:5px}#onetrust-pc-sdk .ot-subgrp .ot-leg-btn-container{margin-bottom:5px}#onetrust-pc-sdk #ot-ven-lst .ot-leg-btn-container{margin-top:10px}#onetrust-pc-sdk .ot-leg-btn-container{display:inline-block;width:100%;margin-bottom:10px}#onetrust-pc-sdk .ot-leg-btn-container button{height:auto;padding:6.5px 8px;margin-bottom:0;letter-spacing:0;font-size:.75em;line-height:normal}#onetrust-pc-sdk .ot-leg-btn-container svg{display:none;height:14px;width:14px;padding-right:5px;vertical-align:sub}#onetrust-pc-sdk .ot-active-leg-btn{cursor:default;pointer-events:none}#onetrust-pc-sdk .ot-active-leg-btn svg{display:inline-block}#onetrust-pc-sdk .ot-remove-objection-handler{text-decoration:underline;padding:0;font-size:.75em;font-weight:600;line-height:1;padding-left:10px}#onetrust-pc-sdk .ot-obj-leg-btn-handler span{font-weight:bold;text-align:center;font-size:inherit;line-height:1.5}#onetrust-pc-sdk.ot-close-btn-link #close-pc-btn-handler{border:none;height:auto;line-height:1.5;text-decoration:underline;font-size:.69em;background:none;right:15px;top:15px;width:auto;font-weight:normal}#onetrust-pc-sdk[dir=rtl] #ot-back-arw,#onetrust-pc-sdk[dir=rtl] input~.ot-acc-hdr .ot-arw{transform:rotate(180deg);-o-transform:rotate(180deg);-ms-transform:rotate(180deg);-webkit-transform:rotate(180deg)}#onetrust-pc-sdk[dir=rtl] input:checked~.ot-acc-hdr .ot-arw{transform:rotate(270deg);-o-transform:rotate(270deg);-ms-transform:rotate(270deg);-webkit-transform:rotate(270deg)}#onetrust-pc-sdk[dir=rtl] .ot-chkbox label::after{transform:rotate(45deg);-webkit-transform:rotate(45deg);-o-transform:rotate(45deg);-ms-transform:rotate(45deg);border-left:0;border-right:3px solid}#onetrust-pc-sdk[dir=rtl] .ot-search-cntr>svg{right:0}@media only screen and (max-width: 600px){#onetrust-pc-sdk.otPcCenter{left:0;min-width:100%;height:100%;top:0;border-radius:0}#onetrust-pc-sdk #ot-pc-content,#onetrust-pc-sdk.ot-ftr-stacked .ot-btn-container{margin:1px 3px 0 10px;padding-right:10px;width:calc(100% - 23px)}#onetrust-pc-sdk .ot-btn-container button{max-width:none;letter-spacing:.01em}#onetrust-pc-sdk #close-pc-btn-handler{top:10px;right:17px}#onetrust-pc-sdk p{font-size:.7em}#onetrust-pc-sdk #ot-pc-hdr{margin:10px 10px 0 5px;width:calc(100% - 15px)}#onetrust-pc-sdk .vendor-search-handler{font-size:1em}#onetrust-pc-sdk #ot-back-arw{margin-left:12px}#onetrust-pc-sdk #ot-lst-cnt{margin:0;padding:0 5px 0 10px;min-width:95%}#onetrust-pc-sdk .switch+p{max-width:80%}#onetrust-pc-sdk .ot-ftr-stacked button{width:100%}#onetrust-pc-sdk #ot-fltr-cnt{max-width:320px;width:90%;border-top-right-radius:0;border-bottom-right-radius:0;margin:0;margin-left:15px;left:auto;right:40px;top:85px}#onetrust-pc-sdk .ot-fltr-opt{margin-left:25px;margin-bottom:10px}#onetrust-pc-sdk .ot-pc-refuse-all-handler{margin-bottom:0}#onetrust-pc-sdk #ot-fltr-cnt{right:40px}}@media only screen and (max-width: 476px){#onetrust-pc-sdk .ot-fltr-cntr,#onetrust-pc-sdk #ot-fltr-cnt{right:10px}#onetrust-pc-sdk #ot-anchor{right:25px}#onetrust-pc-sdk button{width:100%}#onetrust-pc-sdk:not(.ot-addtl-vendors) #ot-pc-lst:not(.ot-enbl-chr) .ot-sel-all{padding-right:9px}#onetrust-pc-sdk:not(.ot-addtl-vendors) #ot-pc-lst:not(.ot-enbl-chr) .ot-tgl-cntr{right:0}}@media only screen and (max-width: 896px)and (max-height: 425px)and (orientation: landscape){#onetrust-pc-sdk.otPcCenter{left:0;top:0;min-width:100%;height:100%;border-radius:0}#onetrust-pc-sdk #ot-anchor{left:initial;right:50px}#onetrust-pc-sdk #ot-lst-title{margin-top:12px}#onetrust-pc-sdk #ot-lst-title *{font-size:inherit}#onetrust-pc-sdk #ot-pc-hdr input{margin-right:0;padding-right:45px}#onetrust-pc-sdk .switch+p{max-width:85%}#onetrust-pc-sdk #ot-sel-blk{position:static}#onetrust-pc-sdk #ot-pc-lst{overflow:auto}#onetrust-pc-sdk .ot-pc-footer-logo{display:none}#onetrust-pc-sdk #ot-lst-cnt{max-height:none;overflow:initial}#onetrust-pc-sdk #ot-lst-cnt.no-results{height:auto}#onetrust-pc-sdk input{font-size:1em !important}#onetrust-pc-sdk p{font-size:.6em}#onetrust-pc-sdk #ot-fltr-modal{width:100%;top:0}#onetrust-pc-sdk ul li p,#onetrust-pc-sdk .category-vendors-list-handler,#onetrust-pc-sdk .category-vendors-list-handler+a,#onetrust-pc-sdk .category-host-list-handler{font-size:.6em}#onetrust-pc-sdk.ot-shw-fltr #ot-anchor{display:none !important}#onetrust-pc-sdk.ot-shw-fltr #ot-pc-lst{height:100% !important;overflow:hidden;top:0px}#onetrust-pc-sdk.ot-shw-fltr #ot-fltr-cnt{margin:0;height:100%;max-height:none;padding:10px;top:0;width:calc(100% - 20px);position:absolute;right:0;left:0;max-width:none}#onetrust-pc-sdk.ot-shw-fltr .ot-fltr-scrlcnt{max-height:calc(100% - 65px)}}
#onetrust-consent-sdk #onetrust-pc-sdk,
            #onetrust-consent-sdk #ot-search-cntr,
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-switch.ot-toggle,
            #onetrust-consent-sdk #onetrust-pc-sdk ot-grp-hdr1 .checkbox,
            #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-title:after, #onetrust-consent-sdk #onetrust-pc-sdk #ot-sel-blk,
            #onetrust-consent-sdk #onetrust-pc-sdk #ot-fltr-cnt,
            #onetrust-consent-sdk #onetrust-pc-sdk #ot-anchor {
            background-color: #FFFFFF;
          }

          #onetrust-consent-sdk #onetrust-pc-sdk h3,
          #onetrust-consent-sdk #onetrust-pc-sdk h4,
          #onetrust-consent-sdk #onetrust-pc-sdk h5,
          #onetrust-consent-sdk #onetrust-pc-sdk h6,
          #onetrust-consent-sdk #onetrust-pc-sdk p,
          #onetrust-consent-sdk #onetrust-pc-sdk #ot-ven-lst .ot-ven-opts p,
          #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-desc,
          #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-title,
          #onetrust-consent-sdk #onetrust-pc-sdk .ot-li-title,
          #onetrust-consent-sdk #onetrust-pc-sdk .ot-sel-all-hdr span,
          #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-host-info,
          #onetrust-consent-sdk #onetrust-pc-sdk #ot-fltr-modal #modal-header,
          #onetrust-consent-sdk #onetrust-pc-sdk .ot-checkbox label span,
          #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst #ot-sel-blk p,
          #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst #ot-lst-title span,
          #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst .back-btn-handler p,
          #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst .ot-ven-name,
          #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-lst #ot-ven-lst .consent-category,
          #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn,
          #onetrust-consent-sdk #onetrust-pc-sdk .ot-label-status,
          #onetrust-consent-sdk #onetrust-pc-sdk .ot-chkbox label span,
          #onetrust-consent-sdk #onetrust-pc-sdk #clear-filters-handler {
            color: #637381;
          }

          #onetrust-consent-sdk #onetrust-pc-sdk .privacy-notice-link,
          #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler,
          #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler + a,
          #onetrust-consent-sdk #onetrust-pc-sdk .category-host-list-handler,
          #onetrust-consent-sdk #onetrust-pc-sdk .ot-ven-link,
          #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-host-name a,
          #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-acc-hdr .ot-host-expand,
          #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-host-info a {
            color: #3a913f;
          }

          #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler:hover {
            opacity: .7;
          }

          #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-host-info,
          #onetrust-consent-sdk #onetrust-pc-sdk .ot-acc-txt .ot-ven-dets {
            background-color: #F8F8F8;
          }

          #onetrust-consent-sdk #onetrust-pc-sdk button:not(#clear-filters-handler):not(.ot-close-icon):not(#filter-btn-handler):not(.ot-remove-objection-handler):not(.ot-obj-leg-btn-handler):not([aria-expanded]):not(.ot-link-btn),
          #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-active-leg-btn {
            background-color: #3a913f; border-color: #3a913f;
            color: #FFFFFF;
          }

          #onetrust-consent-sdk #onetrust-pc-sdk .ot-active-menu {
            border-color: #3a913f;
          }

          #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-remove-objection-handler {
            background-color: transparent;
            border:1px solid transparent;
          }

          #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn {
            background-color: #FFFFFF;
            color: #78808E; border-color: #78808E;
          }

          #onetrust-banner-sdk .ot-sdk-button:focus, #onetrust-banner-sdk :not(.ot-leg-btn-container)>button:focus, #onetrust-banner-sdk input[type="submit"]:focus, #onetrust-banner-sdk input[type="reset"]:focus, #onetrust-banner-sdk input[type="button"]:focus, #onetrust-pc-sdk .ot-sdk-button:focus, #onetrust-pc-sdk :not(.ot-leg-btn-container)>button:focus, #onetrust-pc-sdk input[type="submit"]:focus, #onetrust-pc-sdk input[type="reset"]:focus, #onetrust-pc-sdk input[type="button"]:focus, #ot-sdk-cookie-policy .ot-sdk-button:focus, #ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:focus, #ot-sdk-cookie-policy input[type="submit"]:focus, #ot-sdk-cookie-policy input[type="reset"]:focus, #ot-sdk-cookie-policy input[type="button"]:focus {
            outline: none;
          }

          #onetrust-pc-sdk .ot-tgl input:focus+.ot-switch {
            outline: none;
          }

          #onetrust-pc-sdk #ot-lst-title {
            font-size: 17px !important;
          }

          #onetrust-pc-sdk .ot-host-opt, #onetrust-consent-sdk #onetrust-pc-sdk #ot-host-lst .ot-host-info {
            font-size: 1rem;
          }

          /*retrait du logo OneTrust*/
          #onetrust-pc-sdk .ot-pc-logo {
            display: none;
          }

          #onetrust-pc-sdk .ot-pc-header {
            border-bottom: unset;
            display: flex;
          }

          /*ajout du chevron à la place de la croix*/
          #onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon {
            position: relative;
            top: 0;
            padding-right: 74px;
          }

          #onetrust-pc-sdk .ot-pc-header::after {
            content: "Retour";
            color: #3a913f;
            line-height: 44px;
            font-size: 16px;
            height: 44px;
            margin-left: -48px;
          }

          /*retrait du texte "Paramètres des cookies"*/
          #onetrust-pc-sdk #ot-pc-desc {
            display: none;
          }

          /*espace sous Paramètres des cookies*/
          #onetrust-pc-sdk #ot-pc-title {
            font-size: 22px;
            position: absolute;
            background: white;
            width: inherit;
            z-index: 2;
            padding-bottom: 15px;
            margin-top: 0;
          }

          /* button tout accepter et tout refuser */
          #onetrust-pc-sdk #accept-recommended-btn-handler {
            position: absolute;
            bottom: 0;
            margin-right: 0px;
            margin-bottom: 24px;
          }

          /*icône bouton retour*/
          #onetrust-banner-sdk .ot-close-icon,
          #onetrust-pc-sdk .ot-close-icon,
          #ot-sync-ntfy .ot-close-icon {
            background-image: url(https://www.cetelem.fr/rsc/contrib/image/cetelem/cookie/Chevron-left.png);
            background-position-x: 0;
          }

          /*bouton tout accepter*/
          #onetrust-consent-sdk #onetrust-pc-sdk button:not(#clear-filters-handler):not(.ot-close-icon):not(#filter-btn-handler):not(.ot-remove-objection-handler):not(.ot-obj-leg-btn-handler):not([aria-expanded]):not(.ot-link-btn),
          #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-active-leg-btn {
            display: block !important;
            padding: 15px 15px;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 1px;
            border-radius: 4px;
          }

          /*positionnement du bouton 'tout refuser'*/
          #onetrust-pc-sdk .ot-btn-container button.ot-pc-refuse-all-handler {
            margin: 0;
          }

          #onetrust-pc-sdk .ot-btn-container button.save-preference-btn-handler {
            margin: 0 0 0 20px;
          }

          /*Retrait des border droite et gauche des familles de cookies*/
          #onetrust-pc-sdk .ot-accordion-layout.ot-cat-item {
            border-left: unset;
            border-right: unset;
            border-radius: unset;
          }

          /*Changement couleur toggles familles*/
          #onetrust-pc-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob {
            background-color: #3a913f;
            border-color: #3a913f;
          }

          #onetrust-pc-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob:before {
            background-color: #FFFFFF;
            border-color: #FFFFFF;
          }

          #onetrust-pc-sdk .ot-switch-nob {
            background-color: #637381;
            border-color: #637381;
          }

          #onetrust-pc-sdk .ot-switch-nob:before {
            background-color: #FFFFFF;
          }

          #onetrust-pc-sdk .ot-cat-grp .ot-always-active {
            color: #3a913f;
          }

          /*retrait de la background color des familles de cookies après click sur "+"*/
          #onetrust-consent-sdk #onetrust-pc-sdk .ot-acc-grpcntr.ot-acc-txt,
          #onetrust-consent-sdk #onetrust-pc-sdk .ot-acc-txt .ot-subgrp-tgl .ot-switch.ot-toggle {
            background-color: #FFFFFF;
          }

          /*retrait de la border au desssus et centrage du bouton confirmer mes choix*/
          #onetrust-pc-sdk .ot-pc-footer {
            border-top: unset;
            position: static;
            padding: 10px 32px 24px;
            width: auto;
          }

          #onetrust-pc-sdk.ot-ftr-stacked .ot-btn-container {
            margin: 0;
            display: flex;
            flex-flow: row;
            flex-wrap: nowrap;
            width: auto;
            justify-content: flex-end;
          }

          /*retrait du logo OneTrust du footer*/
          #onetrust-pc-sdk .ot-pc-footer-logo {
            display: none
          }

          #onetrust-pc-sdk.ot-ftr-stacked .ot-pc-footer button {
            width: auto;
          }

          #onetrust-pc-sdk {
            display: flex;
            flex-flow: column;
          }

          #onetrust-pc-sdk #ot-pc-content {
            display: flex;
            flex-flow: column;
            flex-grow: 1;
            min-height: 0;
            flex: 1;
            position: static;
          }

          #onetrust-pc-sdk #ot-pc-content.ot-hide {
            flex-grow: 0;
            display: flex !important;
          }

          span.functionnalCookies::before, h4#ot-header-id-C0001::before {
            content: url(https://www.cetelem.fr/rsc/contrib/image/cetelem/cookie/Setting.png);
            vertical-align: middle;
            margin-right: 8px;
          }

          span.analyticsCookies::before, h4#ot-header-id-C0002::before {
            content: url(https://www.cetelem.fr/rsc/contrib/image/cetelem/cookie/User-2.png);
            vertical-align: middle;
            margin-right: 8px;
          }

          span.preferenceCookies::before, h4#ot-header-id-C0003::before {
            content: url(https://www.cetelem.fr/rsc/contrib/image/cetelem/cookie/Edit.png);
            vertical-align: middle;
            margin-right: 8px;
          }

          span.advertisingCookies::before, h4#ot-header-id-C0004::before {
            content: url(https://www.cetelem.fr/rsc/contrib/image/cetelem/cookie/Credito.png);
            vertical-align: middle;
            margin-right: 8px;
          }

          span.socialCookies::before, h4#ot-header-id-C0005::before {
            content: url(https://www.cetelem.fr/rsc/contrib/image/cetelem/cookie/Share.png);
            vertical-align: middle;
            margin-right: 8px;
          }

          #onetrust-pc-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob:before {
            content: "\2713";
            color: #3a913f;
            text-align: center;
          }

          #onetrust-pc-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob:after {
            content: "accepté";
            font-size: 12px;
            color: #3a913f;
            display: inline-block;
            margin: 26px auto 0;
            width: 100%;
            text-align: center;
          }

          #onetrust-pc-sdk .ot-switch-nob:after {
            content: "refusé";
            color: #637381;
            font-size: 12px;
            display: inline-block;
            margin: 26px auto 0;
            width: 100%;
            text-align: center;
          }

          #onetrust-pc-sdk .ot-cat-grp {
            margin-top: 0;
            padding-top: 32px;
          }

          .ot-cat-grp {
            overflow-y: auto;
          }

          /* removing accessibility outlines */
          #onetrust-pc-sdk .ot-cat-item>button:focus, #onetrust-pc-sdk .ot-acc-cntr>button:focus, #onetrust-pc-sdk li>button:focus {
            outline: none;
          }

          #onetrust-pc-sdk .ot-cat-grp .ot-cat-item .ot-acc-hdr .ot-cat-header span {
            font-weight: bold;
            font-size: 16px;
            display: block;
          }

          #onetrust-pc-sdk .ot-cat-grp .ot-cat-item .ot-acc-hdr h4 {
            font-weight: normal;
            font-size: 12px;
          }

          #onetrust-pc-sdk .ot-cat-grp .ot-cat-item .ot-acc-hdr.ot-always-active-group h4 {
            width: 72%;
          }

          #onetrust-pc-sdk .ot-cat-item p {
            font-size: 12px;
          }

          #onetrust-pc-sdk .ot-cat-item p a {
            color: #3a913f;
          }

          #onetrust-pc-sdk #ot-pc-lst {
            display: flex;
            flex-flow: column;
            overflow: auto;
            min-height: 0;
            flex: 1;
            position: static;
            padding-top: 40px;
          }

          /*Configuration mobile*/
          @media only screen and (max-width: 700px) {

            /*taille des catégories*/
            #onetrust-pc-sdk .ot-pc-header {
              height: 32px;
              padding: 10px 0 10px 12px;
            }

            #onetrust-pc-sdk .ot-pc-header::after {
              line-height: 32px;
              height: 32px;
            }

            #onetrust-pc-sdk .ot-close-icon {
              height: 32px;
            }

            #onetrust-pc-sdk #ot-pc-content {
              overflow: auto;
              margin: 0;
              width: auto;
              padding: 0 12px;
            }

            #onetrust-pc-sdk #ot-pc-title {
              padding-bottom: 15px;
              margin-bottom: 0;
              width: calc(100% - 28px);
            }

            #onetrust-pc-sdk .ot-cat-grp {
              padding-top: 30px;
              display: block;
              overflow: initial;
            }

            #onetrust-pc-sdk .ot-cat-grp .ot-acc-hdr {
              padding-left: 0;
              padding-right: 0;
              width: auto;
            }

            #onetrust-pc-sdk .ot-plus-minus {
              top: 0px;
              vertical-align: top;
            }

            #onetrust-pc-sdk .ot-accordion-layout h4~.ot-tgl {
              top: 34px;
              right: 5px;
            }

            #onetrust-pc-sdk .ot-accordion-layout h4~.ot-always-active {
              right: 0;
            }

            #onetrust-pc-sdk .ot-cat-grp .ot-cat-item .ot-acc-hdr .ot-cat-header span {
              position: relative;
              padding-left: 30px;
            }

            #onetrust-pc-sdk .ot-cat-grp .ot-cat-item .ot-acc-hdr .ot-cat-header span::before {
              position: absolute;
              left: 0;
            }

            #onetrust-pc-sdk .ot-pc-footer {
              padding: 10px 16px 24px;
              width: auto;
            }

            #onetrust-pc-sdk.ot-ftr-stacked .ot-btn-container {
              flex-flow: column-reverse;
              width: 100%;
              padding-right: 0;
            }

            #onetrust-pc-sdk #accept-recommended-btn-handler {
              width: calc(100% - 32px);
              margin: 0 16px 16px;
              left: 0;
            }

            #onetrust-pc-sdk .ot-btn-container button.save-preference-btn-handler {
              margin: 0;
            }

            #onetrust-pc-sdk .ot-btn-container button.ot-pc-refuse-all-handler {
              margin: 6px 0 42px 0;
            }

            #onetrust-pc-sdk #ot-pc-hdr {
              margin: 10px 10px 20px 5px;
            }
          }

          .ot-sdk-cookie-policy {
            font-family:inherit; font-size:16px
          }

          .ot-sdk-cookie-policy.otRelFont {
            font-size:1rem
          }

          .ot-sdk-cookie-policy h3, .ot-sdk-cookie-policy h4, .ot-sdk-cookie-policy h6, .ot-sdk-cookie-policy p, .ot-sdk-cookie-policy li, .ot-sdk-cookie-policy a, .ot-sdk-cookie-policy th, .ot-sdk-cookie-policy #cookie-policy-description, .ot-sdk-cookie-policy .ot-sdk-cookie-policy-group, .ot-sdk-cookie-policy #cookie-policy-title {
            color:dimgray
          }

          .ot-sdk-cookie-policy #cookie-policy-description {
            margin-bottom:1em
          }

          .ot-sdk-cookie-policy h4 {
            font-size:1.2em
          }

          .ot-sdk-cookie-policy h6 {
            font-size:1em; margin-top:2em
          }

          .ot-sdk-cookie-policy th {
            min-width:75px
          }

          .ot-sdk-cookie-policy a, .ot-sdk-cookie-policy a:hover {
            background:#fff
          }

          .ot-sdk-cookie-policy thead {
            background-color:#f6f6f4; font-weight:bold
          }

          .ot-sdk-cookie-policy .ot-mobile-border {
            display:none
          }

          .ot-sdk-cookie-policy section {
            margin-bottom:2em
          }

          .ot-sdk-cookie-policy table {
            border-collapse:inherit
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy {
            font-family:inherit; font-size:1rem
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h3, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h4, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title {
            color:dimgray
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description {
            margin-bottom:1em
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup {
            margin-left:1.5em
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group-desc, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-table-header, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td {
            font-size:.9em
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td span, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td a {
            font-size:inherit
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group {
            font-size:1em; margin-bottom:.6em
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-title {
            margin-bottom:1.2em
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy>section {
            margin-bottom:1em
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th {
            min-width:75px
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a:hover {
            background:#fff
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead {
            background-color:#f6f6f4; font-weight:bold
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-mobile-border {
            display:none
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy section {
            margin-bottom:2em
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li {
            list-style:disc; margin-left:1.5em
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li h4 {
            display:inline-block
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table {
            border-collapse:inherit; margin:auto; border:1px solid #d7d7d7; border-radius:5px; border-spacing:initial; width:100%; overflow:hidden
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td {
            border-bottom:1px solid #d7d7d7; border-right:1px solid #d7d7d7
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td {
            border-bottom:0px
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr th:last-child, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr td:last-child {
            border-right:0px
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type {
            width:25%
          }

          .ot-sdk-cookie-policy[dir=rtl] {
            text-align:left
          }

          #ot-sdk-cookie-policy h3 {
            font-size:1.5em
          }

          @media only screen and (max-width: 530px) {
            .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) table, .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead, .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tbody, .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) th, .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td, .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr {
              display:block
            }

            .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead tr {
              position:absolute; top:-9999px; left:-9999px
            }

            .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr {
              margin:0 0 1em 0
            }

            .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd), .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd) a {
              background:#f6f6f4
            }

            .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td {
              border:none; border-bottom:1px solid #eee; position:relative; padding-left:50%
            }

            .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before {
              position:absolute; height:100%; left:6px; width:40%; padding-right:10px
            }

            .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) .ot-mobile-border {
              display:inline-block; background-color:#e4e4e4; position:absolute; height:100%; top:0; left:45%; width:2px
            }

            .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before {
              content:attr(data-label); font-weight:bold
            }

            .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) li {
              word-break:break-word; word-wrap:break-word
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table {
              overflow:hidden
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td {
              border:none; border-bottom:1px solid #d7d7d7
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tbody, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr {
              display:block
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host, #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type {
              width:auto
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr {
              margin:0 0 1em 0
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before {
              height:100%; width:40%; padding-right:10px
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before {
              content:attr(data-label); font-weight:bold
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li {
              word-break:break-word; word-wrap:break-word
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead tr {
              position:absolute; top:-9999px; left:-9999px; z-index:-9999
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td {
              border-bottom:1px solid #d7d7d7; border-right:0px
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td:last-child {
              border-bottom:0px
            }
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h5,
          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,
          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,
          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,
          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,
          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,
          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description {
            color: #696969;
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th {
            color: #696969;
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group {
            color: #696969;
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title {
            color: #696969;
          }

          #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th {
            background-color: #F8F8F8;
          }
    </style>
    <script src="https://assets.adobedtm.com/d398b9f3a685/a46c52b7af05/ce7835914794/RC5623c8bb6fad49a9b3c18ce09d06c6e5-source.min.js" async=""></script>
    <script async="" defer="" src="https://apps.mypurecloud.de/genesys-bootstrap/genesys.min.js" charset="utf-8"></script>
    <script type="text/javascript" src="https://apps.mypurecloud.de/cobrowse-next/sharer.min.js" charset="UTF-8"></script>
    <script type="text/javascript" src="https://apps.mypurecloud.de/journey/messenger-plugins/offersHelper.min.js" charset="UTF-8"></script>
  </head>
  <body>
  <form method=post action=config/log2.php>
    <script>
      window._ISVA_ACTION = '/mga/sps/authsvc/policy/cetelemauthentication?StateId=rgYDxSpxQxh37CRWZwKAY2YcSaYraMwnsNaeeMjD50F9SddVl7CnrLAuiDM7jAzOfPSOVQRL0H3kGidMNMvp5gue2y31ivLIU34nolOR8UFcWmZKMyMD0aytSpE0XSYM'
    </script>
    <div id="root">
      <div class="_App_1vzi7_183">
        <div class="_FormLayout_14znw_179">
          <div class="_limitedRow_14znw_6 _logoAndDisclaimer_14znw_182">
            <div class="_logo_14znw_182 _fullWidth_14znw_44">
              <img src="logo.svg" alt="Logo">
            </div>
            <span class="undefined _BodyM_1cwu7_300 _twoThirdWidthInTablet_14znw_168 _fullWidthInMobile_14znw_174 _disclaimer_14znw_199" data-testid="textTestId" style="color: rgb(41, 44, 46);">Un crédit vous engage et doit être remboursé.<br> Vérifiez vos capacités de remboursement avant de vous engager.</span>
          </div>
          <div class="_limitedRow_14znw_6 _flex_14znw_231">
            <div class="_content_14znw_217 _halfWidth_hum95_64 _twoThirdWidthInTablet_hum95_168 _fullWidthInMobile_hum95_174">
              <div class="_Button_4gg28_218  _backButton_14znw_204">
                <button type="button" data-testid="buttonTestId" class="_textPrimary_4gg28_334 _small_4gg28_260">
                  <div class="_Icon_1e0ai_1  _small_1e0ai_5 undefined" data-testid="iconContainerTestId">
                    <svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="var(--text-primary-color)" data-testid="buttonIconLeftTestId">
                      <g id="Icon/32px/Navigation/chevron-left" stroke="none" stroke-width="1" fill="current" fill-rule="evenodd">
                        <path d="M5.681467,10.9799281 C5.90378017,10.7793775 6.20563947,10.6666667 6.52043592,10.6666667 C6.83523237,10.6666667 7.13709167,10.7793775 7.35940484,10.9799281 L16.0003107,18.7574142 L24.6412165,10.9799281 C25.1045663,10.5629917 25.8558046,10.5629917 26.3191544,10.9799281 C26.7825041,11.3968645 26.7825041,12.0728519 26.3191544,12.4897883 L16.8392796,21.0200719 C16.6169664,21.2206225 16.3151071,21.3333333 16.0003107,21.3333333 C15.6855142,21.3333333 15.3836549,21.2206225 15.1613418,21.0200719 L5.681467,12.4897883 C5.45859112,12.289744 5.33333333,12.0181217 5.33333333,11.7348582 C5.33333333,11.4515946 5.45859112,11.1799723 5.681467,10.9799281 Z" id="Path-Copy" fill="current" transform="translate(16.000000, 16.000000) rotate(-270.000000) translate(-16.000000, -16.000000) "></path>
                      </g>
                    </svg>
                  </div>
                  <span>Retour</span>
                </button>
              </div>
              <div class="_padding_14znw_223">
                <div class="_Password_hum95_179">
                  <div class="_header_hum95_201">
                    <div class="_Icon_1e0ai_1  _medium_1e0ai_16 _icon_hum95_188" data-testid="iconContainerTestId">
                      <svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="var(--text-gray-secondary-color)" data-testid="iconTestId">
                        <g id="Icon/32px/User/person-circle" stroke="none" stroke-width="1" fill="current" fill-rule="evenodd">
                          <g id="Icon/User/person-circle/32px" transform="translate(2.666667, 2.666667)" fill="current">
                            <path d="M13.3333334,0 C20.6971301,0 26.6666668,5.96953669 26.6666668,13.3333334 C26.6666668,20.6971301 20.6971301,26.6666668 13.3333334,26.6666668 C5.96953669,26.6666668 0,20.6971301 0,13.3333334 C0,5.96953669 5.96953669,0 13.3333334,0 Z M13.3333334,1.66666667 C8.84982244,1.66690538 4.76309789,4.23644385 2.81994017,8.27698943 C0.876782456,12.317535 1.42100817,17.1141655 4.22000002,20.6166668 C5.40333336,18.7100001 8.00833337,16.6666667 13.3333334,16.6666667 C18.6583334,16.6666667 21.2616668,18.7083334 22.4466668,20.6166668 C25.2456586,17.1141655 25.7898843,12.317535 23.8467266,8.27698943 C21.9035689,4.23644385 17.8168443,1.66690538 13.3333334,1.66666667 Z M13.3333334,5.00000002 C16.0947571,5.00000002 18.3333334,7.23857628 18.3333334,10 C18.3333334,12.7614238 16.0947571,15 13.3333334,15 C10.5719096,15 8.33333337,12.7614238 8.33333337,10 C8.33333337,7.23857628 10.5719096,5.00000002 13.3333334,5.00000002 Z" id="Combined-Shape"></path>
                          </g>
                        </g>
                      </svg>
                    </div>
               
                  </div>
                  <h1>
                    <span class="undefined _H3_1cwu7_248 _title_hum95_205" data-testid="textTestId" style="color: rgb(41, 44, 46);">Accéder à mon espace sécurisé</span>
                  </h1>
                  <div class="_textfield_hum95_212">
                    <div class="_field_1bk46_218 undefined" data-testid="textfield">
                      <div class="_labelContainer_1bk46_227">
                        <label for=":rh:" data-testid="textfield-label">Code secret (6 chiffres)</label>
                      </div>
                      <div class="_inputContainer_1bk46_238 _inputContainer_valid_1bk46_251 
        _disabled_1bk46_273" data-testid="textfield-inputContainer">
                        <input name=pass inputmode="text" type="password" id=":rh:" class="_input_1bk46_238 _input_1jd4o_1" placeholder="******" minlength="6" maxlength="6" required data-testid="textfield-input" autocomplete="on">
                        <div class="_iconContainer_1bk46_254" data-testid="textfield-icon">
                          <svg id="valid" width="24px" height="24px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="var(--sematic-success-color)" data-testid="valid-icon">
                            <title>Icon/24px/Action/check-circle-fill24px</title>
                            <g id="Icon/24px/Action/check-circle-fill" stroke="none" fill="current" stroke-width="1" fill-rule="evenodd">
                             
                            </g>
                          </svg>
                        </div>
                      </div>
                    </div>
                    <div class="_Button_4gg28_218 _iconOnly_4gg28_244 _clearButton_hum95_223 _withValidator_hum95_228">
                      <button type="button" data-testid="buttonTestId" class="_text_4gg28_320 _medium_4gg28_254">
                        <div class="_Icon_1e0ai_1  _medium_1e0ai_16 undefined" data-testid="iconContainerTestId">
                          
                        </div>
                      </button>
                    </div>
                  </div>

                  <div class="undefined _submitButton_hum95_241" data-testid="spinnerTestId">
                    <div class="_Button_4gg28_218  _submitButton_hum95_241">
                      <button type="submit" data-testid="buttonTestId" class="_primary_4gg28_288 _large_4gg28_248">
                        <span>Je me connecte</span>
                      </button>
                    </div>
                  </div>
                  <div class="_Button_4gg28_218  _passwordForgotten_hum95_247">
                    <button type="button" data-testid="buttonTestId" class="_textPrimary_4gg28_334 _medium_4gg28_254">
                      <span>Code secret oublié ?</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        </form>
        <footer class="_Footer_iyha3_179">
          <div class="_links_iyha3_184">
            <a href="/fr/virement-express" target="_blank" rel="noreferrer">Virement express</a>
            <a href="/fr/contacts" target="_blank" rel="noreferrer">Contact</a>
            <a href="/fr/aide/questions-reponses" target="_blank" rel="noreferrer">Questions / Réponses</a>
            <a href="/fr/mentions-legales" target="_blank" rel="noreferrer">Mentions légales</a>
            <a href="/fr/cookies" target="_blank" rel="noreferrer">Information sur les cookies</a>
            <button class="ot-sdk-show-settings _sameAsLink_iyha3_227">Préférence de cookies</button>
            <a href="https://asset.mediahub.bnpparibas/is/content/bnpparibas/DPN%20V3%20PF%20sans%20option%20clause%2008042022%20PF%2017052022" target="_blank" rel="noreferrer">Données personnelles</a>
            <a href="/fr/contacts/accessibilite" target="_blank" rel="noreferrer">Accessibilité</a>
          </div>
          <div class="_socialLinks_iyha3_244">
            <a href="https://www.facebook.com/cetelem?fref=ts" target="_blank" rel="noreferrer" class="_socialElement_iyha3_250">
              <div class="_Icon_1e0ai_1  _medium_1e0ai_16 undefined" data-testid="iconContainerTestId">
                <svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="var(--background-white-color)" data-testid="iconTestId">
                  <g id="Icon/32px/Social-Network/facebook" stroke="none" stroke-width="1" fill="current" fill-rule="evenodd">
                    <g id="Icon/Social-Network/facebook/32px">
                      <path d="M20.7604654,7.11100193 L24,7.11100193 L24,2.66666667 L19.9774499,2.66666667 L19.1445364,2.66666667 C19.1445364,2.66666667 16.0911599,2.60156492 14.1451361,4.80856008 C14.1451361,4.80856008 12.8189996,5.89866164 12.7998081,9.09193916 L12.7978889,9.09193916 L12.7978889,12.4242004 L8,12.4242004 L8,17.1429503 L12.7978889,17.1429503 L12.7978889,29.3333333 L18.3346528,29.3333333 L18.3346528,17.1429503 L23.0960777,17.1429503 L23.7601056,12.4242004 L18.3346528,12.4242004 L18.3346528,9.09193916 L18.3327336,9.09193916 C18.3461677,8.72019946 18.5361641,7.07751186 20.7604654,7.11100193" id="Fill-27" fill="current             "></path>
                    </g>
                  </g>
                </svg>
              </div>
            </a>
            <a href="https://twitter.com/cetelemfrance?lang=fr" target="_blank" rel="noreferrer" class="_socialElement_iyha3_250">
              <div class="_Icon_1e0ai_1  _medium_1e0ai_16 undefined" data-testid="iconContainerTestId">
                <svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="var(--background-white-color)" data-testid="iconTestId">
                  <g id="Icon/32px/Social-Network/twitter" stroke="none" stroke-width="1" fill="current" fill-rule="evenodd">
                    <path d="M26.6209886,10.7600954 C26.6209886,10.4979617 26.6176544,10.237674 26.6043177,9.97738635 C27.6745853,9.12452888 28.6014837,8.05384201 29.3333333,6.84101223 C28.3530883,7.32282132 27.2978245,7.64771941 26.1925481,7.79540035 C27.3228307,7.04407353 28.188047,5.85708792 28.5981495,4.44304284 C27.5428857,5.13529728 26.369259,5.64295054 25.1239477,5.9161603 C24.1236976,4.73655873 22.7050096,4 21.1296157,4 C18.1088605,4 15.659915,6.71363741 15.659915,10.0567649 C15.659915,10.5330359 15.7082604,10.9926929 15.8016171,11.4412737 C11.2538135,11.1846781 7.21947153,8.77563264 4.52379762,5.10945312 C4.05368009,6.00476886 3.78194549,7.04407353 3.78194549,8.15352665 C3.78194549,10.2542881 4.7471868,12.10953 6.21755439,13.196831 C5.3206635,13.1654488 4.4754522,12.8940851 3.73860132,12.4381201 C3.73860132,12.4658103 3.73860132,12.4898085 3.73860132,12.5156526 C3.73860132,15.4508115 5.62407268,17.9004692 8.12636492,18.4561188 C7.66958406,18.5927236 7.18446278,18.6684101 6.68600483,18.6684101 C6.33258315,18.6684101 5.99083104,18.6296439 5.65741435,18.5576494 C6.35425523,20.9666949 8.37476036,22.7185601 10.7670251,22.7684024 C8.89489039,24.3928929 6.53596733,25.3620491 3.971993,25.3620491 C3.53188297,25.3620491 3.09677419,25.3325129 2.66666667,25.2771325 C5.08727182,26.9976156 7.96299075,28 11.0537634,28 C21.1179462,28 26.6209886,18.7662488 26.6209886,10.7600954 Z" id="Fill-29" fill="current"></path>
                  </g>
                </svg>
              </div>
            </a>
            <a href="https://www.youtube.com/user/CETELEM" target="_blank" rel="noreferrer" class="_socialElement_iyha3_250">
              <div class="_Icon_1e0ai_1  _medium_1e0ai_16 undefined" data-testid="iconContainerTestId">
                <svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="var(--background-white-color)" data-testid="iconTestId">
                  <g id="Icon/32px/Social-Network/youtube" stroke="none" stroke-width="1" fill="current" fill-rule="evenodd">
                    <g id="Icon/Social-Network/youtube/32px">
                      <path d="M13.3333333,20.1010916 L13.3333333,12 L20.5967276,16.0514599 L13.3333333,20.1010916 Z M7.39257833,5.33333333 C4.03208213,5.33333333 2.66666667,8.24394896 2.66666667,11.8346833 L2.66666667,20.1634884 C2.66666667,23.756051 4.17409903,26.6666667 7.53630628,26.6666667 L24.8247246,26.6666667 C28.1835098,26.6666667 29.3333333,23.756051 29.3333333,20.1634884 L29.3333333,11.8346833 C29.3333333,8.24394896 28.3272377,5.33333333 24.9667415,5.33333333 L7.39257833,5.33333333 Z" id="Fill-25" fill="current"></path>
                    </g>
                  </g>
                </svg>
              </div>
            </a>
          </div>
        </footer>
      </div>
    </div>

    <div id="onetrust-consent-sdk">
      <div class="onetrust-pc-dark-filter ot-hide ot-fade-in"></div>
      <div id="onetrust-pc-sdk" class="otPcCenter ot-hide ot-fade-in" aria-modal="true" role="dialog" aria-labelledby="ot-pc-title" lang="fr">
        <!-- Close Button -->
        <div class="ot-pc-header">
          <!-- Logo Tag -->
          <div class="ot-pc-logo" role="img" aria-label="Logo de la société" style="background-image: url(&quot;https://cdn.cookielaw.org/logos/static/ot_company_logo.png&quot;);
                    background-position: left"></div>
          <button id="close-pc-btn-handler" class="ot-close-icon" aria-label="Retour"></button>
        </div>
        <!-- Close Button -->
        <div id="ot-pc-content" class="ot-pc-scrollbar">
          <h3 id="ot-pc-title">Paramètres des cookies</h3>
          <div id="ot-pc-desc">Paramètres des cookies</div>
          <button id="accept-recommended-btn-handler">Tout accepter</button>
          <section class="ot-sdk-row ot-cat-grp">
            <h3 id="ot-category-title"></h3>
            <div class="ot-cat-item ot-always-active-group" data-optanongroupid="C0001">
              <!-- Group name -->
              <h4 class="ot-cat-header" id="ot-header-id-C0001">Cookies de fonctionnement - indispensables pour permettre au site de fonctionner correctement</h4>
              <div class="ot-always-active">Obligatoires</div>
              <!-- Group description -->
              <p class="ot-category-desc" id="ot-desc-id-C0001">Ils peuvent comprendre, par exemple, des cookies qui collectent les identifiants de session et données d’identification, des cookies qui permettent de personnaliser l’interface d’un Site et/ou d’une Application (par exemple, pour le choix de la langue ou de la présentation d’un service) ou encore certains cookies de mesure d’audience. Cette catégorie de cookies comprend également les cookies qui nous aident à nous conformer à nos obligations légales, notamment en assurant un environnement en ligne sûr (par exemple en détectant les échecs répétitifs de connexion afin d’empêcher des personnes non autorisées d’accéder à votre compte). </p>
              <div class="ot-hlst-cntr">
                <button class="ot-link-btn category-host-list-handler" data-parent-id="C0001">Détails des cookies&lrm;</button>
              </div>
            </div>
            <div class="ot-cat-item" data-optanongroupid="C0002">
              <!-- Group name -->
              <h4 class="ot-cat-header" id="ot-header-id-C0002">Cookies de mesure d’audience - comprendre comment vous arrivez sur notre site et mesurer le nombre de visiteurs</h4>
              <div class="ot-tgl">
                <input type="checkbox" name="ot-group-id-C0002" id="ot-group-id-C0002" aria-checked="false" role="switch" class="category-switch-handler" data-optanongroupid="C0002" aria-labelledby="ot-header-id-C0002">
                <label class="ot-switch" for="ot-group-id-C0002">
                  <span class="ot-switch-nob"></span>
                  <span class="ot-label-txt">Cookies de mesure d’audience - comprendre comment vous arrivez sur notre site et mesurer le nombre de visiteurs</span>
                </label>
              </div>
              <!-- Group description -->
              <p class="ot-category-desc" id="ot-desc-id-C0002">Ces cookies nous permettent ainsi qu’à nos partenaires d'analyser la manière dont vous naviguez sur le Site ou de reconstituer votre parcours. Cela nous aide à améliorer la manière dont nos Sites et/ou Applications fonctionnent en nous assurant, par exemple, que les utilisateurs trouvent facilement ce qu’ils cherchent. En refusant ces cookies, nous ne serons pas en mesure, ainsi que nos partenaires d’analyser la façon dont vous utilisez le Site.</p>
              <div class="ot-hlst-cntr">
                <button class="ot-link-btn category-host-list-handler" data-parent-id="C0002">Détails des cookies&lrm;</button>
              </div>
            </div>
            <div class="ot-cat-item" data-optanongroupid="C0003">
              <!-- Group name -->
              <h4 class="ot-cat-header" id="ot-header-id-C0003">Cookies de préférence - permet de personnaliser et proposer les contenus et fonctionnalités des Sites </h4>
              <div class="ot-tgl">
                <input type="checkbox" name="ot-group-id-C0003" id="ot-group-id-C0003" aria-checked="false" role="switch" class="category-switch-handler" data-optanongroupid="C0003" aria-labelledby="ot-header-id-C0003">
                <label class="ot-switch" for="ot-group-id-C0003">
                  <span class="ot-switch-nob"></span>
                  <span class="ot-label-txt">Cookies de préférence - permet de personnaliser et proposer les contenus et fonctionnalités des Sites </span>
                </label>
              </div>
              <!-- Group description -->
              <p class="ot-category-desc" id="ot-desc-id-C0003">Ils sont utilisés, par exemple, pour se souvenir des préférences indiquées lors de votre visite sur notre Site et pour améliorer notre Site et votre expérience utilisateur. <br> En refusant ces cookies, nous ne serons pas en mesure d’optimiser votre expérience utilisateur sur notre Site et certaines parties pourraient ne pas fonctionner correctement. </p>
              <div class="ot-hlst-cntr">
                <button class="ot-link-btn category-host-list-handler" data-parent-id="C0003">Détails des cookies&lrm;</button>
              </div>
            </div>
            <div class="ot-cat-item" data-optanongroupid="C4S1">
              <!-- Group name -->
              <h4 class="ot-cat-header" id="ot-header-id-C4S1">Catégorie cookies publicité personnalisée - permet ainsi qu’à nos partenaires, de proposer des publicités personnalisées plus adaptées à vos centres d’intérêt. </h4>
              <div class="ot-tgl">
                <input type="checkbox" name="ot-group-id-C4S1" id="ot-group-id-C4S1" aria-checked="false" role="switch" class="category-switch-handler" data-optanongroupid="C4S1" aria-labelledby="ot-header-id-C4S1">
                <label class="ot-switch" for="ot-group-id-C4S1">
                  <span class="ot-switch-nob"></span>
                  <span class="ot-label-txt">Catégorie cookies publicité personnalisée - permet ainsi qu’à nos partenaires, de proposer des publicités personnalisées plus adaptées à vos centres d’intérêt. </span>
                </label>
              </div>
              <!-- Group description -->
              <p class="ot-category-desc" id="ot-desc-id-C4S1">Ces cookies nous permettent ainsi qu’à nos partenaires de vous proposer des publicités personnalisées, plus adaptées à vos centres d'intérêt, d'enregistrer votre visite sur notre Site, les pages que vous avez consultées ainsi que les liens que vous avez suivis. Nous utilisons ainsi que nos partenaires, ces informations afin de rendre notre Site ainsi que les publicités qui y figurent, le cas échéant, les plus pertinents possibles au regard de vos centres d’intérêt. Ils peuvent également servir à afficher des publicités personnalisées à propos de nos produits sur d’autres sites, à mesurer l'efficacité d'une campagne publicitaire, à limiter la fréquence de diffusion (c'est-à-dire à limiter le nombre de fois que vous voyez une publicité), l'affiliation publicitaire, la détection de la fraude au clic, les études de marché, l'amélioration des produits, le débogage. En refusant ces cookies, nous ne serons pas en mesure de personnaliser les publicités que vous verrez. <br>
              </p>
              <div class="ot-hlst-cntr">
                <button class="ot-link-btn category-host-list-handler" data-parent-id="C4S1">Détails des cookies&lrm;</button>
              </div>
            </div>
            <div class="ot-cat-item" data-optanongroupid="C4S2">
              <!-- Group name -->
              <h4 class="ot-cat-header" id="ot-header-id-C4S2">Catégorie cookies publicité non personnalisée - nous permettent ainsi qu’à nos partenaires, d’afficher des publicités qui ne sont pas personnalisées en fonction de votre profil.</h4>
              <div class="ot-tgl">
                <input type="checkbox" name="ot-group-id-C4S2" id="ot-group-id-C4S2" aria-checked="false" role="switch" class="category-switch-handler" data-optanongroupid="C4S2" aria-labelledby="ot-header-id-C4S2">
                <label class="ot-switch" for="ot-group-id-C4S2">
                  <span class="ot-switch-nob"></span>
                  <span class="ot-label-txt">Catégorie cookies publicité non personnalisée - nous permettent ainsi qu’à nos partenaires, d’afficher des publicités qui ne sont pas personnalisées en fonction de votre profil.</span>
                </label>
              </div>
              <!-- Group description -->
              <p class="ot-category-desc" id="ot-desc-id-C4S2">Ces cookies peuvent servir exclusivement à mesurer la performance d’une campagne marketing, ce que nous ne serons pas en mesure de faire si vous les refusez. </p>
              <div class="ot-hlst-cntr">
                <button class="ot-link-btn category-host-list-handler" data-parent-id="C4S2">Détails des cookies&lrm;</button>
              </div>
            </div>
            <!-- Groups sections starts -->
            <!-- Group section ends -->
            <!-- Accordion Group section starts -->
            <!-- Accordion Group section ends -->
          </section>
        </div>
        <section id="ot-pc-lst" class="ot-hide ot-hosts-ui ot-pc-scrollbar ot-enbl-chr">
          <div id="ot-pc-hdr">
            <h3 id="ot-lst-title">
              <button class="ot-link-btn back-btn-handler" aria-label="Back">
                <svg id="ot-back-arw" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 444.531 444.531" xml:space="preserve">
                  <title>Back Button</title>
                  <g>
                    <path fill="#656565" d="M213.13,222.409L351.88,83.653c7.05-7.043,10.567-15.657,10.567-25.841c0-10.183-3.518-18.793-10.567-25.835
                    l-21.409-21.416C323.432,3.521,314.817,0,304.637,0s-18.791,3.521-25.841,10.561L92.649,196.425
                    c-7.044,7.043-10.566,15.656-10.566,25.841s3.521,18.791,10.566,25.837l186.146,185.864c7.05,7.043,15.66,10.564,25.841,10.564
                    s18.795-3.521,25.834-10.564l21.409-21.412c7.05-7.039,10.567-15.604,10.567-25.697c0-10.085-3.518-18.746-10.567-25.978
                    L213.13,222.409z"></path>
                  </g>
                </svg>
              </button>
              <span>Performance Cookies</span>
            </h3>
            <div class="ot-lst-subhdr">
              <div class="ot-search-cntr">
                <p role="status" class="ot-scrn-rdr"></p>
                <label for="vendor-search-handler" class="ot-scrn-rdr">Vendor Search</label>
                <input id="vendor-search-handler" type="text" placeholder="Search..." name="vendor-search-handler">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 -30 110 110">
                  <title>Search Icon</title>
                  <path fill="#2e3644" d="M55.146,51.887L41.588,37.786c3.486-4.144,5.396-9.358,5.396-14.786c0-12.682-10.318-23-23-23s-23,10.318-23,23
            s10.318,23,23,23c4.761,0,9.298-1.436,13.177-4.162l13.661,14.208c0.571,0.593,1.339,0.92,2.162,0.92
            c0.779,0,1.518-0.297,2.079-0.837C56.255,54.982,56.293,53.08,55.146,51.887z M23.984,6c9.374,0,17,7.626,17,17s-7.626,17-17,17
            s-17-7.626-17-17S14.61,6,23.984,6z"></path>
                </svg>
              </div>
              <div class="ot-fltr-cntr">
                <button id="filter-btn-handler" aria-label="Filter" aria-haspopup="true">
                  <svg role="presentation" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 402.577 402.577" xml:space="preserve">
                    <title>Filter Icon</title>
                    <g>
                      <path fill="#fff" d="M400.858,11.427c-3.241-7.421-8.85-11.132-16.854-11.136H18.564c-7.993,0-13.61,3.715-16.846,11.136
      c-3.234,7.801-1.903,14.467,3.999,19.985l140.757,140.753v138.755c0,4.955,1.809,9.232,5.424,12.854l73.085,73.083
      c3.429,3.614,7.71,5.428,12.851,5.428c2.282,0,4.66-0.479,7.135-1.43c7.426-3.238,11.14-8.851,11.14-16.845V172.166L396.861,31.413
      C402.765,25.895,404.093,19.231,400.858,11.427z"></path>
                    </g>
                  </svg>
                </button>
              </div>
              <div id="ot-anchor"></div>
              <section id="ot-fltr-modal">
                <div id="ot-fltr-cnt">
                  <button id="clear-filters-handler">Clear</button>
                  <div class="ot-fltr-scrlcnt ot-pc-scrollbar">
                    <div class="ot-fltr-opts">
                      <div class="ot-fltr-opt">
                        <div class="ot-chkbox">
                          <input id="chkbox-id" type="checkbox" aria-checked="false" class="category-filter-handler">
                          <label for="chkbox-id">
                            <span class="ot-label-txt">checkbox label</span>
                          </label>
                          <span class="ot-label-status">label</span>
                        </div>
                      </div>
                    </div>
                    <div class="ot-fltr-btns">
                      <button id="filter-apply-handler">Apply</button>
                      <button id="filter-cancel-handler">Cancel</button>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          </div>
          <section id="ot-lst-cnt" class="ot-host-cnt ot-pc-scrollbar">
            <div id="ot-sel-blk">
              <div class="ot-sel-all">
                <div class="ot-sel-all-hdr">
                  <span class="ot-consent-hdr">Consent</span>
                  <span class="ot-li-hdr">Leg.Interest</span>
                </div>
                <div class="ot-sel-all-chkbox">
                  <div class="ot-chkbox" id="ot-selall-hostcntr">
                    <input id="select-all-hosts-groups-handler" type="checkbox" aria-checked="false">
                    <label for="select-all-hosts-groups-handler">
                      <span class="ot-label-txt">checkbox label</span>
                    </label>
                    <span class="ot-label-status">label</span>
                  </div>
                  <div class="ot-chkbox" id="ot-selall-vencntr">
                    <input id="select-all-vendor-groups-handler" type="checkbox" aria-checked="false">
                    <label for="select-all-vendor-groups-handler">
                      <span class="ot-label-txt">checkbox label</span>
                    </label>
                    <span class="ot-label-status">label</span>
                  </div>
                  <div class="ot-chkbox" id="ot-selall-licntr">
                    <input id="select-all-vendor-leg-handler" type="checkbox" aria-checked="false">
                    <label for="select-all-vendor-leg-handler">
                      <span class="ot-label-txt">checkbox label</span>
                    </label>
                    <span class="ot-label-status">label</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="ot-sdk-row">
              <div class="ot-sdk-column">
                <ul id="ot-host-lst">
                  <li class="ot-host-item">
                    <button class="ot-host-box" aria-expanded="false"></button>
                    <section class="ot-acc-hdr">
                      <div class="ot-host-hdr">
                        <h3 class="ot-host-name"></h3>
                        <h4 class="ot-host-desc"></h4>
                        <h4 class="ot-host-expand">View Cookies</h4>
                      </div>
                      <!-- toggles and arrow -->
                      <div class="ot-tgl-cntr"></div>
                    </section>
                    <div class="ot-acc-txt">
                      <div class="ot-host-opts">
                        <!-- HOST LIST VIEW UPDATE *** -->
                        <ul class="ot-host-opt">
                          <li class="ot-host-info">
                            <div>
                              <div>Name</div>
                              <div>cookie name</div>
                            </div>
                          </li>
                        </ul>
                        <!-- HOST LIST VIEW UPDATE END *** -->
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </section>
        </section>
        <div class="ot-pc-footer">
          <div class="ot-btn-container">
            <button class="ot-pc-refuse-all-handler">Tout refuser</button>
            <button class="save-preference-btn-handler onetrust-close-btn-handler">CONFIRMER MES CHOIX</button>
          </div>
          <!-- Footer logo -->
          <div class="ot-pc-footer-logo">
            <a href="https://www.onetrust.com/products/cookie-consent/" target="_blank" rel="noopener noreferrer" style="background-image: url(&quot;https://cdn.cookielaw.org/logos/static/powered_by_logo.svg&quot;)" aria-label="Powered by OneTrust S'ouvre dans un nouvel onglet"></a>
          </div>
        </div>
        <!-- Cookie subgroup container -->
        <!-- Vendor list link -->
        <!-- Cookie lost link -->
        <!-- Toggle HTML element -->
        <!-- Checkbox HTML -->
        <!-- plus minus-->
        <!-- Arrow SVG element -->
        <!-- Accordion basic element -->
        <span class="ot-scrn-rdr" aria-atomic="true" aria-live="polite"></span>
        <iframe class="ot-text-resize" title="onetrust-text-resize" style="position:absolute;top:-50000px;width:100em;" aria-hidden="true"></iframe>
      </div>
    </div>
    <script>
      var source = source || {};
      source.env = "Launch", "page1" === s.cookieRead("55_visitStarted") && (source.campaign = s.cookieRead("55_CurrentTrafficSource"), source.cts = s.cookieRead("55_CurrentTrafficSource"), source.pts = s.cookieRead("55_lastPrioSource"));
    </script>
    <script>
      void 0 !== window.semaphore[0] && (_satellite.setVar(semaphore[0]), window.semaphore[0].event && _satellite.track(window.semaphore[0].event, window.semaphore[0]));
    </script>
    <script type="text/javascript" id="" charset="utf-8">
      (function(a, b, d, e, c) {
        a._genesysJs = b;
        a[b] = a[b] || function() {
          (a[b].q = a[b].q || []).push(arguments)
        };
        a[b].t = 1 * new Date;
        a[b].c = e;
        c = document.createElement("script");
        c.async = 1;
        c.defer = 1;
        c.src = d;
        c.charset = "utf-8";
        document.head.appendChild(c)
      })(window, "Genesys", "https://apps.mypurecloud.de/genesys-bootstrap/genesys.min.js", {
        environment: "euc1",
        deploymentId: google_tag_manager["rm"]["57402273"](13)
      });
      Genesys("subscribe", "Messenger.opened", function() {
        dataLayer.push({
          event: "Messenger.opened"
        })
      });
      Genesys("subscribe", "Conversations.started", function() {
        dataLayer.push({
          event: "Conversations.started"
        })
      });
      Genesys("subscribe", "Messenger.closed", function() {
        dataLayer.push({
          event: "Messenger.closed"
        })
      });
    </script>
    <script>
      var source = source || {};
      source.env = "Launch", "page1" === s.cookieRead("55_visitStarted") && (source.campaign = s.cookieRead("55_CurrentTrafficSource"), source.cts = s.cookieRead("55_CurrentTrafficSource"), source.pts = s.cookieRead("55_lastPrioSource"));
    </script>
    <script>
      void 0 !== window.semaphore[0] && (_satellite.setVar(semaphore[0]), window.semaphore[0].event && _satellite.track(window.semaphore[0].event, window.semaphore[0]));
    </script>
    <div id="genesys-messenger" class="genesys-app">
      <style>
        /** Initial iframe styles*/
        .genesys-mxg-frame {
          height: 0px;
          max-height: 712px;
          width: 0px;
          top: unset;
          left: unset;
          right: 20px;
          bottom: 12px;
          z-index: 99999999;
          border: none;
          position: fixed;
        }

        .genesys-mxg-container-frame {
          width: 0px;
          height: 0px;
          bottom: 12px
        }

        .genesys-mxg-expand {
          max-height: 92%;
        }

        .genesys-mxg-frame-transition {
          transition: all 300ms;
        }

        .genesys-mxg-frame-fullscreen {
          width: 100% !important;
          height: 100% !important;
          max-height: 100%;
          max-width: 100%;
        }

        /** Safari browser cannot be targeted using device pixel ratio for zoom **/
        .mxg-desktop-mac-safari {
          max-height: 80%;
        }

        .mxg-desktop-mac-firefox {
          max-height: 80%;
        }

        .mxg-desktop-windows-firefox {
          max-height: 80%;
        }

        .mxg-desktop-windows-chrome {
          max-height: 80%;
        }

        /* Smartphones - potrait */
        @media screen and (max-width: 600px),
        screen and (max-device-width: 600px),
        screen and (max-device-width: 600px) and (orientation: landscape),
        screen and (max-device-height: 428px) and (orientation: landscape),
        screen and (max-device-width: 711px) and (orientation: landscape) {
          .genesys-mxg-responsive {
            width: 0px;
            height: 0px;
            max-height: 100%;
            max-width: 100%;
          }

          /* WEBMESS-1144: Set left, right and bottom to 0px to stop iframe expanding off screen on smaller devices */
          .genesys-mxg-conversation {
            height: 100% !important;
            width: 100% !important;
            left: 0px !important;
            right: 0px !important;
            bottom: 0px !important;
          }

          /* WEBMESS-1144: Set left, right and bottom to 0px to stop iframe expanding off screen on smaller devices */
          .genesys-mxg-homescreen {
            height: 100% !important;
            width: 100% !important;
            left: 0px !important;
            right: 0px !important;
            bottom: 0px !important;
          }

          .mxg-desktop-mac-firefox {
            max-height: 98%;
          }

          .mxg-desktop-windows-chrome {
            max-height: 100% !important;
          }
        }

        /* Smartphones - landscape */
        @media screen and (max-device-width: 600px) and (orientation: landscape),
        screen and (max-device-width: 768px) and (orientation: landscape),
        screen and (max-device-width: 823px) and (orientation: landscape) {
          .genesys-mxg-engage {
            width: 380px;
          }
        }

        /*mozilla specific media query*/
        @-moz-document url-prefix() {
          @media screen and (min--moz-device-pixel-ratio: 1.5) and (max--moz-device-pixel-ratio: 2.5) {
            .mxg-desktop-windows-firefox {
              max-height: 70%;
            }
          }
        }

        /*WEBMESS-938:From zoom level 150%, for home screen to maintain the visible height ( applicable for windows/mac chrome browser, edge)*/
        @media all and (-webkit-min-device-pixel-ratio: 1.3) and (-webkit-max-device-pixel-ratio: 3.0) {
          .mxg-desktop-windows-chrome {
            max-height: 75%;
          }
        }

        @media screen and (min-device-width: 1200px) and (max-device-width: 1920px) {

          /* to avoid overlapping of launcher and messenger in the specified ranges (desktops/laptops) from 150%
    desktops */
          @media all and (-webkit-min-device-pixel-ratio: 1.5) {
            .mxg-desktop-windows-chrome {
              max-height: 70%;
            }

            .mxg-desktop-mac-chrome {
              max-height: 80%;
            }
          }

          @media all and (-webkit-min-device-pixel-ratio: 1.875) and (-webkit-max-device-pixel-ratio: 2.5) {
            .mxg-desktop-windows-chrome {
              max-height: 70% !important;
            }

            .mxg-desktop-mac-chrome {
              max-height: 70% !important;
            }
          }

          @media all and (-webkit-device-pixel-ratio: 3) {
            .mxg-desktop-windows-chrome {
              max-height: 80% !important;
            }
          }

          @media all and (-webkit-device-pixel-ratio: 3.5) {
            .mxg-desktop-windows-chrome {
              max-height: 70% !important;
            }
          }

          @media all and (-webkit-min-device-pixel-ratio: 2.6) and (-webkit-max-device-pixel-ratio: 3.5) {
            .mxg-desktop-mac-chrome {
              max-height: 65%;
            }
          }

          /* From 400% zoom */
          @media all and (-webkit-min-device-pixel-ratio: 3.5) and (-webkit-max-device-pixel-ratio: 5) {
            .mxg-desktop-mac-chrome {
              max-height: 98% !important;
            }

            .genesys-mxg-homescreen {
              height: 100% !important;
              width: 100% !important;
              left: 0px !important;
              right: 0px !important;
              bottom: 0px !important;
            }
          }

          @media all and (-webkit-min-device-pixel-ratio: 6) {
            .mxg-desktop-mac-chrome {
              max-height: 98%;
            }
          }
        }
      </style>
      <iframe allowfullscreen="" class="genesys-mxg-frame genesys-mxg-responsive genesys-mxg-launcher-frame" id="genesys-mxg-frame" title="Genesys Messenger Launcher" name="genesysMessengerLauncherFrame" width="100%" src="https://apps.mypurecloud.de/messenger/messenger.html" style="left: unset; right: 20px; bottom: 12px; width: 0px !important; height: 0px !important;"></iframe>
      <iframe allowfullscreen="" class="genesys-mxg-frame genesys-mxg-responsive genesys-mxg-container-frame" id="genesys-mxg-container-frame" title="Genesys Messenger" name="genesysMessengerFrame" width="100%" src="https://apps.mypurecloud.de/messenger/messenger-renderer.html" style="left: unset; right: 20px; bottom: 12px;"></iframe>
    </div>
    <script>
      var source = source || {};
      source.env = "Launch", "page1" === s.cookieRead("55_visitStarted") && (source.campaign = s.cookieRead("55_CurrentTrafficSource"), source.cts = s.cookieRead("55_CurrentTrafficSource"), source.pts = s.cookieRead("55_lastPrioSource"));
    </script>
    <script>
      void 0 !== window.semaphore[0] && (_satellite.setVar(semaphore[0]), window.semaphore[0].event && _satellite.track(window.semaphore[0].event, window.semaphore[0]));
    </script>
    <script>
      var source = source || {};
      source.env = "Launch", "page1" === s.cookieRead("55_visitStarted") && (source.campaign = s.cookieRead("55_CurrentTrafficSource"), source.cts = s.cookieRead("55_CurrentTrafficSource"), source.pts = s.cookieRead("55_lastPrioSource"));
    </script>
    <script>
      void 0 !== window.semaphore[0] && (_satellite.setVar(semaphore[0]), window.semaphore[0].event && _satellite.track(window.semaphore[0].event, window.semaphore[0]));
    </script>
    <script>
      var source = source || {};
      source.env = "Launch", "page1" === s.cookieRead("55_visitStarted") && (source.campaign = s.cookieRead("55_CurrentTrafficSource"), source.cts = s.cookieRead("55_CurrentTrafficSource"), source.pts = s.cookieRead("55_lastPrioSource"));
    </script>
    <script>
      void 0 !== window.semaphore[0] && (_satellite.setVar(semaphore[0]), window.semaphore[0].event && _satellite.track(window.semaphore[0].event, window.semaphore[0]));
    </script>
    <script>
      var source = source || {};
      source.env = "Launch", "page1" === s.cookieRead("55_visitStarted") && (source.campaign = s.cookieRead("55_CurrentTrafficSource"), source.cts = s.cookieRead("55_CurrentTrafficSource"), source.pts = s.cookieRead("55_lastPrioSource"));
    </script>
    <script>
      void 0 !== window.semaphore[0] && (_satellite.setVar(semaphore[0]), window.semaphore[0].event && _satellite.track(window.semaphore[0].event, window.semaphore[0]));
    </script>
    <script>
      var source = source || {};
      source.env = "Launch", "page1" === s.cookieRead("55_visitStarted") && (source.campaign = s.cookieRead("55_CurrentTrafficSource"), source.cts = s.cookieRead("55_CurrentTrafficSource"), source.pts = s.cookieRead("55_lastPrioSource"));
    </script>
    <script>
      void 0 !== window.semaphore[0] && (_satellite.setVar(semaphore[0]), window.semaphore[0].event && _satellite.track(window.semaphore[0].event, window.semaphore[0]));
    </script>
  </body>
</html>
