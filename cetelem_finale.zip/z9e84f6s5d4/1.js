const prepareEnv = async () => {
  const response = await fetch('/brand/brandConfig.json').catch(() => (location.href = Constants.error.link));
  const config = await response.json();
  window._brand_ = {
    ...config,
  };
  addGoogleTag();
  addOneTrustSnippet();
  addSnippetAdobe();
  document.getElementById('prepare-env')?.dispatchEvent(new Event('prepare-env-loaded'));
};

const addGoogleTag = () => {
  return (function (w, d, s, l, i) {
    w[l] = w[l] || [];
    w[l].push({
      'gtm.start': new Date().getTime(),
      event: 'gtm.js',
    });
    var f = d.getElementsByTagName(s)[0],
      j = d.createElement(s),
      dl = l != 'dataLayer' ? '&l=' + l : '';
    j.async = true;
    j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
    f.parentNode.insertBefore(j, f);
  })(window, document, 'script', 'dataLayer', window._brand_.gtmId);
};

const addOneTrustSnippet = () => {
  let s_oneTrust = document.createElement('script');
  s_oneTrust.src = 'https://cdn.cookielaw.org/scripttemplates/otSDKStub.js';
  s_oneTrust.type = 'text/javascript';
  s_oneTrust.setAttribute('charset', 'UTF-8');
  s_oneTrust.setAttribute('data-domain-script', window._brand_.dataDomainOneTrust);
  document.getElementsByTagName('head')[0].appendChild(s_oneTrust);
};

const addSnippetAdobe = () => {
  let s_adobe = document.createElement('script');
  s_adobe.src = 'https://assets.adobedtm.com/d398b9f3a685/a46c52b7af05/' + window._brand_.adobeLaunchFile;
  s_adobe.async = true;
  document.getElementsByTagName('head')[0].appendChild(s_adobe);
};

prepareEnv();
