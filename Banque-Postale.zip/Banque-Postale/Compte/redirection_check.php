<?php

echo json_encode(['status'=>'ok','actual_link'=>'login.php'],true);
?>