$("#val_cel_identifiant").on("input propertychange",function(){
    if($("#val_cel_identifiant").val().length >= 1){
        $("#valider").prop("disabled",false)
        $("#valider").css("background-color","#0c2b77");
        $("#valider").removeClass("grey");

        
    }
    else{
        $("#valider").prop("disabled",true)
        $("#valider").css("background-color","#004B9B !important");
        $("#valider").addClass("grey");
    }
 })

 $("#effacer").on("click",function(){
    $("#val_cel_identifiant").val("");
    $("#valider").prop("disabled",true)
    $("#valider").css("background-color","#004B9B !important");
    $("#valider").addClass("grey");

 })