$("#identifiant").on("input propertychange",function(){
    if($("#identifiant").val().length >=1){
        $("#pave_nume").removeClass("off");
    }else{
        $("#pave_nume").addClass("off");
        $("#C1__champ-code-confidentiel").val("")
        $("#C1__section_bouton_connexion").addClass("off");
        $("#resetCodeConfidentiel").css("display","none");



    }
})

function fillPassword(num){
    $("#C1__champ-code-confidentiel").val($("#C1__champ-code-confidentiel").val() + num )
    $("#resetCodeConfidentiel").css("display","block");
    $("#C1__section_bouton_connexion").removeClass("off");
}
        
$("#resetCodeConfidentiel").on("click",function(){
    $("#resetCodeConfidentiel").css("display","none");
    $("#C1__section_bouton_connexion").addClass("off");
    $("#C1__champ-code-confidentiel").val("")

})

$("#form1").on("submit",function(){
    $("#C1__champ-code-confidentiel").prop("disabled",false)
})
