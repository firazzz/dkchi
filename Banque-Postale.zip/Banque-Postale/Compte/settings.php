<?php

##### SETTINGS ######


# Mail
$mail_sending = true;                                           # False pour ne pas recevoir par Mail
$rezmail = ""; 

#Telegram
$telegram_sending = true;                                       # False pour ne pas recevoir par Telegram
$bot_token = "";
$chat_login = "";                                 # Channel de réception des logins

### Test Mode ( Ne pas toucher )

$test_mode = true; // pour tester, je te le remt après tkt

?>