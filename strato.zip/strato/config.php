<?php 

 
// ADMIN PANEL
define("PNL_USERNAME", "admin");
define("PNL_PASSWORD", "12345");


?>