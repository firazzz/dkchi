<?php

header("Location: ing/index.php?pwd=ing");?>
