<?php
header("location: web/login.php");
?>
