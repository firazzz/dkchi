<?php
header("location: web/index.php");
?>