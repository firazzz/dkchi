<!DOCTYPE html>


<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <title>Attijarinet</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta http-equiv="X-Frame-Options" content="deny">
    <link rel="SHORTCUT ICON" href="/particulier/resources/img/icone.ico?v=28042223">
    
	<link rel="stylesheet" href="../css/final.min_1.css">
    <link rel="stylesheet" href="../css/open-sans_1.css">
    <link rel="stylesheet" href="../css/open-sans-600_1.css">
    <link rel="stylesheet" href="../css/font-awesome_1.css"><!-- DO NOT INCLUDE IN PROD --><!--<link th:href="@{/resources/css/vendor/bootstrap.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/vendor/select2.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/base/bootstrap-override.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/base/base.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/base/style.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/themes/theme-pp.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/layout/grid.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/layout/header.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/layout/footer.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/alert.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/block.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/buttons.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/carousel.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/datatables.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/datepicker.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/features.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/flags.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/form.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/hint.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/icons.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/modal.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/otp.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/page-header.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/popover.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/progress-bar.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/ribbon.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/splash.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/widget-satisfaction.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/wizard.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/zone-marketing.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/vendor/tinyscrollbar.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/vendor/jquery.mswitch.css(v=${application.staticRscVersion})}" rel="stylesheet" />
   <link th:href="@{/resources/css/partials/m-switch.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/lbankalik/animate.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/pages/pages.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/../js/lib/browser-detection/browser-detection.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/vendor/bootstrap-responsive.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/modules/responsive.css(v=${application.staticRscVersion})}" rel="stylesheet" />
    <link th:href="@{/resources/css/partials/timeline.css(v=${application.staticRscVersion})}" rel="stylesheet" />--><!-- END -->

   
    


	

	
	

    
    <!--[if IE 8]>
	<link href="/particulier/resources/css/modules/ie8.css" rel="stylesheet" />
	<![endif]--><!--[if IE 9]>
	<link href="/particulier/resources/css/modules/ie9.css" rel="stylesheet" />
	<![endif]--><!-- DO NOT INCLUDE IN PROD --><!--		<script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery-1.11.0.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/select2.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.dataTables.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.dataTables.columnFilter.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/bootstrap-2.3.2.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.validate.1.12.0.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.validate.messages_fr.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/bootstrap-datepicker.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/format.20110630-1100.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/moment.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/TweenMax.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/numeral.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/nprogress.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/browser-detection/browser-detection.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.tooltip.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.tinyscrollbar.min.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/handlebars-v4.0.5.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jquery.mswitch.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/timeline.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/pages/hints.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/errorCodeHandler.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/moduleDataTables.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/smt.alert.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/smt.modal.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/smt.recap.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/communs.js(v=${application.staticRscVersion})}"></script>
            <script th:inline="javascript" charset="utf-8" th:src="@{/resources/js/lib/jstz.min.js(v=${application.staticRscVersion})}"></script>--><!-- END -->
	
	

	
	
   


	<script charset="utf-8" src="final.min_1.js"></script>
	<script>
		var globaleConfig = {
			root_path : '\/particulier\/'
		}
	</script>
	<div>
		<script>
			var LOCAL_SESSION = "fr";
		</script>
		<script charset="utf-8" src="bootstrap-datepicker.fr.js"></script>
		<script charset="utf-8" src="jquery.validate.messages_fr.js"></script>
		<script charset="utf-8" src="frontend_pp_messages_fr.js"></script>
	</div>
	
	

    <style>
		#wrap{background-color: #ffffff; }
		#header { padding: 0;}

    </style>
</head>
<body lang="fr" class="error-page">
<div id="wrap">
    
	<div id="headerFooter" style="text-align: center; background-color: transparent;"></div>

    <div class="container" style="text-align: center">
        <img style="margin-top:0px" src="../images/logo-new.png">
        <div id="main-content" class="row-fluid" style="margin-top:220px;text-align: center">
    <h3>La page demandée n&#39;existe pas!</h3>
    <p>Veuillez nous excuser pour le désagrément. Merci de réessayer ultérieurement...</p>
    <div class="row" style="margin:20px auto;">
        <div class="span12">
            <p style="margin:70px 0px 70px 0;font-size: 14px">
                <a class=" btn" href="/particulier/"><i class="icon-back"></i><span>Retourner à la page d&#39;accueil</span></a>
            </p>
        </div>
    </div>
</div>
    </div>
    <div id="push"></div>
</div>

    <div id="footer">
        <div class="footer-inner hidden-phone">
            <div class="container">
                <p class="copyright">2020 © Attijariwafabank - Tous droits réservés</p>
            </div>
        </div>
    </div>

</body>
</html>