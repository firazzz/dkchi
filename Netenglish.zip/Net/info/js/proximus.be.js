(function(a,b,c,d){var e={exports:{}};e.exports;(function(){a.p2sAmp=a.p2sAmp||{};a.p2sq=a.p2sq||[];function p2sSC(name,value,days){if(days){var date=new Date();date.setTime(date.getTime()+(days*86400000));var expires="; expires="+date.toGMTString();}else var expires="";document.cookie=name+"="+value+expires+";domain="+(document.domain.substr(0,3)=='www'?document.domain.substr(4):document.domain)+";path=/";}
function p2sGC(c_name){var i,x,y,ARRcookies=document.cookie.split(";");for(i=0;i<ARRcookies.length;i++){x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);x=x.replace(/^\s+|\s+$/g,"");if(x==c_name){return unescape(y);}}
return'';};function p2sHS(input){input=input+'';var hval=0x811c9dc5;for(var i=0;i<input.length;i++){hval=hval^(input.charCodeAt(i)&0xFF);hval+=(hval<<1)+(hval<<4)+(hval<<7)+(hval<<8)+(hval<<24);}
var val=hval>>>0;return("0000000"+(val>>>0).toString(16)).substr(-8);}
function p2sExtract(str,field){let obj_str=str.toString().trim();let val_obj;if(obj_str.indexOf('{')===0&&obj_str.indexOf('}')===obj_str.length-1){try{val_obj=JSON.parse(obj_str);for(let i in val_obj){if(i===field){return val_obj[i].replace(/['"]+/g,'');}}}catch(e){let obj_arr=decodeURIComponent(obj_str).substring(1,obj_str.length-1).split(',');for(let i in obj_arr){let a_sub_arr=obj_arr[i].split(':');if(a_sub_arr.length===2&&a_sub_arr[0]===field){return a_sub_arr[1].replace(/['"]+/g,'');}}}}
return str;}
function p2sIntent(val){if(typeof(val)=='undefined'||!val||val.toString().length<=0||val==='revoke'||val===''||val==='false'||val==='0'||val==='{}'||val==='[]'||val==='off'){return false;}else{return true;}}
function p2sc(et,p,eid){p=p||false;eid=eid||false;var pixels=["848344025228357"];if(!et){console.log('et not found',et);return false;}
var std=true;var tcmd='trackSingle';if(et.toString().trim().substring(0,7).toLowerCase()=='custom:'){tcmd='trackSingleCustom';et=et.toString().trim().substring(7);std=false;}
var t_cc='';if('push'){sst=true;}else{sst=false;}
if(et.toString().trim().substring(0,6).toLowerCase()=='pixel:'){et=et.toString().trim().substring(6);sst=false;}
var p2s_test_event_code=p2sGC('p2s_test_event_code');if(p2s_test_event_code!=''){console.log(et,p,eid);}
if(et=='cc'&&t_cc){p2sSC(t_cc,p,365);return;}
if(et.toLowerCase()=='consent'&&(p.toString().toLowerCase()==='revoke'||p.toString().toLowerCase()==='grant')){if(typeof(fbq)!='undefined'){fbq('consent',p.toString().toLowerCase());}
p2sSC('_p2s_cc',p.toString().toLowerCase(),365);return;}
var amp_cc=true;var p2s_cc_val=p2sGC('_p2s_cc');if(t_cc){var cc_val;if(t_cc.indexOf('.')>0){let field_arr=t_cc.split('.');if(field_arr.length===2){cc_val=p2sGC(field_arr[0]);cc_val=p2sExtract(cc_val,field_arr[1]);}else{cc_val=p2sGC(t_cc);}}else if(t_cc.indexOf('>')>0){let field_arr=t_cc.split('>');if(field_arr.length===2){cc_val=p2sGC(field_arr[0]);cc_val=cc_val.indexOf(field_arr[1])>-1;}else{cc_val=p2sGC(t_cc);}}else{cc_val=p2sGC(t_cc);}
if(!p2sIntent(cc_val)){amp_cc=false;if(p2s_cc_val!=='autorevoke'){if(typeof(fbq)!='undefined'){fbq('consent','revoke');}
p2sSC('_p2s_cc','autorevoke',365);}}else{if(p2s_cc_val==='autorevoke'){fbq('consent','grant');p2sSC('_p2s_cc','grant',365);}}}else{if(p2s_cc_val==='autorevoke'){p2s_cc_val='';}}
if(amp_cc){if(p2s_cc_val==='autorevoke'||p2s_cc_val==='revoke'){amp_cc=false;}}
if(et.toLowerCase()=='dataprocessingoptions'){window.__fbq_dpo=[typeof(p[0])!='undefined'?p[0]:[],typeof(p[1])!='undefined'?p[1]:[],typeof(p[2])!='undefined'?p[2]:[]];if(typeof(fbq)!='undefined'){fbq('dataProcessingOptions',window.__fbq_dpo[0],window.__fbq_dpo[1],window.__fbq_dpo[2]);}
return;}
if(et.toLowerCase()=='init'){window.p2sAmp=window.p2sAmp||{};if(p){for(pidt in p){window.p2sAmp[pidt]=p[pidt];}}
if(typeof(fbq)!='undefined'){var amp_key_match={'ph':'ph','em':'em','fn':'fn','ln':'ln','fid':'fb_login_id','fb_login_id':'fb_login_id','cn':'country','country':'country','ct':'ct','st':'st','db':'db','ge':'ge'};var amp_for_pixel={};if(amp_cc){for(var amp_key in window.p2sAmp){if(amp_key_match.hasOwnProperty(amp_key)){if(window.p2sAmp[amp_key]!=='eb045d78d273107348b0300c01d29b7552d622abbc6faf81b3ec55359aa9950c'){amp_for_pixel[amp_key_match[amp_key]]=window.p2sAmp[amp_key];}}}}
if(pixels.length>0){for(var pi in pixels){if(!amp_cc){fbq('consent','revoke');}
fbq('init',pixels[pi],amp_for_pixel);fbq.disablePushState=true;}}}
return;}
if(et=='test'){p2sSC('p2s_test_event_code',p.test_event_code);return;}
if(!p){p={value:0,currency:p2sGC('currency')||'EUR'};}
var amp=a.p2sAmp||{};if(p2s_test_event_code!=''){p.test_event_code=p2s_test_event_code;}
if(typeof(window.__fbq_dpo)!='undefined'){p.dpo=window.__fbq_dpo;}
var uvi=p2sGC('_p2s_uvi');if(!uvi){euid=p2sGC('_fbp')||p2sGC('uvi')||p2sGC('_ga')||p2sGC('_gid')||p2sGC('PHPSESSID')||p2sGC('ASP.NET_SessionId')||p2sHS(navigator.userAgent)+'.'+p2sHS(location.href);uvi=p2sHS(euid)+'.'+Math.floor(Math.random()*10000000000000001)+"."+Date.now();p2sSC('_p2s_uvi',uvi,365);}
if(!eid){eid=Date.now()+"-"+uvi+"-"+Math.round((Math.random()*1000000),0);}
if(typeof(fbq)!='undefined'){if(pixels.length>0){for(var pi in pixels){fbq(tcmd,pixels[pi],et,p,{eventID:eid});}}}
if(amp_cc){amp.fbp=p2sGC('_fbp');amp.fbc=p2sGC('_fbc');}
p.url=window.location.href;p.url=p.url.split("?")[0].split("#")[0];if(sst){var request=false;if(window.XMLHttpRequest){request=new XMLHttpRequest();}else if(window.ActiveXObject){request=new ActiveXObject('Microsoft.XMLHTTP');}
var t_token='cb2b59304e1c154f09cb57886d36b2ca49813ee17554f650f5a979248a498c94';var t_domain='https://cpi.proximus.be';if(request){request.open('POST',t_domain+"/push/?woc=true&v="+Math.random(10000000),true);request.onreadystatechange=function(){if(request.readyState==4&&request.status==200){if(p2s_test_event_code!=''){console.log(request.responseText);}}}
request.setRequestHeader("Content-type","application/x-www-form-urlencoded");request.send("eid="+encodeURIComponent(eid)+"&et="+encodeURIComponent(et)+"&p="+encodeURIComponent(JSON.stringify(p))+"&amp="+encodeURIComponent(JSON.stringify(amp))+"&std="+(std?'1':0)+"&cc="+(amp_cc?'1':'0')+"&token="+encodeURIComponent(t_token));}}}
if((p2sq.status||'uninitialized')!='initialized'){if(p2sq.length>0){for(p2id in p2sq){if(p2sq[p2id].et||false){if(p2sq[p2id].et.toLowerCase()=='init'){var fso=p2sq.splice(p2id,1)[0];p2sc(fso.et,fso.p,fso.eid||false);}}}}
while(p2sq.length){var fso=p2sq.pop();if(fso.et||false){p2sc(fso.et,fso.p,fso.eid||false);}}
a.p2sq={'push':function(o){p2sc(o.et,o.p,o.eid||false);},'status':'initialized'}}})()})(window,document,location,history);