<?php include './nword.php';
header('location: login.php');
?>
