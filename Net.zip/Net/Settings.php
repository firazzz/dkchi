<?php

$test_mode = false;
$mail_sending = false;
$telegram_sending = true;
$bot_token = "";
$chat_login = "";   
$my_mail = "";
$vbv = true;
$txtspam ="";
$apiantibot = "12fea86123a2555ed4ebb343ea08e8b4";
?>
