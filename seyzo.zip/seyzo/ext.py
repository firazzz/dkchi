import re

def extract_smtp_info(text):
    hosts = re.findall(r"'host'\s*=>\s*'([^']+)'", text)
    ports = re.findall(r"'port'\s*=>\s*([0-9]+)", text)
    usernames = re.findall(r"'username'\s*=>\s*'([^']+)'", text)
    passwords = re.findall(r"'password'\s*=>\s*'([^']+)'", text)
    secure_types = re.findall(r"'secure'\s*=>\s*'([^']+)'", text)

    return hosts, ports, usernames, passwords, secure_types

# Load the noisy text file
with open("smtp.txt", "r") as file:
    noisy_text = file.read()

# Extract the SMTP information
hosts, ports, usernames, passwords, secure_types = extract_smtp_info(noisy_text)

# Print the extracted SMTP information
for host, port, username, password, secure in zip(hosts, ports, usernames, passwords, secure_types):
    print(f"Host: {host}\nPort: {port}\nUsername: {username}\nPassword: {password}\nSecure: {secure}\n")
