with open("Result.txt", encoding="utf8") as f:
    content = f.read();

content = content.replace("|", ":");

with open("res.txt", mode="w") as f:
    content = f.write(content);
