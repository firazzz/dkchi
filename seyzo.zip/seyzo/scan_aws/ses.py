import boto3

def test_aws_access_keys(access_key, secret_key, region_name):
    try:
        # Create a Boto3 client for the desired AWS service (e.g., S3, EC2, etc.)
        client = boto3.client('s3', aws_access_key_id=access_key, aws_secret_access_key=secret_key, region_name=region_name)

        # List S3 buckets as a simple test
        response = client.list_buckets()

        # If the request was successful, print the bucket names
        if 'Buckets' in response:
            print("Successfully accessed S3 buckets:")
            for bucket in response['Buckets']:
                print(bucket['Name'])

        else:
            print("Unable to access S3 buckets. The credentials might be incorrect.")

    except Exception as e:
        print("Error:", e)

# Read the access keys from the file
with open('res.txt', 'r') as file:
    for line in file:
        access_key, secret_key, region_name = line.strip().split(':')
        test_aws_access_keys(access_key, secret_key, region_name)
