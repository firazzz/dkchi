﻿(function () {
    var w = window,
    nav = w.navigator,
    d = document,
    cn = "DocuTrak";
    logUrl = "";

    //Flags
    var DoNotTrack = function () {
        var dnt = nav.doNotTrack || nav.msDoNotTrack;
        return dnt === "1" || dnt === "yes";
        },
        Disabled = function () {
            var a = PageDocument.location.protocol;
            if ("http:" !== a && "https:" !== a) return !0;
            if (DoNotTrack()) return !0;

            return !1;
        },
        IsHttps = function () {
            return "https:" === d.location.protocol;
        },
        ErrorUrl = function () {
            return (IsHttps() ? "https:" : "http:") + "//wt.dm00.com/WebSiteTracking/api/tracking/Error";
            //return "https://wst.documatix.com/WebSiteTracking/api/tracking/Error";
        },
        LoggingUrl = function () {
            return (IsHttps() ? "https:" : "http:") + "//wt.dm00.com/WebSiteTracking/api/tracking/Log";
            //return "https://wst.documatix.com/WebSiteTracking/api/tracking/Log";
        },
        getDomain = function () {
            var a = "" + d.location.hostname;
            return 0 === a.indexOf("www.") ? a.substring(4) : a;
        },
        CompanyGuid = function () {
            try {
                var scripts = document.getElementsByTagName("script");
                var wtScript = scripts[scripts.length - 1];
                for (var i = 0, l = scripts.length; i < l; i++) {
                    if (scripts[i].src.lastIndexOf("wt.dm00.com") > -1) {
                        wtScript = scripts[i];
                        break;
                    }
                }
                if (wtScript.getAttribute("data-cguid") === null) {
                    return "";
                }
                else {
                    return wtScript.getAttribute("data-cguid");
                }
            }
            catch (err) {
                return "";
            }
        },
        UrlGuid = function () {
            try {
                var scripts = document.getElementsByTagName("script");
                var wtScript = scripts[scripts.length - 1];
                for (var i = 0, l = scripts.length; i < l; i++) {
                    if (scripts[i].src.lastIndexOf("wt.dm00.com") > -1) {
                        wtScript = scripts[i];
                        break;
                    }
                }
                if (wtScript.getAttribute("data-uguid") === null) {
                    return "";
                }
                else {
                    return wtScript.getAttribute("data-uguid");
                }
            }
            catch (err) {
                return "";
            }
        },
        EmptyFunction = function () { };


    //Helpers
    //function EncodeUri(uri) {
    //    if (encodeURIComponent instanceof Function) return encodeURIComponent(uri);
    //    return uri;
    //}

  
    function ProcessPage() {
        try {
            var currentTrackingGuid = SetCookie();
            var data = { Title: d.title, url: window.location, TrackingGuid: currentTrackingGuid, CompanyGuid: CompanyGuid(), UrlGuid: UrlGuid() };
            var url = LoggingUrl();
            LogData(url, BuildQueryString(data), EmptyFunction);
        }
        catch (err) {
            LogError(err);
        }
    }

    function BuildQueryString(obj) {
        var str = [];
        for (var p in obj)
            if (obj.hasOwnProperty(p)) {
                str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
            }
        return str.join("&");
    }

    //function GetParameterByName(name, url) {
    //    if (!url) url = window.location.href;
    //    name = name.replace(/[\[\]]/g, "\\$&");
    //    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
    //        results = regex.exec(url);
    //    if (!results) return null;
    //    if (!results[2]) return '';
    //    return decodeURIComponent(results[2].replace(/\+/g, " "));
    //}

    //function GetScriptParameters() {
    //    var scripts = document.getElementsByTagName('script');
    //    var lastScript = scripts[scripts.length - 1];
    //    var scriptName = lastScript;
    //    return {
    //        companyGuid: scriptName.getAttribute('data-cguid')
    //    };
    //}


    //Cookie Functions///////////////////////////////////////////////
    function SetCookie() {
        var oldCookie = GetOldCookie();
        if (oldCookie !== null) {
            DeleteOldCookie();
            return CreateNewCookie(oldCookie);
        }
        else {
            var newCookie = GetNewCookie();
            if (newCookie !== null && newCookie !== 'undefined' && newCookie !== '') {
                return newCookie;
            }
            else {
                return CreateNewCookie();
            }
        }
    }

    function GetOldCookie() {
        var nameEQ = cn + "=";
        var ca = d.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) === ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

    function GetNewCookie() {
        var nameEQ = cn + '_' + CompanyGuid() + "=";
        var ca = d.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) === ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

    function CreateNewCookie(trackingGuid) {
        if (trackingGuid === null || trackingGuid === 'undefined' || trackingGuid === undefined || trackingGuid === '') {
            trackingGuid = CreateGuid();
        }
        var name = cn + '_' + CompanyGuid();
        var expireDate = "";
        var date = new Date();
        date.setTime(date.getTime() + (365 * 24 * 60 * 60 * 1000));
        expireDate = date.toUTCString();
        //d.cookie = name + "=" + trackingGuid + "; expires=" + expireDate + "; domain=" + getDomain() + "; path=/";
        d.cookie = name + "=" + trackingGuid + "; expires=" + expireDate + "; path=/";
        return trackingGuid;
    }

    function DeleteOldCookie() {
        //var expireDate = "";
        //var date = new Date();
        //date.setTime(date.getTime() - (900000000));
        //expireDate = date.toUTCString();
        //d.cookie = cn + "=" + "" + "; max-age=0; expires=" + expireDate + "; domain=" + getDomain() + ";path=/";

        var d = new Date;
        d.setTime(d.getTime() + 24 * 60 * 60 * 1000 * -1);
        document.cookie = cn + "=" + "" + "; expires=" + d.toGMTString() + "; path=/";
    }

    //function GetLargeRandomNumber() {
    //    return Math.round(2147483647 * Math.random());
    //}

    function CreateGuid() {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        }
        return s4() + s4() + s4() + s4();
    }

    //function GetClientId() {
    //    return GetLargeRandomNumber();
    //}
    //End Cookie Functions/////////////////////////////////////////////////


    //Error handling//////////////////////////////////////////////////////
    function LogError(errorMessage) {
        try {
            var currentTrackingGuid = GetCookie(cn + '_' + CompanyGuid());
            var data = { name: d.title, url: window.location, TrackingGuid: currentTrackingGuid, CompanyGuid: CompanyGuid, ErrorMessage: errorMessage };
            var httpRequest = XMLHttpRequest;
            if (!httpRequest) return !1;
            var logRequest = new httpRequest;
            logRequest.open("POST", ErrorUrl(), !0);
            logRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            logRequest.onreadystatechange = function () {
                4 === logRequest.readyState && (callback(), elogRequest = null);
            };
            logRequest.send(data);
            return !0;
        }
        catch (err) {
        }
    };
    //End Error handling//////////////////////////////////////////////////////


    //Logging Functions///////////////////////////////////////////////////////////

    //Send by Image
    function GetImageElement(imageUrl) {
        var img = d.createElement("img");
        img.width = 1;
        img.height = 1;
        img.src = imageUrl;
        return img;
    }

    //function SendByImage(imageUrl, queryString, callback) {
    //    try {
    //        var img = GetImageElement(imageUrl + "?" + queryString);
    //        img.onload = img.onerror = function () {
    //            img.onload = null;
    //            img.onerror = null;
    //            callback();
    //        };
    //    }
    //    catch (err) {
    //        LogError(err);
    //    }
    //}

    //Send by ajax post
    function SendByPost(url, data, callback) {
        try {
            var httpRequest = XMLHttpRequest;
            if (!httpRequest) return !1;
            var logRequest = new httpRequest;
            logRequest.open("POST", url, !0);
            logRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            logRequest.onreadystatechange = function () {
                4 === logRequest.readyState && (callback(), elogRequest = null);
            };
            logRequest.send(data);
            return !0;
        }
        catch (err) {
            LogError(err);
        }
    };

    //Send by beacon
    function SendByBeacon(url, data, callback) {
        try {
            var headers = { type: 'application/x-www-form-urlencoded' };
            var blob = new Blob([data], headers);
            return w.navigator.sendBeacon ? (w.navigator.sendBeacon(url, blob) ? (callback(), !0) : !1) : !1;
        }
        catch (err) {
            LogError(err);
        }
    }

    //Based on the size of the data, we will either use a beacon or a ajax post to send this data.
    function LogData(url, data, callback) {
        try {
            callback = callback || EmptyFunction;

            // Internet Explorer 6-11
            var isIE = /*@cc_on!@*/false || !!document.documentMode || navigator.userAgent.indexOf("MSIE") != -1;

            var isEdge = !isIE && !!window.StyleMedia;

            // Safari 3.0+
            var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || safari.pushNotification) || navigator.userAgent.indexOf("Safari") !== -1 && !isEdge;

            if (8192 >= data.length && isSafari !== true && isIE !== true) {
                SendByBeacon(url, data, callback);
            }
            else {
                SendByPost(url, data, callback);
            }
        }
        catch (err) {
            LogError(err);
        }
    }

    //End Logging Functions///////////////////////////////////////////////////////////


    ProcessPage();


})(window);